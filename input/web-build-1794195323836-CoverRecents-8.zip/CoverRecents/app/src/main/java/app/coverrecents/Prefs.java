package app.coverrecents;

import android.content.Context;
import android.content.SharedPreferences;

/** Wszystkie ustawienia aplikacji w jednym miejscu. */
final class Prefs {

    // Układ i zawartość
    static final String LAYOUT = "layout";
    static final String COLUMNS = "columns";
    static final String LABELS = "labels";
    static final String CLOSE_ALL = "close_all";
    static final String MAX_APPS = "max_apps";

    // Wygląd
    static final String THEME = "theme";
    static final String STYLE = "style";
    static final String BLUR_DP = "blur_dp";

    // Gest przytrzymania paska
    static final String HANDLE = "handle";
    static final String HANDLE_VISIBLE = "handle_visible";
    static final String HANDLE_HEIGHT = "handle_height";
    static final String HANDLE_OFFSET = "handle_offset";
    static final String HANDLE_AUTO = "handle_auto";
    static final String HOLD_MS = "bar_hold_ms";

    static final String LAYOUT_CAROUSEL = "carousel";
    static final String LAYOUT_GRID = "grid";

    static final String THEME_SYSTEM = "system";
    static final String THEME_DARK = "dark";
    static final String THEME_LIGHT = "light";
    static final String THEME_AMOLED = "amoled";

    static final String STYLE_ONEUI = "oneui";
    static final String STYLE_GLASS = "glass";
    static final String STYLE_PREVIEW = "preview";

    // Motyw One UI
    static final String ACCENT = "accent";
    static final String RADIUS_DP = "radius_dp";
    static final String DIM_ONEUI = "dim_oneui";
    static final String DIM_GLASS = "dim_glass";
    static final String DIM_PREVIEW = "dim_preview";
    static final String CARD_ALPHA = "card_alpha";
    static final String BORDER = "border";

    // Liquid glass
    static final String GLASS_REFRACT = "glass_refract";
    static final String GLASS_SHINE = "glass_shine";
    static final String GLASS_DISPERSION = "glass_dispersion";

    // Podgląd aplikacji
    static final String SNAPSHOTS = "snapshots";

    // Animacje
    static final String ANIM = "anim";
    static final String ANIM_ONEUI = "oneui";
    static final String ANIM_IOS = "ios";
    static final String ANIM_FLOW = "flow";
    static final String ANIM_NONE = "none";

    private Prefs() {
    }

    static SharedPreferences get(Context c) {
        return c.getApplicationContext().getSharedPreferences("settings", Context.MODE_PRIVATE);
    }

    static boolean isGrid(Context c) {
        return LAYOUT_GRID.equals(get(c).getString(LAYOUT, LAYOUT_CAROUSEL));
    }

    static int columns(Context c) {
        return get(c).getInt(COLUMNS, 3);
    }

    static boolean showLabels(Context c) {
        return get(c).getBoolean(LABELS, true);
    }

    static boolean showCloseAll(Context c) {
        return get(c).getBoolean(CLOSE_ALL, true);
    }

    static int maxApps(Context c) {
        return get(c).getInt(MAX_APPS, 10);
    }

    static String theme(Context c) {
        return get(c).getString(THEME, THEME_DARK);
    }

    static String style(Context c) {
        String v = get(c).getString(STYLE, STYLE_ONEUI);
        // Wartości z wcześniejszych wersji.
        if ("standard".equals(v) || "blur".equals(v)) {
            return STYLE_ONEUI;
        }
        return v;
    }

    static int blurDp(Context c) {
        return get(c).getInt(BLUR_DP, 50);
    }

    static int i(Context c, String key, int def) {
        return get(c).getInt(key, def);
    }

    static boolean b(Context c, String key, boolean def) {
        return get(c).getBoolean(key, def);
    }

    static String accent(Context c) {
        return get(c).getString(ACCENT, "none");
    }

    static int radiusDp(Context c) {
        return get(c).getInt(RADIUS_DP, 28);
    }

    static String dimKey(String style) {
        switch (style) {
            case STYLE_GLASS:
                return DIM_GLASS;
            case STYLE_PREVIEW:
                return DIM_PREVIEW;
            default:
                return DIM_ONEUI;
        }
    }

    static int dimDefault(String style) {
        switch (style) {
            case STYLE_GLASS:
                return 30;
            case STYLE_PREVIEW:
                return 60;
            default:
                return 55;
        }
    }

    /** Przyciemnienie tła w procentach (osobne dla każdego stylu). */
    static int dim(Context c) {
        String st = style(c);
        return get(c).getInt(dimKey(st), dimDefault(st));
    }

    static String anim(Context c) {
        return get(c).getString(ANIM, ANIM_ONEUI);
    }

    static boolean snapshotsOn(Context c) {
        return get(c).getBoolean(SNAPSHOTS, true);
    }

    /** Czy usługa ma zapisywać podglądy aplikacji (tylko dla stylu z podglądem). */
    static boolean needsSnapshots(Context c) {
        return STYLE_PREVIEW.equals(style(c)) && snapshotsOn(c);
    }

    static boolean handleEnabled(Context c) {
        return get(c).getBoolean(HANDLE, false);
    }

    static boolean handleVisible(Context c) {
        return get(c).getBoolean(HANDLE_VISIBLE, false);
    }

    /** Domyślnie obszar gestu pokrywa dokładnie systemowy pasek powrotu do ekranu głównego. */
    static boolean handleAutoOffset(Context c) {
        return get(c).getBoolean(HANDLE_AUTO, true);
    }

    static int handleHeightDp(Context c) {
        return get(c).getInt(HANDLE_HEIGHT, 28);
    }

    static int handleOffsetDp(Context c) {
        return get(c).getInt(HANDLE_OFFSET, 0);
    }

    static int holdMs(Context c) {
        return get(c).getInt(HOLD_MS, 2000);
    }
}
