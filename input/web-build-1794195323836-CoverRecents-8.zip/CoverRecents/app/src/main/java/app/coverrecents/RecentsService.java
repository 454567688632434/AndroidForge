package app.coverrecents;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.ColorSpace;
import android.graphics.Insets;
import android.graphics.PixelFormat;
import android.hardware.HardwareBuffer;
import android.hardware.display.DisplayManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/**
 * Gest przytrzymania paska: niewidoczne okno dokładnie na systemowym pasku powrotu do ekranu
 * głównego (przy dolnej krawędzi ekranu zewnętrznego). Przytrzymanie paska przez kilka sekund
 * otwiera ekran ostatnich aplikacji.
 *
 * Okno ma wysokość samego paska, więc reszta ekranu działa normalnie. Ruch palca poza małą
 * tolerancję anuluje przytrzymanie, więc zwykłe przesunięcie w górę (powrót do ekranu głównego)
 * nie uruchamia ostatnich - ten gest nadal obsługuje system.
 */
public class RecentsService extends AccessibilityService {

    private static final String TAG = "CoverRecents";

    private static final int HOLD_SLOP_DP = 10;
    private static final int MIN_BAR_HEIGHT_DP = 20;

    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable reattach = new Runnable() {
        @Override
        public void run() {
            detachOverlay();
            attachOverlay();
        }
    };

    private final SharedPreferences.OnSharedPreferenceChangeListener prefListener =
            (prefs, key) -> {
                if (key == null) {
                    return;
                }
                switch (key) {
                    case Prefs.HANDLE:
                    case Prefs.HANDLE_VISIBLE:
                    case Prefs.HANDLE_HEIGHT:
                    case Prefs.HANDLE_OFFSET:
                    case Prefs.HANDLE_AUTO:
                        handler.removeCallbacks(reattach);
                        handler.postDelayed(reattach, 250);
                        break;
                    default:
                        break;
                }
            };

    private final DisplayManager.DisplayListener displayListener =
            new DisplayManager.DisplayListener() {
                @Override
                public void onDisplayAdded(int displayId) {
                    if (displayId == CoverLauncher.COVER_DISPLAY_ID) {
                        attachOverlay();
                    }
                }

                @Override
                public void onDisplayRemoved(int displayId) {
                    if (displayId == CoverLauncher.COVER_DISPLAY_ID) {
                        detachOverlay();
                    }
                }

                @Override
                public void onDisplayChanged(int displayId) {
                }
            };

    private static final long SHOT_DEBOUNCE_MS = 1200;
    private static final long SHOT_MIN_GAP_MS = 3000;

    /** Działająca usługa (dla ekranu ostatnich, który prosi o zrzut tła). */
    static volatile RecentsService instance;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Runnable shotTask = this::captureForeground;
    private Set<String> ignored = new HashSet<>();
    private long ignoredAt;
    private String fgPkg;
    private long lastShotMs;

    private WindowManager overlayWindowManager;
    private View overlay;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        getSystemService(DisplayManager.class).registerDisplayListener(displayListener, handler);
        Prefs.get(this).registerOnSharedPreferenceChangeListener(prefListener);
        instance = this;
        attachOverlay();
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        cleanup();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        cleanup();
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Zdarzenia służą tylko do ustalenia, która aplikacja jest na wierzchu (podgląd aplikacji).
        if (event == null || !Prefs.needsSnapshots(this)) {
            return;
        }
        CharSequence cs = event.getPackageName();
        if (cs == null) {
            return;
        }
        String p = cs.toString();
        handler.removeCallbacks(shotTask);
        if (isIgnored(p)) {
            // System, launcher albo klawiatura na wierzchu - to nie jest zawartość aplikacji.
            fgPkg = null;
            return;
        }
        fgPkg = p;
        handler.postDelayed(shotTask, SHOT_DEBOUNCE_MS);
    }

    private boolean isIgnored(String pkg) {
        long now = SystemClock.uptimeMillis();
        if (ignored.isEmpty() || now - ignoredAt > 60_000) {
            Set<String> set = new HashSet<>(RecentApps.ignoredPackages(this));
            InputMethodManager imm = getSystemService(InputMethodManager.class);
            if (imm != null) {
                for (InputMethodInfo info : imm.getEnabledInputMethodList()) {
                    set.add(info.getPackageName());
                }
            }
            ignored = set;
            ignoredAt = now;
        }
        return ignored.contains(pkg);
    }

    /** Zrzut aplikacji na wierzchu (ograniczony częstotliwością, tylko gdy ekran zewnętrzny świeci). */
    private void captureForeground() {
        String pkg = fgPkg;
        if (pkg == null || !Prefs.needsSnapshots(this)) {
            return;
        }
        long wait = SHOT_MIN_GAP_MS - (SystemClock.uptimeMillis() - lastShotMs);
        if (wait > 0) {
            handler.postDelayed(shotTask, wait);
            return;
        }
        if (!coverOn()) {
            return;
        }
        grab(CoverLauncher.COVER_DISPLAY_ID, pkg, null);
    }

    private boolean coverOn() {
        Display d = getSystemService(DisplayManager.class).getDisplay(CoverLauncher.COVER_DISPLAY_ID);
        return d != null && d.getState() == Display.STATE_ON;
    }

    /**
     * Zrzut ekranu. Jeśli savePkg != null, zapisuje go jako miniaturę tej aplikacji.
     * Callback (może być null) dostaje zeskalowaną bitmapę albo null przy błędzie, na głównym wątku.
     */
    void grab(int displayId, String savePkg, Consumer<Bitmap> cb) {
        lastShotMs = SystemClock.uptimeMillis();
        try {
            takeScreenshot(displayId, getMainExecutor(), new TakeScreenshotCallback() {
                @Override
                public void onSuccess(ScreenshotResult result) {
                    final HardwareBuffer hb = result.getHardwareBuffer();
                    final ColorSpace cs = result.getColorSpace();
                    worker.execute(() -> {
                        Bitmap out = null;
                        try {
                            Bitmap hw = Bitmap.wrapHardwareBuffer(hb, cs);
                            if (hw != null) {
                                Bitmap sw = hw.copy(Bitmap.Config.ARGB_8888, false);
                                if (sw != null) {
                                    out = Snapshots.scaled(sw);
                                }
                            }
                        } catch (RuntimeException e) {
                            Log.w(TAG, "Zrzut: błąd przetwarzania", e);
                        } finally {
                            hb.close();
                        }
                        if (out != null && savePkg != null) {
                            Snapshots.save(RecentsService.this, savePkg, out);
                        }
                        final Bitmap res = out;
                        handler.post(() -> {
                            if (cb != null) {
                                cb.accept(res);
                            }
                        });
                    });
                }

                @Override
                public void onFailure(int errorCode) {
                    // np. okno z FLAG_SECURE albo zbyt częste zrzuty
                    if (cb != null) {
                        cb.accept(null);
                    }
                }
            });
        } catch (RuntimeException e) {
            Log.w(TAG, "takeScreenshot nie powiodło się", e);
            if (cb != null) {
                cb.accept(null);
            }
        }
    }

    /**
     * Otwieranie ostatnich z gestu: najpierw zrzut aplikacji na wierzchu (miniatura + tło szkła),
     * dopiero potem ekran ostatnich, żeby zrzut nie zawierał już naszego okna.
     */
    private void openRecents() {
        boolean wantsBackdrop = Prefs.STYLE_GLASS.equals(Prefs.style(this));
        if ((Prefs.needsSnapshots(this) || wantsBackdrop) && coverOn()) {
            String save = Prefs.needsSnapshots(this) ? fgPkg : null;
            grab(CoverLauncher.COVER_DISPLAY_ID, save, bmp -> {
                if (bmp != null && wantsBackdrop) {
                    Snapshots.putHandoff(bmp);
                }
                CoverLauncher.openRecentsOnCover(this);
            });
        } else {
            CoverLauncher.openRecentsOnCover(this);
        }
    }

    @Override
    public void onInterrupt() {
    }

    private void cleanup() {
        if (instance == this) {
            instance = null;
        }
        handler.removeCallbacksAndMessages(null);
        Prefs.get(this).unregisterOnSharedPreferenceChangeListener(prefListener);
        DisplayManager dm = getSystemService(DisplayManager.class);
        if (dm != null) {
            dm.unregisterDisplayListener(displayListener);
        }
        detachOverlay();
    }

    private void attachOverlay() {
        if (overlay != null || !Prefs.handleEnabled(this)) {
            return;
        }
        DisplayManager dm = getSystemService(DisplayManager.class);
        Display display = dm.getDisplay(CoverLauncher.COVER_DISPLAY_ID);
        if (display == null) {
            Log.w(TAG, "Brak display " + CoverLauncher.COVER_DISPLAY_ID + " - to nie jest Z Flip?");
            return;
        }
        try {
            Context ctx = createDisplayContext(display)
                    .createWindowContext(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, null);
            WindowManager wm = ctx.getSystemService(WindowManager.class);
            float density = ctx.getResources().getDisplayMetrics().density;

            int heightPx;
            int offsetPx;
            if (Prefs.handleAutoOffset(this)) {
                // Dokładnie na pasku nawigacji: wysokość = wysokość paska systemowego.
                Insets nav = wm.getCurrentWindowMetrics().getWindowInsets()
                        .getInsetsIgnoringVisibility(WindowInsets.Type.navigationBars());
                heightPx = Math.max(nav.bottom, Math.round(MIN_BAR_HEIGHT_DP * density));
                offsetPx = 0;
            } else {
                heightPx = Math.round(Prefs.handleHeightDp(this) * density);
                offsetPx = Math.round(Prefs.handleOffsetDp(this) * density);
            }

            View view = new View(ctx);
            if (Prefs.handleVisible(this)) {
                view.setBackgroundColor(0x40FFFFFF);
            }
            view.setOnTouchListener(new BarHoldListener(density));

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    heightPx,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.BOTTOM;
            lp.y = offsetPx;
            // Okno liczone od fizycznej krawędzi ekranu, a nie od krawędzi paska systemowego.
            lp.setFitInsetsTypes(0);

            wm.addView(view, lp);
            overlayWindowManager = wm;
            overlay = view;
            Log.i(TAG, "Gest paska dodany na display " + CoverLauncher.COVER_DISPLAY_ID
                    + " (wysokość " + heightPx + " px, odstęp " + offsetPx + " px)");
        } catch (RuntimeException e) {
            Log.e(TAG, "Nie udało się dodać gestu na ekran zewnętrzny", e);
        }
    }

    private void detachOverlay() {
        if (overlay != null && overlayWindowManager != null) {
            try {
                overlayWindowManager.removeView(overlay);
            } catch (RuntimeException e) {
                Log.w(TAG, "removeView nie powiodło się", e);
            }
        }
        overlay = null;
        overlayWindowManager = null;
    }

    /** Długie przytrzymanie w jednym miejscu; ruch poza tolerancję anuluje. */
    private final class BarHoldListener implements View.OnTouchListener {
        private final float slopPx;

        private float downX;
        private float downY;
        private View touchedView;

        private final Runnable fire = new Runnable() {
            @Override
            public void run() {
                if (touchedView != null) {
                    touchedView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                }
                openRecents();
            }
        };

        BarHoldListener(float density) {
            slopPx = HOLD_SLOP_DP * density;
        }

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    touchedView = v;
                    downX = e.getRawX();
                    downY = e.getRawY();
                    handler.removeCallbacks(fire);
                    handler.postDelayed(fire, Prefs.holdMs(RecentsService.this));
                    return true;

                case MotionEvent.ACTION_MOVE:
                    if (Math.hypot(e.getRawX() - downX, e.getRawY() - downY) > slopPx) {
                        // Palec się przesuwa (np. powrót do ekranu głównego) - to nie przytrzymanie.
                        handler.removeCallbacks(fire);
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    handler.removeCallbacks(fire);
                    return true;

                default:
                    return true;
            }
        }
    }
}
