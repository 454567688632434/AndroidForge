package app.coverrecents;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.LruCache;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/**
 * Miniatury ostatnio widzianych aplikacji (dla stylu "Podgląd aplikacji").
 *
 * Zwykła aplikacja nie ma dostępu do systemowych miniatur zadań, więc usługa ułatwień dostępu
 * robi zrzut ekranu zewnętrznego, gdy aplikacja jest na wierzchu. Pliki leżą w prywatnym cache
 * aplikacji (JPEG, ~400 px szerokości) i znikają razem z zamknięciem aplikacji z listy.
 */
final class Snapshots {

    static final int WIDTH = 400;
    private static final int MAX_FILES = 30;
    private static final long HANDOFF_MAX_AGE_MS = 3000;

    private static final LruCache<String, Bitmap> CACHE =
            new LruCache<String, Bitmap>(12 * 1024 * 1024) {
                @Override
                protected int sizeOf(String key, Bitmap value) {
                    return value.getByteCount();
                }
            };
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static volatile Bitmap handoff;
    private static volatile long handoffAt;

    private Snapshots() {
    }

    private static File dir(Context c) {
        File d = new File(c.getCacheDir(), "snaps");
        if (!d.isDirectory()) {
            //noinspection ResultOfMethodCallIgnored
            d.mkdirs();
        }
        return d;
    }

    private static File file(Context c, String pkg) {
        return new File(dir(c), pkg + ".jpg");
    }

    /** Skaluje zrzut do szerokości WIDTH (software ARGB_8888). */
    static Bitmap scaled(Bitmap src) {
        if (src.getWidth() <= WIDTH) {
            return src;
        }
        int h = Math.round(src.getHeight() * (WIDTH / (float) src.getWidth()));
        return Bitmap.createScaledBitmap(src, WIDTH, h, true);
    }

    static void save(Context c, String pkg, Bitmap bmp) {
        CACHE.put(pkg, bmp);
        File f = file(c, pkg);
        try (FileOutputStream out = new FileOutputStream(f)) {
            bmp.compress(Bitmap.CompressFormat.JPEG, 84, out);
        } catch (IOException ignored) {
            // brak miejsca - podgląd po prostu się nie zapisze
        }
        prune(c);
    }

    private static void prune(Context c) {
        File[] files = dir(c).listFiles();
        if (files == null || files.length <= MAX_FILES) {
            return;
        }
        Arrays.sort(files, Comparator.comparingLong(File::lastModified));
        for (int i = 0; i < files.length - MAX_FILES; i++) {
            //noinspection ResultOfMethodCallIgnored
            files[i].delete();
        }
    }

    static Bitmap cached(String pkg) {
        return CACHE.get(pkg);
    }

    /** Wczytuje miniaturę poza głównym wątkiem; callback na głównym (null = brak). */
    static void loadAsync(Context c, String pkg, Consumer<Bitmap> cb) {
        final Context app = c.getApplicationContext();
        IO.execute(() -> {
            Bitmap b = CACHE.get(pkg);
            if (b == null) {
                File f = file(app, pkg);
                if (f.isFile()) {
                    b = BitmapFactory.decodeFile(f.getAbsolutePath());
                    if (b != null) {
                        CACHE.put(pkg, b);
                    }
                }
            }
            final Bitmap result = b;
            MAIN.post(() -> cb.accept(result));
        });
    }

    static void delete(Context c, String pkg) {
        CACHE.remove(pkg);
        //noinspection ResultOfMethodCallIgnored
        file(c, pkg).delete();
    }

    static void clearAll(Context c) {
        CACHE.evictAll();
        File[] files = dir(c).listFiles();
        if (files != null) {
            for (File f : files) {
                //noinspection ResultOfMethodCallIgnored
                f.delete();
            }
        }
    }

    // ---- przekazanie świeżego zrzutu tła z usługi do ekranu ostatnich ----

    static void putHandoff(Bitmap b) {
        handoff = b;
        handoffAt = SystemClock.uptimeMillis();
    }

    static Bitmap takeHandoff() {
        Bitmap b = handoff;
        handoff = null;
        if (b != null && SystemClock.uptimeMillis() - handoffAt <= HANDOFF_MAX_AGE_MS) {
            return b;
        }
        return null;
    }
}
