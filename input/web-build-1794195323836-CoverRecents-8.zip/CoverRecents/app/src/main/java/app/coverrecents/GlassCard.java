package app.coverrecents;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RuntimeShader;
import android.graphics.Shader;
import android.widget.LinearLayout;

/**
 * Karta z prawdziwym "liquid glass" rysowanym shaderem AGSL (GPU).
 *
 * Gdy mamy zrzut tła (usługa ułatwień dostępu), szkło faktycznie je załamuje: przy krawędzi
 * próbkowanie tła jest zaginane wzdłuż normalnej kształtu (soczewka), kanały RGB rozchodzą się
 * (dyspersja), a światło krawędziowe i połysk zależą od położenia karty na ekranie. Bez zrzutu
 * rysujemy półprzezroczystą taflę z tym samym oświetleniem, na tle rozmytym przez system.
 *
 * Wydajność: jeden przebieg shadera na kartę, 3 próbki tekstury, odświeżany tylko podczas
 * przewijania i animacji (patrz RecentsActivity).
 */
final class GlassCard extends LinearLayout {

    /** Wspólny stan wszystkich kart (jeden na ekran). */
    static final class Env {
        Shader bg;               // miękka kopia zrzutu tła
        float k = 1f;            // piksele tekstury na piksel ekranu
        boolean hasBg;
        boolean dark;
        float screenW = 1f;
        float radiusPx = 60f;
        float refract = 0.6f;    // 0..1
        float shine = 0.6f;      // 0..1
        float dispersion = 1f;   // 0 albo 1
        float dimK = 0f;         // jak mocno przyciemnić tło widziane przez szkło
        final float[] tint = {1f, 1f, 1f, 0.2f};
        Shader dummy;
    }

    private static final String AGSL = ""
            + "uniform shader bg;\n"
            + "uniform float2 size;\n"
            + "uniform float2 origin;\n"
            + "uniform float s;\n"
            + "uniform float k;\n"
            + "uniform float radius;\n"
            + "uniform float refr;\n"
            + "uniform float shine;\n"
            + "uniform float disp;\n"
            + "uniform float hasBg;\n"
            + "uniform float dark;\n"
            + "uniform float dimK;\n"
            + "uniform float2 lightDir;\n"
            + "uniform float4 tint;\n"
            + "\n"
            + "float sd(float2 p, float2 b, float r) {\n"
            + "    float2 q = abs(p) - b + float2(r);\n"
            + "    return min(max(q.x, q.y), 0.0) + length(max(q, float2(0.0))) - r;\n"
            + "}\n"
            + "\n"
            + "float3 tap(float2 pos) {\n"
            + "    return bg.eval((origin + pos * s) * k).rgb;\n"
            + "}\n"
            + "\n"
            + "half4 main(float2 frag) {\n"
            + "    float2 c = size * 0.5;\n"
            + "    float2 p = frag - c;\n"
            + "    float r = min(radius, min(c.x, c.y));\n"
            + "    float d = sd(p, c, r);\n"
            + "    float alpha = clamp(0.5 - d, 0.0, 1.0);\n"
            + "    if (alpha <= 0.0) { return half4(0.0); }\n"
            + "\n"
            + "    float2 gx = float2(1.0, 0.0);\n"
            + "    float2 gy = float2(0.0, 1.0);\n"
            + "    float2 n = normalize(float2(sd(p + gx, c, r) - sd(p - gx, c, r),\n"
            + "                                sd(p + gy, c, r) - sd(p - gy, c, r)) + float2(0.00001));\n"
            + "    float bw = max(14.0, r * 0.85);\n"
            + "    float t = clamp(1.0 + d / bw, 0.0, 1.0);\n"
            + "    float lens = t * t;\n"
            + "\n"
            + "    float3 col;\n"
            + "    if (hasBg > 0.5) {\n"
            + "        float2 q = c + p * (1.0 - 0.07 * refr);\n"
            + "        float2 off = n * (lens * bw * refr * 1.1);\n"
            + "        float3 sr = tap(q - off * (1.0 + 0.22 * disp));\n"
            + "        float3 sg = tap(q - off);\n"
            + "        float3 sb = tap(q - off * (1.0 - 0.22 * disp));\n"
            + "        col = float3(sr.r, sg.g, sb.b) * (1.0 - dimK);\n"
            + "    } else {\n"
            + "        col = dark > 0.5 ? float3(0.18, 0.19, 0.22) : float3(1.0);\n"
            + "    }\n"
            + "    col = mix(col, tint.rgb, tint.a);\n"
            + "\n"
            + "    float lit = max(dot(n, lightDir), 0.0);\n"
            + "    float back = max(dot(n, -lightDir), 0.0);\n"
            + "    float rim = pow(t, 3.0);\n"
            + "    float spec = rim * (0.20 + 0.80 * lit) + rim * 0.25 * back;\n"
            + "    float edge = 1.0 - smoothstep(0.0, 1.5, abs(d + 0.75));\n"
            + "    float gloss = (1.0 - smoothstep(0.0, 0.55, frag.y / size.y)) * 0.07;\n"
            + "    float hi = (spec * 0.55 + edge * (0.20 + 0.45 * lit) + gloss) * shine;\n"
            + "    col += hi * (dark > 0.5 ? 1.0 : 1.2);\n"
            + "    col = clamp(col, 0.0, 1.0);\n"
            + "\n"
            + "    float a = mix(clamp(0.52 + hi * 1.4, 0.0, 1.0), 1.0, hasBg) * alpha;\n"
            + "    return half4(half3(col * a), half(a));\n"
            + "}\n";

    private final Env env;
    private final RuntimeShader shader = new RuntimeShader(AGSL);
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    GlassCard(Context c, Env env) {
        super(c);
        this.env = env;
        setWillNotDraw(false);
    }

    /** Miękka kopia tła do próbkowania; null = tryb bez zrzutu. */
    static Shader makeBackdropShader(Bitmap soft) {
        BitmapShader bs = new BitmapShader(soft, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        bs.setFilterMode(BitmapShader.FILTER_MODE_LINEAR);
        return bs;
    }

    static Shader dummyShader() {
        Bitmap one = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        return new BitmapShader(one, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        if (w == 0 || h == 0) {
            return;
        }
        float sx = getScaleX();
        float ox = getX() + getPivotX() * (1f - sx);
        float oy = getY() + getPivotY() * (1f - getScaleY());

        // Światło przesuwa się razem z kartą: poruszanie karuzelą "obraca" odbicia.
        float cx = ox + w * sx * 0.5f;
        float dx = (cx - env.screenW * 0.5f) / env.screenW;
        float lx = -0.6f + dx * 0.9f;
        float ly = -0.8f;
        float ll = (float) Math.hypot(lx, ly);

        shader.setInputShader("bg", env.hasBg && env.bg != null ? env.bg : dummy());
        shader.setFloatUniform("size", w, h);
        shader.setFloatUniform("origin", ox, oy);
        shader.setFloatUniform("s", sx);
        shader.setFloatUniform("k", env.k);
        shader.setFloatUniform("radius", env.radiusPx);
        shader.setFloatUniform("refr", env.refract);
        shader.setFloatUniform("shine", env.shine);
        shader.setFloatUniform("disp", env.dispersion);
        shader.setFloatUniform("hasBg", env.hasBg ? 1f : 0f);
        shader.setFloatUniform("dark", env.dark ? 1f : 0f);
        shader.setFloatUniform("dimK", env.dimK);
        shader.setFloatUniform("lightDir", lx / ll, ly / ll);
        shader.setFloatUniform("tint", env.tint[0], env.tint[1], env.tint[2], env.tint[3]);

        paint.setShader(shader);
        canvas.drawRect(0, 0, w, h, paint);
    }

    private Shader dummy() {
        if (env.dummy == null) {
            env.dummy = dummyShader();
        }
        return env.dummy;
    }
}
