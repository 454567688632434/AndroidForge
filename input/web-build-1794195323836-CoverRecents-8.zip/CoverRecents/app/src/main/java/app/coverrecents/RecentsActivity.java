package app.coverrecents;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Outline;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.WindowInsets;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * Ekran ostatnich aplikacji.
 *
 * Style: One UI (karty z paletą Samsunga), Liquid glass (shader AGSL, patrz GlassCard) oraz
 * Podgląd aplikacji (miniatura zawartości z ikoną nad kartą, jak na dużym ekranie Samsunga).
 * Układ: karuzela (przesunięcie karty w górę zamyka) albo siatka (przesunięcie w bok zamyka).
 */
public class RecentsActivity extends Activity {

    private static final String TAG = "CoverRecents";

    private final List<RecentApps.App> items = new ArrayList<>();

    private FrameLayout root;
    private ImageView bgView;
    private RecyclerView list;
    private TextView emptyView;
    private Adapter adapter;
    private Look.Colors colors;
    private Look.Anim anim;
    private GlassCard.Env glassEnv;

    private boolean grid;
    private boolean labels;
    private boolean glass;
    private boolean preview;
    private boolean border;
    private int cardAlpha;
    private float density;
    private int screenW;
    private int cardWidth;
    private int cardHeight;
    private int cellWidth;
    private int headerH;
    private int radiusPx;

    // animacja wejścia
    private boolean entering;
    private float enterT;
    private int enterTotal;
    private ValueAnimator enterAnimator;
    private boolean backdropDone;
    private int scrimColor;
    private int blurPx;
    private View closeBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        density = dm.density;
        screenW = dm.widthPixels;
        int w = dm.widthPixels;
        int h = dm.heightPixels;
        grid = Prefs.isGrid(this);
        labels = Prefs.showLabels(this);
        String style = Prefs.style(this);
        glass = Prefs.STYLE_GLASS.equals(style);
        preview = Prefs.STYLE_PREVIEW.equals(style);
        border = Prefs.b(this, Prefs.BORDER, false);
        cardAlpha = Prefs.i(this, Prefs.CARD_ALPHA, 100);
        radiusPx = dp(Prefs.radiusDp(this));
        colors = Look.colors(this);
        anim = Look.anim(Prefs.anim(this));

        // Treść pod paskami systemowymi: układ pokrywa się ze zrzutem ekranu (potrzebne szkłu).
        getWindow().setDecorFitsSystemWindows(false);

        // Tło okna: przyciemnienie + rozmycie tego, co jest za oknem (compositor).
        boolean blurOn = getWindowManager().isCrossWindowBlurEnabled();
        float dim = Prefs.dim(this) / 100f;
        if (!blurOn) {
            dim = Math.max(dim, 0.78f);
        }
        scrimColor = (Math.round(dim * 255) << 24) | colors.scrimRgb;
        int blurDp = Prefs.blurDp(this);
        blurPx = blurOn && blurDp > 0 ? dp(blurDp) : 0;
        applyWindowBackdrop();

        root = new FrameLayout(this);

        bgView = new ImageView(this);
        bgView.setScaleType(ImageView.ScaleType.FIT_XY);
        bgView.setVisibility(View.GONE);
        root.addView(bgView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        list = new RecyclerView(this);
        list.setClipToPadding(false);
        list.setOverScrollMode(View.OVER_SCROLL_NEVER);
        adapter = new Adapter();
        list.setAdapter(adapter);

        headerH = preview ? dp(grid ? 30 : 44) : 0;
        if (grid) {
            int columns = Math.max(2, Math.min(4, Prefs.columns(this)));
            int side = dp(12);
            cellWidth = (w - 2 * side) / columns;
            cardHeight = preview ? Math.round(cellWidth * 1.05f) : 0;
            list.setLayoutManager(new GridLayoutManager(this, columns));
            list.setPadding(side, dp(40), side, dp(96));
        } else {
            cardWidth = Math.round(w * 0.60f);
            cardHeight = preview
                    ? Math.min(Math.round(cardWidth * (h / (float) w)), Math.round(h * 0.62f))
                    : Math.round(h * 0.62f);
            int total = cardHeight + headerH;
            int sidePad = Math.max(0, (w - cardWidth) / 2 - dp(8));
            int topPad = Math.max(dp(16), (h - total) / 2 - dp(24));
            list.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
            list.setPadding(sidePad, topPad, sidePad, 0);
            new LinearSnapHelper().attachToRecyclerView(list);
        }
        root.addView(list, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        emptyView = new TextView(this);
        emptyView.setTextColor(colors.textDim);
        emptyView.setTextSize(16);
        emptyView.setGravity(Gravity.CENTER);
        emptyView.setPadding(dp(32), 0, dp(32), 0);
        root.addView(emptyView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));

        if (Prefs.showCloseAll(this)) {
            closeBtn = buildCloseButton();
            root.addView(closeBtn, closeParams());
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) closeBtn.getLayoutParams();
                lp.bottomMargin = dp(20) + insets.getInsets(WindowInsets.Type.systemBars()).bottom;
                closeBtn.setLayoutParams(lp);
                return insets;
            });
        }

        setContentView(root);

        if (glass) {
            setupGlass(w);
        }

        setupSwipe();
        setupTransforms();
    }

    /** Przyciemnienie + rozmycie tego, co jest za oknem (compositor systemu). */
    private void applyWindowBackdrop() {
        Window window = getWindow();
        window.setBackgroundDrawable(new ColorDrawable(scrimColor));
        window.setBackgroundBlurRadius(blurPx);
    }

    private FrameLayout.LayoutParams closeParams() {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                dp(56), dp(56), Gravity.BOTTOM | Gravity.START);
        lp.setMargins(dp(20), 0, 0, dp(28));
        return lp;
    }

    private View buildCloseButton() {
        ImageButton close = new ImageButton(this);
        close.setImageResource(R.drawable.ic_close);
        close.setColorFilter(colors.closeIcon);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(colors.closeBg);
        if (glass) {
            bg.setStroke(dp(1), colors.dark ? 0x55FFFFFF : 0xCCFFFFFF);
        }
        close.setBackground(bg);
        close.setContentDescription("Zamknij wszystkie");
        close.setOnClickListener(v -> closeAll());
        return close;
    }

    // ---- gesty ----

    private void setupSwipe() {
        int swipeDirs = grid
                ? (ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT)
                : ItemTouchHelper.UP;
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, swipeDirs) {
            @Override
            public boolean onMove(RecyclerView rv, RecyclerView.ViewHolder vh,
                                  RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder vh, int direction) {
                int pos = vh.getBindingAdapterPosition();
                if (pos == RecyclerView.NO_POSITION) {
                    return;
                }
                RecentApps.App app = items.remove(pos);
                adapter.notifyItemRemoved(pos);
                RecentApps.close(RecentsActivity.this, app.pkg);
                updateEmpty();
            }

            @Override
            public void onChildDraw(android.graphics.Canvas c, RecyclerView rv,
                                    RecyclerView.ViewHolder vh, float dX, float dY,
                                    int actionState, boolean active) {
                super.onChildDraw(c, rv, vh, dX, dY, actionState, active);
                if (glass) {
                    vh.itemView.invalidate(); // szkło musi przeliczyć położenie względem tła
                }
            }
        }).attachToRecyclerView(list);

        // Dotknięcie pustego tła zamyka ekran (jak w Samsungu).
        final GestureDetector tap = new GestureDetector(this,
                new GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onSingleTapUp(MotionEvent e) {
                        if (list.findChildViewUnder(e.getX(), e.getY()) == null) {
                            finishAnimated();
                        }
                        return false;
                    }
                });
        list.addOnItemTouchListener(new RecyclerView.SimpleOnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {
                tap.onTouchEvent(e);
                return false;
            }
        });
    }

    // ---- animacje: transformacje kart zależne od odległości od środka + wejście ----

    private void setupTransforms() {
        // Przed każdą klatką ustawiamy transformacje widocznych kart (kilka widoków, tanio).
        list.getViewTreeObserver().addOnPreDrawListener(() -> {
            applyTransforms();
            return true;
        });
        if (glass) {
            list.addOnScrollListener(new RecyclerView.OnScrollListener() {
                @Override
                public void onScrolled(RecyclerView rv, int dx, int dy) {
                    invalidateGlass();
                }
            });
        }
    }

    private void invalidateGlass() {
        if (!glass) {
            return;
        }
        for (int i = 0; i < list.getChildCount(); i++) {
            list.getChildAt(i).invalidate();
        }
    }

    private static float clamp01(float v) {
        return v < 0f ? 0f : Math.min(v, 1f);
    }

    private void applyTransforms() {
        boolean carouselFx = !grid && (anim.scaleMin < 1f || anim.alphaMin < 1f
                || anim.rotY > 0f || anim.overlap > 0f);
        if (!carouselFx && !entering) {
            return;
        }
        if (list.isAnimating()) {
            return; // nie przeszkadzamy animacji usuwania/przesuwania kart
        }
        float cx = list.getWidth() / 2f;
        float step = cardWidth + dp(16);
        for (int i = 0; i < list.getChildCount(); i++) {
            View v = list.getChildAt(i);
            float d = 0f;
            float sc = 1f;
            float al = 1f;
            float rot = 0f;
            float tx = 0f;
            if (carouselFx) {
                d = ((v.getLeft() + v.getRight()) / 2f - cx) / step;
                float t = Math.min(1f, Math.abs(d));
                float sg = Math.signum(d);
                sc = 1f - (1f - anim.scaleMin) * t;
                al = 1f - (1f - anim.alphaMin) * t;
                rot = -sg * anim.rotY * t;
                tx = -sg * anim.overlap * cardWidth * t;
            }
            float ty = 0f;
            if (entering) {
                int rank = grid
                        ? Math.min(Math.max(list.getChildAdapterPosition(v), 0), 9)
                        : Math.round(Math.abs(d));
                float raw = clamp01((enterT * enterTotal - rank * anim.stagger) / anim.enterMs);
                float e = anim.enter.getInterpolation(raw);
                al *= clamp01(e * 1.4f);
                sc *= anim.enterScale + (1f - anim.enterScale) * e;
                ty = (1f - e) * anim.enterY * density;
                rot += (1f - e) * anim.enterRot * (d >= 0 ? -1f : 1f);
            }
            if (v.getScaleX() != sc) {
                v.setScaleX(sc);
                v.setScaleY(sc);
            }
            if (v.getAlpha() != al) {
                v.setAlpha(al);
            }
            if (v.getRotationY() != rot) {
                v.setRotationY(rot);
            }
            if (v.getTranslationX() != tx) {
                v.setTranslationX(tx);
            }
            if (entering) {
                v.setTranslationY(ty);
            }
        }
    }

    private void startEnter() {
        if (enterAnimator != null) {
            enterAnimator.cancel();
        }
        if (anim.enterMs <= 0) {
            entering = false;
            return;
        }
        entering = true;
        enterT = 0f;
        enterTotal = anim.enterMs + anim.stagger * (grid ? 9 : 2);
        enterAnimator = ValueAnimator.ofFloat(0f, 1f);
        enterAnimator.setDuration(enterTotal);
        enterAnimator.setInterpolator(null); // liniowo, krzywe są liczone per karta
        enterAnimator.addUpdateListener(a -> {
            enterT = (float) a.getAnimatedValue();
            list.invalidate();
            invalidateGlass();
        });
        enterAnimator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                entering = false;
                for (int i = 0; i < list.getChildCount(); i++) {
                    list.getChildAt(i).setTranslationY(0f);
                }
                applyTransforms();
            }
        });
        enterAnimator.start();
    }

    // ---- liquid glass: zrzut tła i środowisko shadera ----

    private void setupGlass(int w) {
        glassEnv = new GlassCard.Env();
        glassEnv.dark = colors.dark;
        glassEnv.screenW = w;
        glassEnv.radiusPx = radiusPx;
        glassEnv.refract = Prefs.i(this, Prefs.GLASS_REFRACT, 60) / 100f;
        glassEnv.shine = Prefs.i(this, Prefs.GLASS_SHINE, 60) / 100f;
        glassEnv.dispersion = Prefs.b(this, Prefs.GLASS_DISPERSION, true) ? 1f : 0f;
        float[] t = glassEnv.tint;
        if (colors.accent != 0) {
            t[0] = ((colors.accent >> 16) & 0xFF) / 255f;
            t[1] = ((colors.accent >> 8) & 0xFF) / 255f;
            t[2] = (colors.accent & 0xFF) / 255f;
            t[3] = 0.16f;
        } else if (colors.dark) {
            t[0] = 0.10f;
            t[1] = 0.10f;
            t[2] = 0.12f;
            t[3] = 0.16f;
        } else {
            t[0] = 1f;
            t[1] = 1f;
            t[2] = 1f;
            t[3] = 0.20f;
        }

        // Bez zrzutu tła ekran pokazuje się od razu; ze zrzutem czekamy chwilę (max ~0,5 s).
        Bitmap handed = Snapshots.takeHandoff();
        if (handed != null) {
            useBackdrop(handed);
            return;
        }
        RecentsService svc = RecentsService.instance;
        if (svc == null) {
            backdropDone = true;
            return;
        }
        root.setAlpha(0f);
        // Okno musi być czyste, inaczej zrzut zawierałby już nasze przyciemnienie.
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        getWindow().setBackgroundBlurRadius(0);
        Display d = getDisplay();
        svc.grab(d != null ? d.getDisplayId() : CoverLauncher.COVER_DISPLAY_ID, null, this::useBackdrop);
        root.postDelayed(() -> useBackdrop(null), 500);
    }

    private void useBackdrop(Bitmap shot) {
        if (backdropDone) {
            return;
        }
        backdropDone = true;
        if (shot != null) {
            // Tło rysujemy sami (rozmycie GPU + przyciemnienie), żeby szkło mogło je załamywać.
            float dim = Prefs.dim(this) / 100f;
            int scrim = (Math.round(dim * 255) << 24) | colors.scrimRgb;
            bgView.setImageBitmap(shot);
            bgView.setColorFilter(new PorterDuffColorFilter(scrim, PorterDuff.Mode.SRC_ATOP));
            float blur = Math.max(1f, dp(Prefs.blurDp(this)) * 0.5f);
            bgView.setRenderEffect(RenderEffect.createBlurEffect(blur, blur, Shader.TileMode.CLAMP));
            bgView.setVisibility(View.VISIBLE);
            getWindow().setBackgroundDrawable(new ColorDrawable(0xFF000000));
            getWindow().setBackgroundBlurRadius(0);

            Bitmap soft = Bitmap.createScaledBitmap(shot,
                    Math.max(1, shot.getWidth() / 2), Math.max(1, shot.getHeight() / 2), true);
            glassEnv.bg = GlassCard.makeBackdropShader(soft);
            glassEnv.k = soft.getWidth() / (float) screenW;
            glassEnv.dimK = dim * 0.55f;
            glassEnv.hasBg = true;
            invalidateGlass();
        }
        if (shot == null) {
            applyWindowBackdrop();
        }
        if (root.getAlpha() < 1f) {
            root.animate().alpha(1f).setDuration(140).setInterpolator(Look.SINE_33).start();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        reload();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (enterAnimator != null) {
            enterAnimator.cancel();
        }
        // Jak systemowe ostatnie: po wyjściu (home, wygaszenie, start aplikacji) ekran znika.
        if (!isChangingConfigurations()) {
            finish();
        }
    }

    // ---- tła kart ----

    private GradientDrawable cardBackground(int radius) {
        GradientDrawable d = new GradientDrawable();
        int a = Math.round(255 * cardAlpha / 100f);
        d.setColor((a << 24) | (colors.card & 0x00FFFFFF));
        d.setCornerRadius(radius);
        if (border || colors.amoled) {
            d.setStroke(dp(1), colors.stroke);
        }
        return d;
    }

    // ---- dane i akcje ----

    private void reload() {
        items.clear();
        items.addAll(RecentApps.load(this, Prefs.maxApps(this)));
        entering = anim.enterMs > 0 && !items.isEmpty();
        enterT = 0f;
        adapter.notifyDataSetChanged();
        updateEmpty();
        if (!items.isEmpty()) {
            startEnter();
        }
    }

    private void updateEmpty() {
        boolean none = items.isEmpty();
        emptyView.setVisibility(none ? View.VISIBLE : View.GONE);
        if (none) {
            emptyView.setText(RecentApps.hasUsageAccess(this)
                    ? "Brak ostatnich aplikacji"
                    : "Przyznaj dostęp do użycia w aplikacji Cover Recents (na ekranie głównym telefonu)");
        }
    }

    private void finishAnimated() {
        if (anim.enterMs <= 0) {
            finish();
            return;
        }
        root.animate().alpha(0f).setDuration(180).setInterpolator(Look.SINE_70)
                .withEndAction(this::finish).start();
    }

    private void closeAll() {
        // Zamykamy też aplikacje starsze niż te widoczne na liście.
        for (RecentApps.App app : RecentApps.load(this, Integer.MAX_VALUE)) {
            RecentApps.close(this, app.pkg);
        }
        items.clear();
        adapter.notifyDataSetChanged();
        list.animate().alpha(0f).setDuration(160).withEndAction(this::finish).start();
    }

    private void launch(RecentApps.App app) {
        Intent intent = getPackageManager().getLaunchIntentForPackage(app.pkg);
        if (intent == null) {
            Toast.makeText(this, "Nie można uruchomić: " + app.label, Toast.LENGTH_SHORT).show();
            return;
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        ActivityOptions options = ActivityOptions.makeBasic();
        Display display = getDisplay();
        if (display != null) {
            options.setLaunchDisplayId(display.getDisplayId());
        }
        try {
            startActivity(intent, options.toBundle());
        } catch (RuntimeException e) {
            Log.w(TAG, "Start z wymuszonym ekranem nie powiódł się, próbuję domyślnie", e);
            try {
                startActivity(intent);
            } catch (RuntimeException e2) {
                Log.e(TAG, "Nie udało się uruchomić " + app.pkg, e2);
                Toast.makeText(this, "Nie można uruchomić: " + app.label, Toast.LENGTH_SHORT).show();
                return;
            }
        }
        finish();
    }

    private int dp(int value) {
        return Math.round(value * density);
    }

    private static final class Holder extends RecyclerView.ViewHolder {
        final ImageView icon;     // ikona (w podglądzie: mała, nad kartą)
        final TextView label;
        final ImageView big;      // duża ikona (karty bez podglądu / brak miniatury)
        final ImageView shot;     // miniatura (tylko styl z podglądem)
        String pkg;

        Holder(View itemView, ImageView icon, TextView label, ImageView big, ImageView shot) {
            super(itemView);
            this.icon = icon;
            this.label = label;
            this.big = big;
            this.shot = shot;
        }
    }

    private final class Adapter extends RecyclerView.Adapter<Holder> {

        @Override
        public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
            return preview ? createPreviewHolder() : createCardHolder();
        }

        private RecyclerView.LayoutParams itemParams(int width, int height) {
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(width, height);
            if (grid) {
                lp.setMargins(dp(4), dp(6), dp(4), dp(6));
            } else {
                lp.setMargins(dp(8), 0, dp(8), 0);
            }
            return lp;
        }

        /** One UI / szkło: karta z dużą ikoną i nazwą. */
        private Holder createCardHolder() {
            LinearLayout card = glass
                    ? new GlassCard(RecentsActivity.this, glassEnv)
                    : new LinearLayout(RecentsActivity.this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER);
            int iconSize;
            if (grid) {
                iconSize = dp(56);
                card.setPadding(dp(4), dp(12), dp(4), dp(12));
                card.setLayoutParams(itemParams(cellWidth - dp(8), ViewGroup.LayoutParams.WRAP_CONTENT));
            } else {
                iconSize = dp(96);
                card.setLayoutParams(itemParams(cardWidth, cardHeight));
            }
            if (!glass) {
                int r = grid ? Math.round(radiusPx * 0.75f) : radiusPx;
                card.setBackground(cardBackground(r));
                if (!grid) {
                    card.setElevation(dp(6));
                }
            }

            ImageView icon = new ImageView(RecentsActivity.this);
            card.addView(icon, new LinearLayout.LayoutParams(iconSize, iconSize));
            TextView label = makeLabel(grid ? 12 : 17, grid ? 6 : 14);
            card.addView(label, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            return new Holder(card, icon, label, icon, null);
        }

        /** Podgląd aplikacji: ikona + nazwa nad miniaturą zawartości, jak w Samsungu. */
        private Holder createPreviewHolder() {
            LinearLayout item = new LinearLayout(RecentsActivity.this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER_HORIZONTAL);
            int width = grid ? cellWidth - dp(8) : cardWidth;
            item.setLayoutParams(itemParams(width, grid
                    ? ViewGroup.LayoutParams.WRAP_CONTENT : cardHeight + headerH));

            LinearLayout header = new LinearLayout(RecentsActivity.this);
            header.setOrientation(LinearLayout.HORIZONTAL);
            header.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
            int iconSize = dp(grid ? 20 : 30);
            ImageView icon = new ImageView(RecentsActivity.this);
            header.addView(icon, new LinearLayout.LayoutParams(iconSize, iconSize));
            TextView label = makeLabel(grid ? 11 : 15, 0);
            label.setPadding(dp(8), 0, 0, 0);
            label.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            header.addView(label, llp);
            item.addView(header, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, headerH));

            FrameLayout card = new FrameLayout(RecentsActivity.this);
            final int r = grid ? Math.round(radiusPx * 0.7f) : radiusPx;
            card.setBackground(cardBackground(r));
            card.setOutlineProvider(new ViewOutlineProvider() {
                @Override
                public void getOutline(View view, Outline outline) {
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), r);
                }
            });
            card.setClipToOutline(true);
            card.setElevation(dp(grid ? 3 : 6));

            ImageView big = new ImageView(RecentsActivity.this);
            int bigSize = dp(grid ? 44 : 80);
            card.addView(big, new FrameLayout.LayoutParams(bigSize, bigSize, Gravity.CENTER));
            ImageView shot = new ImageView(RecentsActivity.this);
            shot.setScaleType(ImageView.ScaleType.CENTER_CROP);
            shot.setVisibility(View.GONE);
            card.addView(shot, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            item.addView(card, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, cardHeight));
            return new Holder(item, icon, label, big, shot);
        }

        private TextView makeLabel(int sp, int topPadDp) {
            TextView label = new TextView(RecentsActivity.this);
            label.setTextColor(colors.text);
            label.setMaxLines(1);
            label.setEllipsize(TextUtils.TruncateAt.END);
            label.setGravity(Gravity.CENTER);
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
            label.setPadding(dp(8), dp(topPadDp), dp(8), 0);
            label.setVisibility(labels ? View.VISIBLE : View.GONE);
            return label;
        }

        @Override
        public void onBindViewHolder(Holder holder, int position) {
            RecentApps.App app = items.get(position);
            holder.pkg = app.pkg;
            holder.icon.setImageDrawable(app.icon);
            holder.label.setText(app.label);
            holder.itemView.setOnClickListener(v -> {
                int p = holder.getBindingAdapterPosition();
                if (p != RecyclerView.NO_POSITION) {
                    launch(items.get(p));
                }
            });
            if (holder.shot != null) {
                holder.big.setImageDrawable(app.icon);
                holder.big.setVisibility(View.VISIBLE);
                holder.shot.setVisibility(View.GONE);
                holder.shot.setImageDrawable(null);
                Bitmap cached = Snapshots.cached(app.pkg);
                if (cached != null) {
                    showShot(holder, cached, false);
                } else {
                    Snapshots.loadAsync(RecentsActivity.this, app.pkg, bmp -> {
                        if (bmp != null && app.pkg.equals(holder.pkg)) {
                            showShot(holder, bmp, true);
                        }
                    });
                }
            }
        }

        private void showShot(Holder h, Bitmap bmp, boolean fade) {
            h.shot.setImageBitmap(bmp);
            h.shot.setVisibility(View.VISIBLE);
            h.big.setVisibility(View.GONE);
            if (fade) {
                h.shot.setAlpha(0f);
                h.shot.animate().alpha(1f).setDuration(160).start();
            } else {
                h.shot.setAlpha(1f);
            }
        }

        @Override
        public int getItemCount() {
            return items.size();
        }
    }
}
