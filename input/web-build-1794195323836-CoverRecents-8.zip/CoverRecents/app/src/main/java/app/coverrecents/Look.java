package app.coverrecents;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.view.animation.Interpolator;
import android.view.animation.PathInterpolator;

/**
 * Paleta i ruch w duchu One UI.
 *
 * Samsung nie publikuje oficjalnej tabeli kolorów dla aplikacji firm trzecich, więc wartości
 * to odwzorowanie One UI (niebieski akcent, czerń i #252525 w trybie ciemnym, #F6F6F6 / biel w
 * jasnym) oraz kolorów obudowy Galaxy Z Flip5 (Mint, Lavender, Cream, Graphite).
 */
final class Look {

    private Look() {
    }

    // ---- paleta ----

    static final int ONEUI_BLUE = 0xFF3E91FF;

    static final String[] ACCENT_KEYS = {"none", "blue", "mint", "lavender", "cream", "graphite"};
    static final String[] ACCENT_NAMES = {"Neutralny", "Samsung Blue", "Mint", "Lavender", "Cream", "Graphite"};
    static final int[] ACCENT_COLORS = {0, ONEUI_BLUE, 0xFFA8D5BE, 0xFFB7A8D8, 0xFFE9DFC9, 0xFF4A4D55};

    /** Zaokrąglenia kart (dp): od ostrych do pełnych, 28 dp to domyślne One UI. */
    static final int[] RADII = {12, 20, 28, 36, 44};
    static final String[] RADIUS_NAMES = {"Ostre", "Małe", "One UI", "Duże", "Pełne"};

    static int accentColor(String key) {
        for (int i = 0; i < ACCENT_KEYS.length; i++) {
            if (ACCENT_KEYS[i].equals(key)) {
                return ACCENT_COLORS[i];
            }
        }
        return 0;
    }

    static int blend(int base, int over, float a) {
        int r = Math.round(Color.red(base) * (1 - a) + Color.red(over) * a);
        int g = Math.round(Color.green(base) * (1 - a) + Color.green(over) * a);
        int b = Math.round(Color.blue(base) * (1 - a) + Color.blue(over) * a);
        return Color.rgb(r, g, b);
    }

    static boolean isNight(Context c) {
        return (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
    }

    static final class Colors {
        boolean dark;
        boolean amoled;
        int accent;      // 0 = brak
        int scrimRgb;
        int card;        // bez przezroczystości
        int text;
        int textDim;
        int stroke;
        int closeBg;
        int closeIcon;
    }

    static Colors colors(Context c) {
        String theme = Prefs.theme(c);
        Colors k = new Colors();
        k.amoled = Prefs.THEME_AMOLED.equals(theme);
        k.dark = k.amoled || Prefs.THEME_DARK.equals(theme)
                || (Prefs.THEME_SYSTEM.equals(theme) && isNight(c));
        k.accent = accentColor(Prefs.accent(c));

        k.scrimRgb = k.dark ? 0x000000 : 0xF6F6F6;
        int card = k.amoled ? 0x121212 : (k.dark ? 0x252525 : 0xFFFFFF);
        if (k.accent != 0) {
            card = blend(card, k.accent, k.dark ? 0.18f : 0.22f);
        }
        k.card = 0xFF000000 | card;
        k.text = k.dark ? 0xFFFFFFFF : 0xFF000000;
        k.textDim = k.dark ? 0xFFA8A8A8 : 0xFF6F6F6F;
        k.stroke = k.dark ? 0x2AFFFFFF : 0x1F000000;
        if (k.accent != 0) {
            k.closeBg = k.accent;
            boolean lightAccent = Color.luminance(k.accent) > 0.55f;
            k.closeIcon = lightAccent ? 0xFF000000 : 0xFFFFFFFF;
        } else {
            k.closeBg = k.dark ? 0x33FFFFFF : 0x1F000000;
            k.closeIcon = k.dark ? 0xFFFFFFFF : 0xFF000000;
        }
        return k;
    }

    // ---- ruch ----

    /** Krzywe sinusoidalne Samsunga (SineInOut33/70) i krzywa ekranu Apple. */
    static final Interpolator SINE_33 = new PathInterpolator(0.33f, 0f, 0.67f, 1f);
    static final Interpolator SINE_70 = new PathInterpolator(0.33f, 0f, 0.7f, 1f);
    static final Interpolator APPLE_OUT = new PathInterpolator(0.22f, 1f, 0.36f, 1f);

    /** Sprężyna z lekkim przeregulowaniem, jak animacje iOS (dampingRatio ~0.82, response ~0.5 s). */
    static final class Spring implements Interpolator {
        private final float zeta;
        private final float wn;
        private final float wd;
        private final float seconds;

        Spring(float zeta, float response, float seconds) {
            this.zeta = zeta;
            this.wn = (float) (2 * Math.PI / response);
            this.wd = (float) (wn * Math.sqrt(1 - zeta * zeta));
            this.seconds = seconds;
        }

        @Override
        public float getInterpolation(float input) {
            if (input >= 1f) {
                return 1f;
            }
            float t = input * seconds;
            double env = Math.exp(-zeta * wn * t);
            return (float) (1 - env * (Math.cos(wd * t) + (zeta * wn / wd) * Math.sin(wd * t)));
        }
    }

    /** Parametry animacji karuzeli i wejścia. */
    static final class Anim {
        float scaleMin = 1f;   // skala kart po bokach
        float alphaMin = 1f;
        float rotY = 0f;       // obrót kart po bokach (stopnie)
        float overlap = 0f;    // nachodzenie kart na siebie (ułamek szerokości)
        float enterScale = 1f;
        float enterY = 0f;     // dp
        float enterRot = 0f;
        int enterMs = 0;       // 0 = bez animacji wejścia
        int stagger = 0;
        Interpolator enter = SINE_33;
    }

    static Anim anim(String key) {
        Anim a = new Anim();
        switch (key) {
            case Prefs.ANIM_IOS:
                a.scaleMin = 0.86f;
                a.alphaMin = 0.78f;
                a.overlap = 0.05f;
                a.enterScale = 0.88f;
                a.enterY = 96f;
                a.enterMs = 560;
                a.stagger = 38;
                a.enter = new Spring(0.82f, 0.5f, 0.56f);
                break;
            case Prefs.ANIM_FLOW:
                a.scaleMin = 0.80f;
                a.alphaMin = 0.85f;
                a.rotY = 38f;
                a.overlap = 0.20f;
                a.enterScale = 0.85f;
                a.enterY = 40f;
                a.enterRot = 50f;
                a.enterMs = 460;
                a.stagger = 45;
                a.enter = APPLE_OUT;
                break;
            case Prefs.ANIM_NONE:
                break;
            default:
                a.scaleMin = 0.90f;
                a.alphaMin = 0.55f;
                a.enterScale = 0.94f;
                a.enterY = 24f;
                a.enterMs = 340;
                a.stagger = 28;
                a.enter = SINE_33;
                break;
        }
        return a;
    }
}
