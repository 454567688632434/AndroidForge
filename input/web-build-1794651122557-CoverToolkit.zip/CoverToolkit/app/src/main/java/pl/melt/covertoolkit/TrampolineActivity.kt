package pl.melt.covertoolkit

import android.app.Activity
import android.os.Bundle
import android.widget.Toast

/**
 * Niewidoczny pośrednik. Kafelek widgetu otwiera go (już na cover screenie),
 * a on próbuje uruchomić właściwy cel na ekranie 1 i od razu się zamyka.
 */
class TrampolineActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val preset = Presets.byId(intent.getStringExtra(EXTRA_PRESET))
        if (preset != null) {
            val r = CoverLaunch.launchPreset(this, preset)
            if (!r.ok) {
                Toast.makeText(applicationContext, "${preset.title}: nie wyszło\n${r.message}", Toast.LENGTH_LONG).show()
            }
        }
        finish()
    }

    companion object {
        const val EXTRA_PRESET = "preset"
    }
}
