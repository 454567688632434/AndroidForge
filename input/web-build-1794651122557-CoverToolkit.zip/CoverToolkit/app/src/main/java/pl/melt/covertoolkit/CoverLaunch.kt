package pl.melt.covertoolkit

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle

/**
 * Rdzeń całego toolkitu: uruchamianie dowolnej aktywności na wskazanym ekranie
 * (cover screen Z Flip 5 = display o id 1) przez ActivityOptions.setLaunchDisplayId.
 */
object CoverLaunch {

    const val COVER_DISPLAY_ID = 1

    class Result(val ok: Boolean, val message: String)

    fun options(displayId: Int = COVER_DISPLAY_ID): Bundle =
        ActivityOptions.makeBasic().setLaunchDisplayId(displayId).toBundle()

    /** Zwraca null, gdy start się udał, albo wyjątek, który system rzucił. */
    fun startIntent(ctx: Context, intent: Intent, displayId: Int = COVER_DISPLAY_ID): Throwable? {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent, options(displayId))
            null
        } catch (t: Throwable) {
            t
        }
    }

    fun adbFor(cn: ComponentName): String =
        "am start --display $COVER_DISPLAY_ID -n ${cn.flattenToShortString()}"

    /** Próbuje kolejnych sposobów z presetu (najpierw własny cel użytkownika), aż któryś ruszy. */
    fun launchPreset(ctx: Context, preset: Preset, displayId: Int = COVER_DISPLAY_ID): Result {
        val tries = ArrayList<Candidate>()

        val custom = Prefs.getOverride(ctx, preset.id)
        if (custom != null) {
            tries.add(
                Candidate("własny cel ${custom.flattenToShortString()}", adbFor(custom)) {
                    Intent().setComponent(custom)
                }
            )
        }
        tries.addAll(preset.candidates)

        val log = StringBuilder()
        for (cand in tries) {
            val intent: Intent? = try {
                cand.make(ctx)
            } catch (t: Throwable) {
                null
            }
            if (intent == null) {
                log.append("• ").append(cand.label).append(": nie ma tego na telefonie\n")
                continue
            }
            val err = startIntent(ctx, intent, displayId)
            if (err == null) {
                return Result(true, cand.label)
            }
            log.append("• ").append(cand.label).append(": ").append(err.javaClass.simpleName).append('\n')
        }
        return Result(false, log.toString().trim())
    }
}
