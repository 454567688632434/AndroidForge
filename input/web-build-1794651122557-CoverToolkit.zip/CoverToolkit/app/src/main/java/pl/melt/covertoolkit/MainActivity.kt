package pl.melt.covertoolkit

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.provider.Settings
import android.view.Display
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Ekran na dużym wyświetlaczu: start, diagnostyka ekranów, testy każdego kafelka, ADB, narzędzia. */
class MainActivity : Activity() {

    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(getColor(R.color.bg))

        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(24), dp(16), dp(32))
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        root.removeAllViews()
        build()
    }

    // ---------- widok ----------

    private fun build() {
        root.addView(label("Cover Toolkit", 28f, R.color.text, true))
        root.addView(label("Z Flip 5 · pełne apki i ustawienia na cover screenie", 14f, R.color.sub, false), lp(2))

        // Start
        root.addView(
            card(
                label("Start", 18f, R.color.text, true),
                label(
                    "1. Ustawienia → Ekran zewnętrzny (Cover screen) → Widgety.\n" +
                        "2. Włącz widget „Cover Toolkit”.\n" +
                        "3. Zamknij telefon i na cover screenie przesuń do widgetu. Każdy kafelek odpala swoją rzecz od razu na małym ekranie.",
                    14f, R.color.sub, false,
                ),
                button("Otwórz Ustawienia") { startActivity(Intent(Settings.ACTION_SETTINGS)) },
            ),
            lp(16),
        )

        // Diagnostyka
        root.addView(
            card(
                label("Ekrany i Good Lock", 18f, R.color.text, true),
                label(displaysInfo(), 13f, R.color.sub, false),
                label(goodLockInfo(), 13f, R.color.sub, false),
            ),
            lp(12),
        )

        // Kafelki
        for (p in Presets.all) {
            root.addView(presetCard(p), lp(12))
        }

        // Narzędzia
        root.addView(
            card(
                label("Narzędzia", 18f, R.color.text, true),
                button("Apki Samsunga (lista)") {
                    startActivity(
                        Intent(this, PickerActivity::class.java)
                            .putExtra(PickerActivity.EXTRA_MODE, PickerActivity.MODE_SAMSUNG)
                    )
                },
                button("Odkrywca aktywności") {
                    startActivity(
                        Intent(this, PickerActivity::class.java)
                            .putExtra(PickerActivity.EXTRA_MODE, PickerActivity.MODE_ACTIVITIES)
                    )
                },
            ),
            lp(12),
        )

        // Uwagi
        root.addView(
            card(
                label("Dobrze wiedzieć", 18f, R.color.text, true),
                label(
                    "• Test z tego ekranu działa, gdy cover jest włączony (telefon zamknięty). Pewniej testować z widgetu.\n" +
                        "• „SecurityException” = ta aktywność jest prywatna. Użyj przycisku ADB i odpal ją przez Wireless debugging z komputera.\n" +
                        "• Panel szybki i widgety cover są sterowane przez SystemUI Samsunga. Toolkit otwiera edytory na małym ekranie, ale nie zmienia tego, które kafelki cover w ogóle akceptuje.",
                    13f, R.color.sub, false,
                ),
            ),
            lp(12),
        )
    }

    private fun presetCard(p: Preset): View {
        val children = ArrayList<View>()
        children.add(label(p.title, 18f, R.color.text, true))
        children.add(label(p.note, 13f, R.color.sub, false))

        val ov = Prefs.getOverride(this, p.id)
        if (ov != null) {
            children.add(label("Własny cel: " + ov.flattenToShortString(), 12f, R.color.sub, false))
        }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(smallButton("Na cover") { launchPreset(p, CoverLaunch.COVER_DISPLAY_ID) }, weight())
        row.addView(smallButton("Tu") { launchPreset(p, display?.displayId ?: Display.DEFAULT_DISPLAY) }, weight())
        row.addView(smallButton("ADB") { showAdb(p) }, weight())
        if (ov != null) {
            row.addView(smallButton("Wyczyść") {
                Prefs.setOverride(this, p.id, null)
                onResume()
            }, weight())
        }
        children.add(row)
        return card(*children.toTypedArray())
    }

    private fun launchPreset(p: Preset, displayId: Int) {
        val r = CoverLaunch.launchPreset(this, p, displayId)
        if (r.ok) {
            Toast.makeText(this, p.title + ": " + r.message, Toast.LENGTH_SHORT).show()
        } else {
            AlertDialog.Builder(this)
                .setTitle(p.title)
                .setMessage("Żaden sposób nie zadziałał:\n\n" + r.message)
                .setPositiveButton("OK", null)
                .show()
        }
    }

    private fun showAdb(p: Preset) {
        val cmds = p.candidates
            .filter { !it.adb.startsWith("(") }
            .joinToString("\n\n") { "# " + it.label + "\nadb shell " + it.adb }
        val text = if (cmds.isEmpty()) "Ten kafelek jest wewnętrzny, nie ma odpowiednika ADB." else cmds
        AlertDialog.Builder(this)
            .setTitle("ADB: " + p.title)
            .setMessage(text)
            .setPositiveButton("Kopiuj") { _, _ ->
                getSystemService(ClipboardManager::class.java)
                    .setPrimaryClip(ClipData.newPlainText("adb", text))
                Toast.makeText(this, "Skopiowano", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Zamknij", null)
            .show()
    }

    // ---------- diagnostyka ----------

    private fun displaysInfo(): String {
        val dm = getSystemService(DisplayManager::class.java)
        val sb = StringBuilder()
        for (d in dm.displays) {
            val m = d.mode
            sb.append("Ekran ").append(d.displayId).append(" · ").append(d.name).append(" · ")
                .append(m.physicalWidth).append("×").append(m.physicalHeight).append(" · ")
                .append(stateName(d.state)).append('\n')
        }
        sb.append("Cover screen Flipa 5 to zwykle ekran 1.")
        return sb.toString()
    }

    private fun stateName(s: Int): String = when (s) {
        Display.STATE_ON -> "włączony"
        Display.STATE_OFF -> "wyłączony"
        Display.STATE_DOZE, Display.STATE_DOZE_SUSPEND -> "doze"
        else -> "?"
    }

    private fun installed(p: String): Boolean = try {
        packageManager.getPackageInfo(p, PackageManager.PackageInfoFlags.of(0))
        true
    } catch (e: Exception) {
        false
    }

    private fun goodLockInfo(): String {
        fun s(p: String) = if (installed(p)) "jest" else "brak"
        return "Good Lock: " + s("com.samsung.android.goodlock") +
            " · QuickStar: " + s("com.samsung.android.qstuner") +
            " · MultiStar: " + s("com.samsung.android.multistar")
    }

    // ---------- małe pomocnicze klocki UI ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun lp(topDp: Int): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.topMargin = dp(topDp)
        return p
    }

    private fun weight(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    private fun label(s: String, sizeSp: Float, colorRes: Int, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = sizeSp
        t.setTextColor(getColor(colorRes))
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        t.setPadding(0, dp(2), 0, dp(2))
        return t
    }

    private fun button(s: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    private fun smallButton(s: String, onClick: () -> Unit): Button = button(s, onClick)

    private fun card(vararg children: View): LinearLayout {
        val cardColor = getColor(R.color.card)
        val bg = GradientDrawable()
        bg.setColor(cardColor)
        bg.cornerRadius = dp(24).toFloat()

        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        c.background = bg
        for (v in children) c.addView(v)
        return c
    }
}
