# Cover Toolkit (Galaxy Z Flip 5)

Jedna apka, jeden widget na cover screenie. Sześć kafelków odpala na małym ekranie to, co normalnie jest tylko na dużym:

| Kafelek | Co robi |
|---|---|
| Wiadomości | Domyślna apka SMS na cover screenie |
| Ustawienia | Pełne Ustawienia Samsunga na cover screenie |
| Odcisk palca | Kreator rejestracji biometrii (czytnik jest w bocznym przycisku) |
| Panel szybki | Próba otwarcia edycji przez Good Lock (QuickStar), w ostateczności Ustawienia |
| Widgety cover | Próba otwarcia edycji przez Good Lock (MultiStar), w ostateczności Ustawienia |
| Apki Samsunga | Lista apek Samsunga (lub wszystkich), dotknięcie = start na cover |

## Jak to działa

Mechanizm jest ten z dokumentacji Samsunga dla Flex Window: widget oznaczony `display="sub_screen"`,
którego kliknięcie startuje aktywność z `ActivityOptions.setLaunchDisplayId(1)`.
Każdy kafelek najpierw trafia do niewidocznej `TrampolineActivity`, a ta próbuje po kolei kilku sposobów
uruchomienia (np. dla Wiadomości: domyślna apka SMS, Samsung Messages, Google Messages) i zatrzymuje się na pierwszym, który ruszy.

## Budowanie APK

Nic nie trzeba instalować, jeśli użyjesz GitHuba:

1. Utwórz **prywatne** repo na GitHubie i wrzuć do niego całą zawartość tego folderu (razem z `.github/` i `toolkit.keystore`).
2. Zakładka **Actions → Build APK** (uruchomi się sama po pushu, albo kliknij *Run workflow*).
3. Po ok. 3-5 min pobierz artefakt **CoverToolkit-apk** i zainstaluj `app-release.apk` na telefonie.

Albo lokalnie: otwórz folder w Android Studio i `Build → Build Bundle(s) / APK(s) → Build APK(s)`
(lub `./gradlew assembleRelease`, wynik: `app/build/outputs/apk/release/`).

APK jest podpisany stałym kluczem z `toolkit.keystore`, więc kolejne wersje instalują się na wierzch bez odinstalowywania.
Klucz jest w repo celowo (to apka do własnego sideloadu), dlatego repo ma być prywatne.

## Uruchomienie na telefonie

1. Zainstaluj APK, otwórz **Cover Toolkit** na dużym ekranie.
2. **Ustawienia → Ekran zewnętrzny (Cover screen) → Widgety** i włącz widget *Cover Toolkit*.
3. Zamknij telefon, na cover screenie przesuń do widgetu.

Na głównym ekranie apki są też testy każdego kafelka, diagnostyka ekranów (czy cover to display 1),
lista Good Lock oraz komendy ADB.

## Jeśli coś nie ruszy

- **Nic się nie dzieje po dotknięciu kafelka**: sprawdź w apce (na dużym ekranie) przycisk *Na cover* przy tym kafelku, dostaniesz pełny log, który sposób zawiódł i dlaczego.
- **SecurityException**: aktywność jest prywatna i zwykła apka jej nie uruchomi. Użyj przycisku **ADB**, skopiuj komendę i odpal z komputera przez *Wireless debugging* (`adb shell am start --display 1 -n ...`).
- **Kafelek otwiera Ustawienia zamiast edytora**: konkretna aktywność edytora nie jest dostępna. Znajdź ją w **Odkrywcy aktywności** (wyszukiwarka po nazwie pakietu), przytrzymaj wynik → *Ustaw jako cel kafelka*. Od tej pory kafelek próbuje najpierw jej.
- **Panel szybki / widgety cover**: to, które kafelki i widgety cover w ogóle przyjmuje, decyduje SystemUI Samsunga. Toolkit otwiera edytory na małym ekranie, ale tego nie zmienia.
