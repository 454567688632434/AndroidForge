import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "pl.melt.covertoolkit"
    compileSdk = 35

    defaultConfig {
        applicationId = "pl.melt.covertoolkit"
        minSdk = 33          // Z Flip 5 wyszedł z Androidem 13
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }

    // Stały klucz, żeby każda kolejna wersja APK dawała się zainstalować "na wierzch" bez odinstalowywania.
    signingConfigs {
        create("toolkit") {
            storeFile = rootProject.file("toolkit.keystore")
            storePassword = "covertoolkit"
            keyAlias = "toolkit"
            keyPassword = "covertoolkit"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("toolkit")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("toolkit")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    // Shizuku = wireless debugging jako usługa: daje apce uprawnienia shella (am start --display 1 itd.)
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
