package pl.melt.covertoolkit

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle

/**
 * Rdzeń całego toolkitu: uruchamianie dowolnej aktywności na wskazanym ekranie
 * (cover screen Z Flip 5 = display o id 1) przez ActivityOptions.setLaunchDisplayId.
 */
object CoverLaunch {

    const val COVER_DISPLAY_ID = 1

    class Result(val ok: Boolean, val message: String)

    fun options(displayId: Int = COVER_DISPLAY_ID): Bundle =
        ActivityOptions.makeBasic().setLaunchDisplayId(displayId).toBundle()

    /** Zwraca null, gdy start się udał, albo wyjątek, który system rzucił. */
    fun startIntent(ctx: Context, intent: Intent, displayId: Int = COVER_DISPLAY_ID): Throwable? {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent, options(displayId))
            null
        } catch (t: Throwable) {
            t
        }
    }

    fun adbFor(cn: ComponentName): String =
        "am start --display $COVER_DISPLAY_ID -n ${cn.flattenToShortString()}"

    /** Próbuje kolejnych sposobów z presetu (najpierw własny cel użytkownika), aż któryś ruszy. */
    fun launchPreset(ctx: Context, preset: Preset, displayId: Int = COVER_DISPLAY_ID): Result {
        val tries = ArrayList<Candidate>()

        val custom = Prefs.getOverride(ctx, preset.id)
        if (custom != null) {
            tries.add(
                Candidate("własny cel ${custom.flattenToShortString()}", adbFor(custom)) {
                    Intent().setComponent(custom)
                }
            )
        }
        tries.addAll(preset.candidates)

        val log = StringBuilder()
        for (cand in tries) {
            val intent: Intent? = try {
                cand.make(ctx)
            } catch (t: Throwable) {
                null
            }
            if (intent == null) {
                log.append("• ").append(cand.label).append(": nie ma tego na telefonie\n")
                continue
            }
            val err = startIntent(ctx, intent, displayId)
            if (err == null) {
                return Result(true, cand.label)
            }
            log.append("• ").append(cand.label).append(": ").append(err.javaClass.simpleName).append('\n')
        }
        return Result(false, log.toString().trim())
    }

    /** Gdzie wylądowało okno (Display #N + wznowiona aktywność), do logu diagnostycznego. */
    fun whereIsTop(): String {
        val o = Shell.run(
            "sleep 1; dumpsys activity activities | grep -E 'Display #|topResumedActivity|mResumedActivity' | head -12",
            10,
        )
        return o.text
    }

    /**
     * Start z uprawnieniami shella (Shizuku). Zwraca null, gdy Shizuku nie jest gotowe.
     * Wołać z wątku w tle.
     */
    fun launchPresetShell(ctx: Context, preset: Preset, displayId: Int = COVER_DISPLAY_ID): Result? {
        if (!Shell.granted()) return null

        val cmds = ArrayList<Pair<String, String>>()
        val custom = Prefs.getOverride(ctx, preset.id)
        if (custom != null) {
            cmds.add("własny cel ${custom.flattenToShortString()}" to adbFor(custom))
        }
        for (c in preset.candidates) {
            if (c.adb.startsWith("(")) continue
            cmds.add(c.label to c.adb)
        }

        val log = StringBuilder()
        for ((label, adb) in cmds) {
            val cmd = adb.replace("--display 1", "--display $displayId")
            val o = Shell.run(cmd)
            val bad = o.code != 0 || o.text.contains("Error", ignoreCase = true) ||
                o.text.contains("Exception") || o.text.contains("does not match")
            if (!bad) {
                val where = whereIsTop()
                return Result(true, "$label (shell)\n$where")
            }
            log.append("• ").append(label).append(" (shell): ").append(o.text.lines().take(3).joinToString(" / ")).append('\n')
        }
        return Result(false, log.toString().trim())
    }

    /** Najpierw shell (jeśli jest), potem zwykłe API aplikacji. Wołać z wątku w tle. */
    fun launchBest(ctx: Context, preset: Preset, displayId: Int = COVER_DISPLAY_ID): Result {
        val sh = launchPresetShell(ctx, preset, displayId)
        if (sh != null && sh.ok) return sh
        val plain = launchPreset(ctx, preset, displayId)
        if (plain.ok) return plain
        val head = if (sh != null) "SHELL:\n${sh.message}\n\n" else "(Shizuku niegotowe, tylko tryb zwykły)\n\n"
        return Result(false, head + "ZWYKŁY:\n" + plain.message)
    }
}
