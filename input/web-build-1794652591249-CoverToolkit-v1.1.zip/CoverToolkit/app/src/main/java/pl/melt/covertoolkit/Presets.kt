package pl.melt.covertoolkit

import android.content.Context
import android.content.Intent
import android.hardware.biometrics.BiometricManager
import android.provider.Settings

/** Jedna próba uruchomienia: jak zbudować Intent oraz jak wyglądałby jego odpowiednik w adb. */
class Candidate(
    val label: String,
    val adb: String,
    val make: (Context) -> Intent?,
)

class Preset(
    val id: String,
    val title: String,
    val subtitle: String,
    val note: String,
    val candidates: List<Candidate>,
)

object Presets {

    /** Start przez launcher pakietu (zwraca null, jeśli pakietu nie ma na telefonie). */
    private fun pkg(p: String) = Candidate(
        label = p,
        adb = "am start --display 1 -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -p $p",
        make = { c -> c.packageManager.getLaunchIntentForPackage(p) },
    )

    private fun action(label: String, a: String) = Candidate(
        label = label,
        adb = "am start --display 1 -a $a",
        make = { Intent(a) },
    )

    /** Kolejność = kolejność kafelków w widgecie (6 pierwszych). */
    val all: List<Preset> = listOf(
        Preset(
            id = "messages",
            title = "Wiadomości",
            subtitle = "pełna apka SMS",
            note = "Domyślna apka SMS na cover screenie, jak na dużym ekranie.",
            candidates = listOf(
                Candidate(
                    label = "domyślna apka SMS",
                    adb = "am start --display 1 -a android.intent.action.MAIN -c android.intent.category.APP_MESSAGING",
                    make = { Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING) },
                ),
                pkg("com.samsung.android.messaging"),
                pkg("com.google.android.apps.messaging"),
            ),
        ),
        Preset(
            id = "settings",
            title = "Ustawienia",
            subtitle = "pełne, jak na dużym",
            note = "Ustawienia Samsunga otwarte na cover screenie.",
            candidates = listOf(
                action("Ustawienia (systemowe)", Settings.ACTION_SETTINGS),
                pkg("com.android.settings"),
            ),
        ),
        Preset(
            id = "fingerprint",
            title = "Odcisk palca",
            subtitle = "dodaj / skonfiguruj",
            note = "Kreator rejestracji biometrii na cover screenie. Czytnik jest w bocznym przycisku, więc działa przy zamkniętym telefonie.",
            candidates = listOf(
                Candidate(
                    label = "rejestracja biometrii",
                    adb = "am start --display 1 -a ${Settings.ACTION_BIOMETRIC_ENROLL} --ei ${Settings.EXTRA_BIOMETRIC_AUTHENTICATORS_ALLOWED} ${BiometricManager.Authenticators.BIOMETRIC_STRONG}",
                    make = {
                        Intent(Settings.ACTION_BIOMETRIC_ENROLL).putExtra(
                            Settings.EXTRA_BIOMETRIC_AUTHENTICATORS_ALLOWED,
                            BiometricManager.Authenticators.BIOMETRIC_STRONG,
                        )
                    },
                ),
                action("rejestracja odcisku (starsza akcja)", "android.settings.FINGERPRINT_ENROLL"),
                action("Zabezpieczenia (potem Biometria)", Settings.ACTION_SECURITY_SETTINGS),
            ),
        ),
        Preset(
            id = "quickpanel",
            title = "Panel szybki",
            subtitle = "edycja przycisków",
            note = "Samsung nie ma osobnego ekranu edycji panelu. Próbuję przez Good Lock (QuickStar), a w ostateczności otwieram Ustawienia (tam wyszukaj: panel szybki).",
            candidates = listOf(
                pkg("com.samsung.android.qstuner"),
                pkg("com.samsung.android.goodlock"),
                action("Ustawienia (wyszukaj: panel szybki)", Settings.ACTION_SETTINGS),
            ),
        ),
        Preset(
            id = "coverwidgets",
            title = "Widgety cover",
            subtitle = "edycja widgetów",
            note = "Próbuję przez Good Lock (MultiStar), a w ostateczności otwieram Ustawienia (tam: Ekran zewnętrzny / Cover screen → Widgety).",
            candidates = listOf(
                pkg("com.samsung.android.multistar"),
                pkg("com.samsung.android.goodlock"),
                action("Ustawienia (wyszukaj: ekran zewnętrzny)", Settings.ACTION_SETTINGS),
            ),
        ),
        Preset(
            id = "apps",
            title = "Apki Samsunga",
            subtitle = "odblokowane na cover",
            note = "Lista apek Samsunga (i wszystkich innych), każdą odpalisz na cover screenie jednym dotknięciem.",
            candidates = listOf(
                Candidate("lista apek Samsunga", "(wewnętrzne)") { c ->
                    Intent(c, PickerActivity::class.java)
                        .putExtra(PickerActivity.EXTRA_MODE, PickerActivity.MODE_SAMSUNG)
                },
            ),
        ),
    )

    fun byId(id: String?): Preset? = all.firstOrNull { it.id == id }
}
