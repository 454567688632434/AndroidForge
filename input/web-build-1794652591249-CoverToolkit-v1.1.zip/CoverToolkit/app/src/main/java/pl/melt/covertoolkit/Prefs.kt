package pl.melt.covertoolkit

import android.content.ComponentName
import android.content.Context

/** Własne cele kafelków (ustawiane z Odkrywcy aktywności), próbowane przed wbudowanymi sposobami. */
object Prefs {

    private fun sp(c: Context) = c.getSharedPreferences("toolkit", Context.MODE_PRIVATE)

    fun getOverride(c: Context, presetId: String): ComponentName? {
        val flat = sp(c).getString("ov_$presetId", null) ?: return null
        return ComponentName.unflattenFromString(flat)
    }

    fun setOverride(c: Context, presetId: String, cn: ComponentName?) {
        val e = sp(c).edit()
        if (cn == null) e.remove("ov_$presetId") else e.putString("ov_$presetId", cn.flattenToString())
        e.apply()
    }
}
