package pl.melt.covertoolkit

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

/**
 * Dwa tryby:
 *  - MODE_SAMSUNG: lista apek z ikoną w launcherze (domyślnie tylko Samsung), dotknięcie = start na cover screenie.
 *  - MODE_ACTIVITIES: "Odkrywca" – wszystkie aktywności wszystkich pakietów z wyszukiwarką.
 *    Dotknięcie = start na cover, przytrzymanie = menu (ten ekran / ustaw jako cel kafelka / kopiuj ADB).
 */
class PickerActivity : Activity() {

    private class Entry(
        val title: String,
        val sub: String,
        val cn: ComponentName,
        val launcher: Boolean,
    )

    private lateinit var mode: String
    private lateinit var list: ListView
    private lateinit var toggle: Button
    private val adapter = EntryAdapter()

    private var all: List<Entry> = emptyList()
    private var query: String = ""
    private var showAllApps = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_SAMSUNG

        val colBg = getColor(R.color.bg)
        val colText = getColor(R.color.text)
        val colSub = getColor(R.color.sub)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(colBg)
        root.setPadding(dp(16), dp(16), dp(16), 0)

        val title = TextView(this)
        title.text = if (mode == MODE_SAMSUNG) "Apki Samsunga na cover" else "Odkrywca aktywności"
        title.textSize = 22f
        title.setTextColor(colText)
        title.setPadding(0, dp(8), 0, dp(8))
        root.addView(title)

        toggle = Button(this)
        if (mode == MODE_SAMSUNG) {
            toggle.isAllCaps = false
            toggle.setOnClickListener {
                showAllApps = !showAllApps
                refresh()
            }
            root.addView(toggle)
        } else {
            val search = EditText(this)
            search.hint = "Szukaj (min. 2 znaki): biometric, quick, cover…"
            search.setSingleLine()
            search.setTextColor(colText)
            search.setHintTextColor(colSub)
            search.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    query = (s?.toString() ?: "").trim().lowercase()
                    refresh()
                }
                override fun afterTextChanged(s: Editable?) {}
            })
            root.addView(search)
        }

        list = ListView(this)
        list.adapter = adapter
        list.divider = null
        list.setOnItemClickListener { _, _, pos, _ -> onTap(adapter.items[pos]) }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            onLong(adapter.items[pos])
            true
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        Thread {
            val loaded = if (mode == MODE_SAMSUNG) loadApps() else loadActivities()
            runOnUiThread {
                all = loaded
                refresh()
            }
        }.start()
    }

    // ---------- dane ----------

    @Suppress("DEPRECATION")
    private fun loadApps(): List<Entry> {
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(main, 0)
            .map { ri ->
                val ai = ri.activityInfo
                Entry(ri.loadLabel(pm).toString(), ai.packageName, ComponentName(ai.packageName, ai.name), true)
            }
            .sortedBy { it.title.lowercase() }
    }

    private fun loadActivities(): List<Entry> {
        val pm = packageManager
        val out = ArrayList<Entry>()
        val pkgs = pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(PackageManager.GET_ACTIVITIES.toLong()))
        for (pi in pkgs) {
            val acts = pi.activities ?: continue
            val appLabel = pi.applicationInfo?.loadLabel(pm)?.toString() ?: pi.packageName
            for (ai in acts) {
                val short = ai.name.removePrefix(pi.packageName)
                val priv = if (ai.exported) "" else "  (prywatna)"
                out.add(Entry(appLabel, pi.packageName + "/" + short + priv, ComponentName(pi.packageName, ai.name), false))
            }
        }
        return out.sortedBy { it.sub }
    }

    private fun isSamsung(p: String): Boolean =
        p.startsWith("com.samsung.") || p.startsWith("com.sec.") || p == "com.android.settings"

    private fun refresh() {
        val filtered: List<Entry> = if (mode == MODE_SAMSUNG) {
            all.filter { showAllApps || isSamsung(it.cn.packageName) }
        } else {
            if (query.length < 2) emptyList()
            else all.filter { (it.title + " " + it.sub).lowercase().contains(query) }
        }
        adapter.items = filtered.take(400)
        adapter.notifyDataSetChanged()
        if (mode == MODE_SAMSUNG) {
            toggle.text = if (showAllApps) "Pokazuję wszystkie apki (dotknij: tylko Samsung)"
            else "Pokazuję apki Samsunga (dotknij: wszystkie)"
        }
    }

    // ---------- akcje ----------

    private fun buildIntent(e: Entry): Intent =
        if (e.launcher) Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(e.cn)
        else Intent().setComponent(e.cn)

    private fun onTap(e: Entry) {
        // Z Shizuku: start z uprawnieniami shella (omija część blokad), inaczej zwykłe API.
        if (Shell.granted()) {
            Thread {
                val o = Shell.run(CoverLaunch.adbFor(e.cn))
                val bad = o.code != 0 || o.text.contains("Error", true) || o.text.contains("Exception")
                runOnUiThread { if (bad) toast("Shell: ${o.text.take(200)}") }
            }.start()
            return
        }
        val err = CoverLaunch.startIntent(this, buildIntent(e), CoverLaunch.COVER_DISPLAY_ID)
        if (err != null) toast("Nie wyszło: ${err.javaClass.simpleName}\n${e.cn.flattenToShortString()}")
    }

    private fun onLong(e: Entry) {
        val items = arrayOf("Uruchom na cover", "Uruchom na tym ekranie", "Ustaw jako cel kafelka…", "Kopiuj komendę ADB")
        AlertDialog.Builder(this)
            .setTitle(e.cn.flattenToShortString())
            .setItems(items) { _, which ->
                when (which) {
                    0 -> onTap(e)
                    1 -> {
                        val here = display?.displayId ?: 0
                        val err = CoverLaunch.startIntent(this, buildIntent(e), here)
                        if (err != null) toast("Nie wyszło: ${err.javaClass.simpleName}")
                    }
                    2 -> chooseTarget(e)
                    3 -> copy(CoverLaunch.adbFor(e.cn))
                    else -> {}
                }
            }
            .show()
    }

    private fun chooseTarget(e: Entry) {
        val names = Presets.all.map { it.title }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Cel dla kafelka")
            .setItems(names) { _, i ->
                Prefs.setOverride(this, Presets.all[i].id, e.cn)
                toast("Kafelek „${Presets.all[i].title}” spróbuje najpierw: ${e.cn.flattenToShortString()}")
            }
            .show()
    }

    private fun copy(text: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("adb", text))
        toast("Skopiowano")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ---------- lista ----------

    private fun makeRow(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.VERTICAL
        row.setPadding(dp(4), dp(10), dp(4), dp(10))

        val t = TextView(this)
        t.textSize = 16f
        t.setTextColor(getColor(R.color.text))

        val s = TextView(this)
        s.textSize = 12f
        s.setTextColor(getColor(R.color.sub))

        row.addView(t)
        row.addView(s)
        return row
    }

    private inner class EntryAdapter : BaseAdapter() {
        var items: List<Entry> = emptyList()

        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = convertView as? LinearLayout ?: makeRow()
            val e = items[position]
            (row.getChildAt(0) as TextView).text = e.title
            (row.getChildAt(1) as TextView).text = e.sub
            return row
        }
    }

    companion object {
        const val EXTRA_MODE = "mode"
        const val MODE_SAMSUNG = "samsung"
        const val MODE_ACTIVITIES = "activities"
    }
}
