package pl.melt.covertoolkit

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Diagnostyka przez shell: szuka, KTÓRA warstwa Samsunga wypycha apki z cover screena
 * (ustawienie systemowe, whitelista, czy sprawdzenie w samej apce). Wynik można skopiować/udostępnić.
 */
class DiagActivity : Activity() {

    private lateinit var out: TextView
    private lateinit var cmdBox: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(getColor(R.color.bg))
        root.setPadding(pad, pad, pad, pad)

        val title = TextView(this)
        title.text = "Diagnostyka (shell przez Shizuku)"
        title.textSize = 20f
        title.setTypeface(title.typeface, Typeface.BOLD)
        title.setTextColor(getColor(R.color.text))
        root.addView(title)

        root.addView(btn("Skan ustawień (cover/sub/flex/fold)") { run(SCAN_SETTINGS) })
        root.addView(btn("Ekrany i zadania (gdzie ląduje okno)") { run(SCAN_DISPLAYS) })
        root.addView(btn("Pakiety Samsunga od cover/flex/Good Lock") { run(SCAN_PACKAGES) })

        cmdBox = EditText(this)
        cmdBox.hint = "własna komenda shell, np. am start --display 1 -n pkg/.Klasa"
        cmdBox.setTextColor(getColor(R.color.text))
        cmdBox.setHintTextColor(getColor(R.color.sub))
        root.addView(cmdBox)
        root.addView(btn("Uruchom komendę") { run(cmdBox.text.toString()) })

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(btn("Kopiuj") {
            getSystemService(ClipboardManager::class.java)
                .setPrimaryClip(ClipData.newPlainText("diag", out.text))
            Toast.makeText(this, "Skopiowano", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(btn("Udostępnij") {
            startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, out.text.toString()),
                    "Wyślij wynik",
                )
            )
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)

        out = TextView(this)
        out.textSize = 11f
        out.typeface = Typeface.MONOSPACE
        out.setTextIsSelectable(true)
        out.setTextColor(getColor(R.color.sub))
        out.text = if (Shell.granted()) "Shizuku gotowe. Wybierz skan." else "Shizuku nie jest gotowe: uruchom je (Wireless debugging) i przyznaj dostęp w głównym ekranie apki."
        val sv = ScrollView(this)
        sv.addView(out)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    private fun btn(s: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.isAllCaps = false
        b.setOnClickListener { f() }
        return b
    }

    private fun run(cmd: String) {
        if (cmd.isBlank()) return
        out.text = "Działam…"
        Thread {
            val o = Shell.run(cmd, 60)
            val text = "exit=${o.code}\n" + o.text
            runOnUiThread { out.text = if (text.length > 60000) text.take(60000) + "\n…(ucięte)" else text }
        }.start()
    }

    companion object {
        private const val KEYS = "cover|sub_?screen|flex|flip|fold|outer|launcher_widget|allowed|labs"

        val SCAN_SETTINGS = """
            for ns in global secure system; do
              echo "=== settings $ns ==="
              settings list ${'$'}ns | grep -iE '$KEYS' | head -80
            done
        """.trimIndent()

        val SCAN_DISPLAYS = """
            echo "=== dumpsys display ==="
            dumpsys display | grep -iE 'Display [0-9]|uniqueId|mName|layerStack|state=|flags' | head -60
            echo
            echo "=== activity activities ==="
            dumpsys activity activities | grep -E 'Display #|topResumedActivity|mResumedActivity|mFocusedApp' | head -40
            echo
            echo "=== wm size/density ==="
            wm size -d 1; wm density -d 1
        """.trimIndent()

        val SCAN_PACKAGES = """
            pm list packages | grep -iE 'cover|flex|subscreen|flip|fold|multistar|goodlock|labs|shizuku' | sort
            echo
            getprop | grep -iE 'flip|fold|cover|sub_?display' | head -30
        """.trimIndent()
    }
}
