package pl.melt.covertoolkit

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.InputStream
import java.util.concurrent.TimeUnit

/**
 * Komendy z uprawnieniami shella (jak `adb shell`) przez Shizuku.
 * Shizuku odpalasz raz po restarcie telefonu: apka Shizuku -> "Start via Wireless debugging".
 */
object Shell {

    class Out(val code: Int, val text: String)

    const val REQ_CODE = 4711

    fun running(): Boolean = try {
        Shizuku.pingBinder()
    } catch (t: Throwable) {
        false
    }

    fun granted(): Boolean = try {
        running() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) {
        false
    }

    fun requestPermission() {
        try {
            Shizuku.requestPermission(REQ_CODE)
        } catch (t: Throwable) {
            // brak Shizuku: nic nie robimy, UI pokaże status
        }
    }

    // newProcess jest w API Shizuku prywatne, stąd refleksja (standardowy sposób).
    private val newProcess by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java,
        ).apply { isAccessible = true }
    }

    private fun drain(s: InputStream, sink: StringBuilder): Thread {
        val t = Thread {
            try {
                s.bufferedReader().forEachLine { line -> synchronized(sink) { sink.append(line).append('\n') } }
            } catch (_: Throwable) {
            }
        }
        t.isDaemon = true
        t.start()
        return t
    }

    /** Wołać z wątku w tle. */
    fun run(cmd: String, timeoutSec: Long = 20): Out {
        if (!granted()) return Out(-1, "Brak uprawnienia Shizuku (uruchom Shizuku i przyznaj dostęp w apce).")
        return try {
            val p = newProcess.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val out = StringBuilder()
            val err = StringBuilder()
            val t1 = drain(p.inputStream, out)
            val t2 = drain(p.errorStream, err)
            val done = p.waitFor(timeoutSec, TimeUnit.SECONDS)
            if (!done) {
                p.destroy()
                return Out(-2, "timeout po ${timeoutSec}s\n$out$err")
            }
            t1.join(1000)
            t2.join(1000)
            Out(p.exitValue(), (out.toString() + err.toString()).trim())
        } catch (t: Throwable) {
            Out(-3, "${t.javaClass.simpleName}: ${t.message}")
        }
    }
}
