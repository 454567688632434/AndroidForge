package pl.melt.covertoolkit

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews

/** Widget Flex Window (cover screen) z sześcioma kafelkami. */
class ToolkitWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            appWidgetManager.updateAppWidget(id, build(context))
        }
    }

    private fun build(ctx: Context): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_toolkit)

        val tiles = intArrayOf(R.id.tile0, R.id.tile1, R.id.tile2, R.id.tile3, R.id.tile4, R.id.tile5)
        val titles = intArrayOf(R.id.tt0, R.id.tt1, R.id.tt2, R.id.tt3, R.id.tt4, R.id.tt5)
        val subs = intArrayOf(R.id.ts0, R.id.ts1, R.id.ts2, R.id.ts3, R.id.ts4, R.id.ts5)

        Presets.all.take(tiles.size).forEachIndexed { i, p ->
            rv.setTextViewText(titles[i], p.title)
            rv.setTextViewText(subs[i], p.subtitle)

            // Unikalne data URI, żeby PendingIntenty różnych kafelków się nie zlały w jeden.
            val intent = Intent(ctx, TrampolineActivity::class.java)
                .setData(Uri.parse("covertoolkit://preset/${p.id}"))
                .putExtra(TrampolineActivity.EXTRA_PRESET, p.id)

            val pi = PendingIntent.getActivity(
                ctx,
                i,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                CoverLaunch.options(),
            )
            rv.setOnClickPendingIntent(tiles[i], pi)
        }
        return rv
    }
}
