package pl.melt.covertoolkit

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast

/**
 * Niewidoczny pośrednik. Kafelek widgetu otwiera go (już na cover screenie),
 * a on próbuje uruchomić właściwy cel na ekranie 1 i od razu się zamyka.
 */
class TrampolineActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val preset = Presets.byId(intent.getStringExtra(EXTRA_PRESET))
        if (preset != null) {
            val app = applicationContext
            Thread {
                val r = CoverLaunch.launchBest(app, preset)
                if (!r.ok) {
                    Handler(Looper.getMainLooper()).post {
                        Toast.makeText(app, "${preset.title}: nie wyszło\n${r.message.take(300)}", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }
        finish()
    }

    companion object {
        const val EXTRA_PRESET = "preset"
    }
}
