plugins {
    id("com.android.application")
}

android {
    namespace = "app.coverrecents"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.coverrecents"
        minSdk = 33
        targetSdk = 35
        versionCode = 3
        versionName = "2.1"
    }

    // Stały klucz w repo: kolejne wersje instalują się "na wierzch" bez odinstalowywania.
    // To aplikacja do własnego użytku (sideload), więc hasło jest jawne.
    signingConfigs {
        create("release") {
            storeFile = file("release.jks")
            storePassword = "coverrecents"
            keyAlias = "cover"
            keyPassword = "coverrecents"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}
