package app.coverrecents;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * Ekran ostatnich aplikacji.
 *
 * Karuzela (jak w Samsungu): karty obok siebie, przesunięcie karty w górę zamyka aplikację.
 * Siatka: ikony w kolumnach, przesunięcie w bok zamyka aplikację.
 * Przycisk X w lewym dolnym rogu zamyka wszystkie. Dotknięcie tła zamyka ekran.
 */
public class RecentsActivity extends Activity {

    private static final String TAG = "CoverRecents";

    private final List<RecentApps.App> items = new ArrayList<>();

    private RecyclerView list;
    private TextView emptyView;
    private Adapter adapter;

    private boolean grid;
    private boolean labels;
    private float density;
    private int cardWidth;
    private int cardHeight;
    private int cellWidth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        density = dm.density;
        int w = dm.widthPixels;
        int h = dm.heightPixels;
        grid = Prefs.isGrid(this);
        labels = Prefs.showLabels(this);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xE8101014);

        list = new RecyclerView(this);
        list.setClipToPadding(false);
        list.setOverScrollMode(View.OVER_SCROLL_NEVER);
        adapter = new Adapter();
        list.setAdapter(adapter);

        if (grid) {
            int columns = Math.max(2, Math.min(4, Prefs.columns(this)));
            int side = dp(12);
            cellWidth = (w - 2 * side) / columns;
            list.setLayoutManager(new GridLayoutManager(this, columns));
            list.setPadding(side, dp(24), side, dp(96));
        } else {
            cardWidth = Math.round(w * 0.60f);
            cardHeight = Math.round(h * 0.62f);
            int sidePad = Math.max(0, (w - cardWidth) / 2 - dp(8));
            int topPad = Math.max(dp(16), (h - cardHeight) / 2 - dp(24));
            list.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
            list.setPadding(sidePad, topPad, sidePad, 0);
            new LinearSnapHelper().attachToRecyclerView(list);
        }
        root.addView(list, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        emptyView = new TextView(this);
        emptyView.setTextColor(0xB3FFFFFF);
        emptyView.setTextSize(16);
        emptyView.setGravity(Gravity.CENTER);
        emptyView.setPadding(dp(32), 0, dp(32), 0);
        root.addView(emptyView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));

        if (Prefs.showCloseAll(this)) {
            ImageButton close = new ImageButton(this);
            close.setImageResource(R.drawable.ic_close);
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.OVAL);
            bg.setColor(0x33FFFFFF);
            close.setBackground(bg);
            close.setContentDescription("Zamknij wszystkie");
            close.setOnClickListener(v -> closeAll());
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    dp(56), dp(56), Gravity.BOTTOM | Gravity.START);
            lp.setMargins(dp(20), 0, 0, dp(20));
            root.addView(close, lp);
        }

        setContentView(root);

        int swipeDirs = grid
                ? (ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT)
                : ItemTouchHelper.UP;
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, swipeDirs) {
            @Override
            public boolean onMove(RecyclerView rv, RecyclerView.ViewHolder vh,
                                  RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder vh, int direction) {
                int pos = vh.getBindingAdapterPosition();
                if (pos == RecyclerView.NO_POSITION) {
                    return;
                }
                RecentApps.App app = items.remove(pos);
                adapter.notifyItemRemoved(pos);
                RecentApps.close(RecentsActivity.this, app.pkg);
                updateEmpty();
            }
        }).attachToRecyclerView(list);

        // Dotknięcie pustego tła zamyka ekran (jak w Samsungu).
        final GestureDetector tap = new GestureDetector(this,
                new GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onSingleTapUp(MotionEvent e) {
                        if (list.findChildViewUnder(e.getX(), e.getY()) == null) {
                            finish();
                        }
                        return false;
                    }
                });
        list.addOnItemTouchListener(new RecyclerView.SimpleOnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {
                tap.onTouchEvent(e);
                return false;
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        reload();
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Jak systemowe ostatnie: po wyjściu (home, wygaszenie, start aplikacji) ekran znika.
        if (!isChangingConfigurations()) {
            finish();
        }
    }

    private void reload() {
        items.clear();
        items.addAll(RecentApps.load(this, Prefs.maxApps(this)));
        adapter.notifyDataSetChanged();
        updateEmpty();
    }

    private void updateEmpty() {
        boolean none = items.isEmpty();
        emptyView.setVisibility(none ? View.VISIBLE : View.GONE);
        if (none) {
            emptyView.setText(RecentApps.hasUsageAccess(this)
                    ? "Brak ostatnich aplikacji"
                    : "Przyznaj dostęp do użycia w aplikacji Cover Recents (na ekranie głównym telefonu)");
        }
    }

    private void closeAll() {
        // Zamykamy też aplikacje starsze niż te widoczne na liście.
        for (RecentApps.App app : RecentApps.load(this, Integer.MAX_VALUE)) {
            RecentApps.close(this, app.pkg);
        }
        items.clear();
        adapter.notifyDataSetChanged();
        list.animate().alpha(0f).setDuration(160).withEndAction(this::finish).start();
    }

    private void launch(RecentApps.App app) {
        Intent intent = getPackageManager().getLaunchIntentForPackage(app.pkg);
        if (intent == null) {
            Toast.makeText(this, "Nie można uruchomić: " + app.label, Toast.LENGTH_SHORT).show();
            return;
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        ActivityOptions options = ActivityOptions.makeBasic();
        Display display = getDisplay();
        if (display != null) {
            options.setLaunchDisplayId(display.getDisplayId());
        }
        try {
            startActivity(intent, options.toBundle());
        } catch (RuntimeException e) {
            Log.w(TAG, "Start z wymuszonym ekranem nie powiódł się, próbuję domyślnie", e);
            try {
                startActivity(intent);
            } catch (RuntimeException e2) {
                Log.e(TAG, "Nie udało się uruchomić " + app.pkg, e2);
                Toast.makeText(this, "Nie można uruchomić: " + app.label, Toast.LENGTH_SHORT).show();
                return;
            }
        }
        finish();
    }

    private int dp(int value) {
        return Math.round(value * density);
    }

    private static final class Holder extends RecyclerView.ViewHolder {
        final ImageView icon;
        final TextView label;

        Holder(View itemView, ImageView icon, TextView label) {
            super(itemView);
            this.icon = icon;
            this.label = label;
        }
    }

    private final class Adapter extends RecyclerView.Adapter<Holder> {

        @Override
        public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
            LinearLayout card = new LinearLayout(RecentsActivity.this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER);

            int iconSize;
            if (grid) {
                iconSize = dp(56);
                card.setPadding(dp(4), dp(10), dp(4), dp(10));
                card.setLayoutParams(new RecyclerView.LayoutParams(
                        cellWidth, ViewGroup.LayoutParams.WRAP_CONTENT));
            } else {
                iconSize = dp(96);
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(0xFF26262B);
                bg.setCornerRadius(dp(28));
                card.setBackground(bg);
                card.setElevation(dp(6));
                RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(cardWidth, cardHeight);
                lp.setMargins(dp(8), 0, dp(8), 0);
                card.setLayoutParams(lp);
            }

            ImageView icon = new ImageView(RecentsActivity.this);
            card.addView(icon, new LinearLayout.LayoutParams(iconSize, iconSize));

            TextView label = new TextView(RecentsActivity.this);
            label.setTextColor(Color.WHITE);
            label.setMaxLines(1);
            label.setEllipsize(TextUtils.TruncateAt.END);
            label.setGravity(Gravity.CENTER);
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, grid ? 12 : 17);
            label.setPadding(dp(8), dp(grid ? 6 : 14), dp(8), 0);
            label.setVisibility(labels ? View.VISIBLE : View.GONE);
            card.addView(label, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            return new Holder(card, icon, label);
        }

        @Override
        public void onBindViewHolder(Holder holder, int position) {
            RecentApps.App app = items.get(position);
            holder.icon.setImageDrawable(app.icon);
            holder.label.setText(app.label);
            holder.itemView.setOnClickListener(v -> {
                int p = holder.getBindingAdapterPosition();
                if (p != RecyclerView.NO_POSITION) {
                    launch(items.get(p));
                }
            });
        }

        @Override
        public int getItemCount() {
            return items.size();
        }
    }
}
