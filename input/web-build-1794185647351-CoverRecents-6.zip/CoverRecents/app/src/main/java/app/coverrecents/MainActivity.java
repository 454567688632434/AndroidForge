package app.coverrecents;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Locale;

/** Ustawienia aplikacji (ekran główny telefonu). */
public class MainActivity extends Activity {

    private LinearLayout content;
    private TextView usageStatus;
    private TextView accessibilityStatus;
    private float density;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        density = getResources().getDisplayMetrics().density;

        ScrollView scroll = new ScrollView(this);
        scroll.setOnApplyWindowInsetsListener((v, insets) -> {
            Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsets.CONSUMED;
        });

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(16), dp(20), dp(32));
        scroll.addView(content);
        setContentView(scroll);

        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        usageStatus.setText(RecentApps.hasUsageAccess(this)
                ? "Dostęp do użycia: włączony ✓"
                : "Dostęp do użycia: BRAK. Bez niego lista ostatnich jest pusta.");
        accessibilityStatus.setText(isAccessibilityEnabled()
                ? "Usługa ułatwień dostępu: włączona ✓"
                : "Usługa ułatwień dostępu: wyłączona (potrzebna do gestu)");
    }

    private void build() {
        content.addView(text("Cover Recents", 26, true), lp(0));
        content.addView(note("Własny ekran ostatnich aplikacji dla ekranu zewnętrznego Z Flip."), lp(4));

        section("Uprawnienia");
        usageStatus = text("", 15, false);
        content.addView(usageStatus, lp(8));
        content.addView(button("Przyznaj dostęp do użycia", v -> openUsageAccess()), lp(4));

        section("Sposoby otwierania");
        content.addView(note("Można używać obu sposobów naraz."), lp(8));

        content.addView(text("1. Widżet", 16, true), lp(14));
        content.addView(note("Dodaj widżet „Ostatnie aplikacje” na ekranie zewnętrznym: "
                + "przesuń palcem do widżetów i dodaj go do listy. "
                + "Dotknięcie widżetu otwiera ostatnie aplikacje. Działa zawsze, bez dodatkowych ustawień."), lp(2));

        content.addView(text("2. Gest przy pasku powrotu do ekranu głównego", 16, true), lp(20));
        content.addView(note("Przeciągnij palec w górę tuż nad paskiem, który wraca do ekranu głównego, "
                + "i przytrzymaj. Wymaga usługi ułatwień dostępu. "
                + "Jeśli przełącznik usługi jest wyszarzony: Ustawienia → Aplikacje → Cover Recents → "
                + "menu ⋮ → Zezwól na ustawienia z ograniczeniami."), lp(2));
        accessibilityStatus = text("", 15, false);
        content.addView(accessibilityStatus, lp(8));
        content.addView(button("Ustawienia ułatwień dostępu",
                v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))), lp(4));
        switchRow("Włącz gest", Prefs.HANDLE, false);
        switchRow("Położenie automatyczne (tuż nad paskiem nawigacji)", Prefs.HANDLE_AUTO, true);
        switchRow("Pokaż obszar gestu (do ustawienia)", Prefs.HANDLE_VISIBLE, false);
        seekRow("Wysokość obszaru gestu", Prefs.HANDLE_HEIGHT, 12, 80, 4, 36, " dp");
        seekRow("Odstęp od dołu (gdy położenie nie jest automatyczne)", Prefs.HANDLE_OFFSET, 0, 80, 4, 16, " dp");
        seekRow("Czas przytrzymania (0 = bez przytrzymania)", Prefs.HOLD_MS, 0, 600, 50, 250, " ms");

        section("Wygląd");
        radioRow("Styl", Prefs.LAYOUT, Prefs.LAYOUT_CAROUSEL,
                new String[]{Prefs.LAYOUT_CAROUSEL, Prefs.LAYOUT_GRID},
                new String[]{"Karuzela (jak w Samsungu)", "Siatka"});
        seekRow("Kolumny siatki", Prefs.COLUMNS, 2, 4, 1, 3, "");
        switchRow("Nazwy aplikacji", Prefs.LABELS, true);
        switchRow("Przycisk X „Zamknij wszystkie” (lewy dolny róg)", Prefs.CLOSE_ALL, true);
        seekRow("Liczba aplikacji na liście", Prefs.MAX_APPS, 4, 20, 1, 10, "");
        content.addView(button("Podgląd na tym ekranie",
                v -> startActivity(new Intent(this, RecentsActivity.class))), lp(16));
    }

    // ---- elementy interfejsu ----

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        if (bold) {
            t.setTypeface(null, Typeface.BOLD);
        }
        return t;
    }

    private TextView note(String s) {
        TextView t = text(s, 13, false);
        t.setAlpha(0.7f);
        return t;
    }

    private void section(String title) {
        TextView t = text(title.toUpperCase(Locale.getDefault()), 12, true);
        t.setTextColor(0xFF4F8CFF);
        t.setLetterSpacing(0.08f);
        content.addView(t, lp(28));
    }

    private Button button(String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(listener);
        return b;
    }

    private void switchRow(String label, String key, boolean def) {
        Switch sw = new Switch(this);
        sw.setText(label);
        sw.setTextSize(16);
        sw.setChecked(Prefs.get(this).getBoolean(key, def));
        sw.setOnCheckedChangeListener((button, on) ->
                Prefs.get(this).edit().putBoolean(key, on).apply());
        content.addView(sw, lp(10));
    }

    private void radioRow(String label, String key, String def, String[] values, String[] labels) {
        content.addView(text(label, 16, false), lp(12));
        RadioGroup group = new RadioGroup(this);
        String current = Prefs.get(this).getString(key, def);
        for (int i = 0; i < values.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(labels[i]);
            rb.setId(View.generateViewId());
            rb.setTag(values[i]);
            group.addView(rb);
            if (values[i].equals(current)) {
                rb.setChecked(true);
            }
        }
        group.setOnCheckedChangeListener((g, id) -> {
            View checked = g.findViewById(id);
            if (checked != null) {
                Prefs.get(this).edit().putString(key, (String) checked.getTag()).apply();
            }
        });
        content.addView(group, lp(0));
    }

    private void seekRow(String label, String key, int min, int max, int step, int def, String unit) {
        TextView title = text("", 16, false);
        int current = Prefs.get(this).getInt(key, def);
        title.setText(label + ": " + current + unit);
        content.addView(title, lp(14));

        SeekBar bar = new SeekBar(this);
        bar.setMax((max - min) / step);
        bar.setProgress((current - min) / step);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                int value = min + progress * step;
                title.setText(label + ": " + value + unit);
                if (fromUser) {
                    Prefs.get(MainActivity.this).edit().putInt(key, value).apply();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        content.addView(bar, lp(0));
    }

    private LinearLayout.LayoutParams lp(int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(topDp);
        return p;
    }

    private int dp(int value) {
        return Math.round(value * density);
    }

    // ---- uprawnienia ----

    private void openUsageAccess() {
        try {
            startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS,
                    Uri.parse("package:" + getPackageName())));
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
        }
    }

    private boolean isAccessibilityEnabled() {
        String enabled = Settings.Secure.getString(
                getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) {
            return false;
        }
        ComponentName mine = new ComponentName(this, RecentsService.class);
        for (String entry : enabled.split(":")) {
            if (mine.equals(ComponentName.unflattenFromString(entry))) {
                return true;
            }
        }
        return false;
    }
}
