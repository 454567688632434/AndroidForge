# Cover Toolkit 2.0

Widget na cover screen (Z Flip 5) z ostatnimi powiadomieniami. Dotknięcie = otwarcie powiadomienia na cover screenie.

1. Zainstaluj APK, otwórz apkę, włącz dostęp do powiadomień.
2. Ustawienia → Ekran zewnętrzny → Widgety → włącz Cover Toolkit.
3. Zamknij telefon, przesuń do widgetu.

Budowanie: GitHub Actions (Build APK) albo `./gradlew assembleRelease`.
