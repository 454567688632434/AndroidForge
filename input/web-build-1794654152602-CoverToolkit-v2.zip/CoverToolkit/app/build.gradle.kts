import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "pl.melt.covertoolkit"
    compileSdk = 35

    defaultConfig {
        applicationId = "pl.melt.covertoolkit"
        minSdk = 33          // Z Flip 5 wyszedł z Androidem 13
        targetSdk = 34
        versionCode = 3
        versionName = "2.0"
    }

    // Stały klucz, żeby każda kolejna wersja APK dawała się zainstalować "na wierzch" bez odinstalowywania.
    signingConfigs {
        create("toolkit") {
            storeFile = rootProject.file("toolkit.keystore")
            storePassword = "covertoolkit"
            keyAlias = "toolkit"
            keyPassword = "covertoolkit"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("toolkit")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("toolkit")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

