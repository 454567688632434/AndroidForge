package pl.melt.covertoolkit

import android.app.Notification
import android.content.pm.PackageManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Podgląd aktywnych powiadomień dla widgetu na cover screenie. */
class NotifService : NotificationListenerService() {

    override fun onListenerConnected() {
        instance = this
        ToolkitWidget.refresh(applicationContext)
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        ToolkitWidget.refresh(applicationContext)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        ToolkitWidget.refresh(applicationContext)
    }

    companion object {
        const val MAX = 5

        @Volatile
        var instance: NotifService? = null

        private fun all(): List<StatusBarNotification> {
            val arr = try {
                instance?.activeNotifications
            } catch (t: Throwable) {
                null
            }
            return arr?.toList() ?: emptyList()
        }

        /** Widoczne powiadomienia: bez stałych (ongoing), bez zbiorczych, bez własnych, najnowsze pierwsze. */
        fun visible(selfPkg: String): List<StatusBarNotification> =
            all().filter {
                val n = it.notification
                (n.flags and Notification.FLAG_ONGOING_EVENT) == 0 &&
                    (n.flags and Notification.FLAG_GROUP_SUMMARY) == 0 &&
                    it.packageName != selfPkg
            }.sortedByDescending { it.postTime }.take(MAX)

        fun find(key: String?): StatusBarNotification? = all().firstOrNull { it.key == key }

        fun appLabel(pm: PackageManager, pkg: String): String = try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0))).toString()
        } catch (t: Throwable) {
            pkg
        }
    }
}
