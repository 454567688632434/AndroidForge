package pl.melt.covertoolkit

import android.app.Notification
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.View
import android.widget.RemoteViews

/** Widget Flex Window (cover screen): ostatnie powiadomienia, dotknięcie = otwarcie na cover screenie. */
class ToolkitWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            appWidgetManager.updateAppWidget(id, build(context))
        }
    }

    companion object {

        fun refresh(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, ToolkitWidget::class.java))
            for (id in ids) {
                mgr.updateAppWidget(id, build(ctx))
            }
        }

        private fun build(ctx: Context): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_toolkit)

            val rows = intArrayOf(R.id.row0, R.id.row1, R.id.row2, R.id.row3, R.id.row4)
            val titles = intArrayOf(R.id.t0, R.id.t1, R.id.t2, R.id.t3, R.id.t4)
            val texts = intArrayOf(R.id.s0, R.id.s1, R.id.s2, R.id.s3, R.id.s4)

            val list = NotifService.visible(ctx.packageName)
            rv.setViewVisibility(R.id.empty, if (list.isEmpty()) View.VISIBLE else View.GONE)

            for (i in rows.indices) {
                if (i >= list.size) {
                    rv.setViewVisibility(rows[i], View.GONE)
                    continue
                }
                val sbn = list[i]
                val ex = sbn.notification.extras
                val app = NotifService.appLabel(ctx.packageManager, sbn.packageName)
                val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
                val body = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
                    ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()

                rv.setViewVisibility(rows[i], View.VISIBLE)
                rv.setTextViewText(titles[i], if (title.isEmpty()) app else "$app · $title")
                rv.setTextViewText(texts[i], body)

                // Unikalne data URI, żeby PendingIntenty kolejnych wierszy się nie zlały w jeden.
                val intent = Intent(ctx, OpenReceiver::class.java)
                    .setData(Uri.parse("covertoolkit://notif/$i"))
                    .putExtra(OpenReceiver.EXTRA_KEY, sbn.key)
                val pi = PendingIntent.getBroadcast(
                    ctx, i, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                )
                rv.setOnClickPendingIntent(rows[i], pi)
            }
            return rv
        }
    }
}
