package pl.melt.covertoolkit

import android.app.ActivityOptions
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast

/** Dotknięcie powiadomienia w widgecie: odpala jego intencję na cover screenie (display 1). */
class OpenReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val sbn = NotifService.find(intent.getStringExtra(EXTRA_KEY))
        val pi = sbn?.notification?.contentIntent
        if (pi == null) {
            Toast.makeText(context, "Powiadomienie już nie istnieje", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val opts = ActivityOptions.makeBasic().setLaunchDisplayId(COVER_DISPLAY_ID)
            if (Build.VERSION.SDK_INT >= 34) {
                opts.setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
            }
            pi.send(context, 0, null, null, null, null, opts.toBundle())
        } catch (e: PendingIntent.CanceledException) {
            Toast.makeText(context, "Powiadomienie wygasło", Toast.LENGTH_SHORT).show()
        } catch (t: Throwable) {
            Toast.makeText(context, "Nie wyszło: ${t.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    companion object {
        const val EXTRA_KEY = "key"
        const val COVER_DISPLAY_ID = 1
    }
}
