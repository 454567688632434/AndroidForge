package pl.melt.covertoolkit

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Jedyny ekran: dostęp do powiadomień + instrukcja dodania widgetu na cover screen. */
class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(getColor(R.color.bg))
        root.setPadding(pad, pad * 2, pad, pad)

        val title = TextView(this)
        title.text = "Cover Toolkit"
        title.textSize = 28f
        title.setTypeface(title.typeface, Typeface.BOLD)
        title.setTextColor(getColor(R.color.text))
        root.addView(title)

        status = TextView(this)
        status.textSize = 15f
        status.setTextColor(getColor(R.color.sub))
        status.setPadding(0, pad / 2, 0, pad / 2)
        root.addView(status)

        val btn = Button(this)
        btn.text = "Dostęp do powiadomień"
        btn.isAllCaps = false
        btn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        root.addView(btn)

        val how = TextView(this)
        how.text = "Jak użyć:\n" +
            "1. Włącz dostęp dla Cover Toolkit (przycisk wyżej).\n" +
            "2. Ustawienia → Ekran zewnętrzny → Widgety → włącz „Cover Toolkit”.\n" +
            "3. Zamknij telefon i przesuń do widgetu. Dotknięcie powiadomienia otwiera je na cover screenie."
        how.textSize = 14f
        how.setTextColor(getColor(R.color.sub))
        how.setPadding(0, pad, 0, 0)
        root.addView(how)

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        status.text = if (enabled) "Dostęp do powiadomień: włączony" else "Dostęp do powiadomień: wyłączony"
    }
}
