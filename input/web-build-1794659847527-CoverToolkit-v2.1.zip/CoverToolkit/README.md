# Cover Toolkit 2.1

Bypass powiadomień na cover screen (Z Flip 5): widget z powiadomieniami, otwieranie ich na cover screenie, szybka odpowiedź i zamykanie.

Ustawienia: liczba powiadomień (3–8), pokazywanie treści, stałe powiadomienia, usuwanie po otwarciu,
tryb otwierania (auto / cover / duży ekran), ID ekranu cover, tekst szybkiej odpowiedzi, filtr aplikacji.

1. Zainstaluj APK, włącz dostęp do powiadomień.
2. Ustawienia → Ekran zewnętrzny → Widgety → włącz Cover Toolkit.
