package pl.melt.covertoolkit

import android.app.Notification
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.View
import android.widget.RemoteViews

/** Widget Flex Window (cover screen): powiadomienia, dotknięcie = otwarcie, ↩ = szybka odpowiedź, ✕ = zamknij. */
class ToolkitWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            appWidgetManager.updateAppWidget(id, build(context))
        }
    }

    companion object {
        private val ROWS = intArrayOf(R.id.row0, R.id.row1, R.id.row2, R.id.row3, R.id.row4, R.id.row5, R.id.row6, R.id.row7)
        private val TITLES = intArrayOf(R.id.t0, R.id.t1, R.id.t2, R.id.t3, R.id.t4, R.id.t5, R.id.t6, R.id.t7)
        private val TEXTS = intArrayOf(R.id.s0, R.id.s1, R.id.s2, R.id.s3, R.id.s4, R.id.s5, R.id.s6, R.id.s7)
        private val REPLY = intArrayOf(R.id.r0, R.id.r1, R.id.r2, R.id.r3, R.id.r4, R.id.r5, R.id.r6, R.id.r7)
        private val CLOSE = intArrayOf(R.id.x0, R.id.x1, R.id.x2, R.id.x3, R.id.x4, R.id.x5, R.id.x6, R.id.x7)

        fun refresh(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, ToolkitWidget::class.java))
            for (id in ids) {
                mgr.updateAppWidget(id, build(ctx))
            }
        }

        private fun pending(ctx: Context, action: String, i: Int, key: String): PendingIntent {
            // Unikalne data URI, żeby PendingIntenty różnych wierszy i przycisków się nie zlały.
            val intent = Intent(ctx, OpenReceiver::class.java)
                .setAction(action)
                .setData(Uri.parse("covertoolkit://$i/${action.substringAfterLast('.')}"))
                .putExtra(OpenReceiver.EXTRA_KEY, key)
            return PendingIntent.getBroadcast(
                ctx, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
        }

        private fun build(ctx: Context): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_toolkit)
            val list = NotifService.visible(ctx)
            val showContent = Prefs.showContent(ctx)
            val quick = Prefs.quickReply(ctx)

            rv.setViewVisibility(R.id.empty, if (list.isEmpty()) View.VISIBLE else View.GONE)

            for (i in ROWS.indices) {
                if (i >= list.size) {
                    rv.setViewVisibility(ROWS[i], View.GONE)
                    continue
                }
                val sbn = list[i]
                val ex = sbn.notification.extras
                val app = NotifService.appLabel(ctx.packageManager, sbn.packageName)
                val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
                val body = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
                    ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()

                rv.setViewVisibility(ROWS[i], View.VISIBLE)
                rv.setTextViewText(TITLES[i], if (title.isEmpty()) app else "$app · $title")
                if (showContent && body.isNotEmpty()) {
                    rv.setViewVisibility(TEXTS[i], View.VISIBLE)
                    rv.setTextViewText(TEXTS[i], body)
                } else {
                    rv.setViewVisibility(TEXTS[i], View.GONE)
                }

                val canReply = quick.isNotBlank() && NotifService.replyAction(sbn) != null
                rv.setViewVisibility(REPLY[i], if (canReply) View.VISIBLE else View.GONE)

                rv.setOnClickPendingIntent(ROWS[i], pending(ctx, OpenReceiver.ACTION_OPEN, i, sbn.key))
                rv.setOnClickPendingIntent(REPLY[i], pending(ctx, OpenReceiver.ACTION_REPLY, i, sbn.key))
                rv.setOnClickPendingIntent(CLOSE[i], pending(ctx, OpenReceiver.ACTION_DISMISS, i, sbn.key))
            }
            return rv
        }
    }
}
