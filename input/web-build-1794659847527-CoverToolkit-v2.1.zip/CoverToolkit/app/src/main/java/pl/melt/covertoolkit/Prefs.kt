package pl.melt.covertoolkit

import android.content.Context

/** Ustawienia bypassu powiadomień. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("cover_toolkit", Context.MODE_PRIVATE)

    fun count(c: Context) = sp(c).getInt("count", 5).coerceIn(3, 8)
    fun setCount(c: Context, v: Int) = sp(c).edit().putInt("count", v.coerceIn(3, 8)).apply()

    fun showContent(c: Context) = sp(c).getBoolean("showContent", true)
    fun setShowContent(c: Context, v: Boolean) = sp(c).edit().putBoolean("showContent", v).apply()

    fun showOngoing(c: Context) = sp(c).getBoolean("showOngoing", false)
    fun setShowOngoing(c: Context, v: Boolean) = sp(c).edit().putBoolean("showOngoing", v).apply()

    fun dismissAfterOpen(c: Context) = sp(c).getBoolean("dismissAfterOpen", false)
    fun setDismissAfterOpen(c: Context, v: Boolean) = sp(c).edit().putBoolean("dismissAfterOpen", v).apply()

    /** 0 = auto (cover, w razie błędu duży ekran), 1 = tylko cover, 2 = tylko duży ekran. */
    fun openMode(c: Context) = sp(c).getInt("openMode", 0)
    fun setOpenMode(c: Context, v: Int) = sp(c).edit().putInt("openMode", v).apply()

    fun coverDisplay(c: Context) = sp(c).getInt("coverDisplay", 1)
    fun setCoverDisplay(c: Context, v: Int) = sp(c).edit().putInt("coverDisplay", v).apply()

    fun quickReply(c: Context) = sp(c).getString("quickReply", "OK") ?: ""
    fun setQuickReply(c: Context, v: String) = sp(c).edit().putString("quickReply", v).apply()

    /** Aplikacje, których powiadomień NIE pokazujemy. */
    fun blocked(c: Context): Set<String> = HashSet(sp(c).getStringSet("blocked", emptySet()) ?: emptySet())
    fun setBlocked(c: Context, v: Set<String>) = sp(c).edit().putStringSet("blocked", HashSet(v)).apply()
}
