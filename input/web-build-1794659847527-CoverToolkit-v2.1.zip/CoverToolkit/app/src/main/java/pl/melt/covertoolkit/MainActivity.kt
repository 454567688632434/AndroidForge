package pl.melt.covertoolkit

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

/** Ustawienia bypassu powiadomień na cover screen. */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var reply: EditText

    private val modes = arrayOf(
        "Otwieraj: auto (cover, w razie błędu duży ekran)",
        "Otwieraj: tylko cover screen",
        "Otwieraj: tylko duży ekran",
    )

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(getColor(color))
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun btn(text: String, onClick: (Button) -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setOnClickListener { onClick(b) }
        return b
    }

    private fun sw(text: String, init: Boolean, onChange: (Boolean) -> Unit): Switch {
        val s = Switch(this)
        s.text = text
        s.isChecked = init
        s.setTextColor(getColor(R.color.text))
        s.setPadding(0, 16, 0, 16)
        s.setOnCheckedChangeListener { _, v ->
            onChange(v)
            ToolkitWidget.refresh(applicationContext)
        }
        return s
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad * 2, pad, pad)

        root.addView(tv("Cover Toolkit", 28f, R.color.text, true))

        status = tv("", 15f, R.color.sub)
        status.setPadding(0, pad / 2, 0, pad / 2)
        root.addView(status)
        root.addView(btn("Dostęp do powiadomień") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })

        // Liczba powiadomień
        val countLabel = tv("Liczba powiadomień: ${Prefs.count(this)}", 15f, R.color.text)
        countLabel.setPadding(0, pad, 0, 0)
        root.addView(countLabel)
        val sb = SeekBar(this)
        sb.max = 5
        sb.progress = Prefs.count(this) - 3
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                countLabel.text = "Liczba powiadomień: ${p + 3}"
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {
                Prefs.setCount(this@MainActivity, (s?.progress ?: 2) + 3)
                ToolkitWidget.refresh(applicationContext)
            }
        })
        root.addView(sb)

        root.addView(sw("Pokazuj treść wiadomości", Prefs.showContent(this)) { Prefs.setShowContent(this, it) })
        root.addView(sw("Pokazuj stałe powiadomienia (odtwarzacz itp.)", Prefs.showOngoing(this)) { Prefs.setShowOngoing(this, it) })
        root.addView(sw("Usuń powiadomienie po otwarciu", Prefs.dismissAfterOpen(this)) { Prefs.setDismissAfterOpen(this, it) })

        // Tryb otwierania
        root.addView(btn(modes[Prefs.openMode(this)]) { b ->
            val next = (Prefs.openMode(this) + 1) % modes.size
            Prefs.setOpenMode(this, next)
            b.text = modes[next]
        })

        // ID ekranu cover
        root.addView(btn("ID ekranu cover: ${Prefs.coverDisplay(this)} (dotknij, by zmienić 1→2→3)") { b ->
            val next = Prefs.coverDisplay(this) % 3 + 1
            Prefs.setCoverDisplay(this, next)
            b.text = "ID ekranu cover: $next (dotknij, by zmienić 1→2→3)"
        })

        // Szybka odpowiedź
        val rl = tv("Tekst szybkiej odpowiedzi (przycisk ↩, puste = wyłączone)", 14f, R.color.sub)
        rl.setPadding(0, pad, 0, 0)
        root.addView(rl)
        reply = EditText(this)
        reply.setText(Prefs.quickReply(this))
        reply.inputType = InputType.TYPE_CLASS_TEXT
        reply.setTextColor(getColor(R.color.text))
        root.addView(reply)

        root.addView(btn("Wybierz aplikacje") {
            startActivity(Intent(this, AppFilterActivity::class.java))
        })

        val how = tv(
            "Jak użyć:\n" +
                "1. Włącz dostęp do powiadomień.\n" +
                "2. Ustawienia → Ekran zewnętrzny → Widgety → włącz „Cover Toolkit”.\n" +
                "3. Na cover screenie: dotknięcie = otwórz, ↩ = szybka odpowiedź, ✕ = zamknij.",
            14f, R.color.sub,
        )
        how.setPadding(0, pad, 0, 0)
        root.addView(how)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(getColor(R.color.bg))
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        status.text = if (enabled) "Dostęp do powiadomień: włączony" else "Dostęp do powiadomień: wyłączony"
    }

    override fun onPause() {
        super.onPause()
        Prefs.setQuickReply(this, reply.text.toString())
        ToolkitWidget.refresh(applicationContext)
    }
}
