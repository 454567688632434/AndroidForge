package pl.melt.covertoolkit

import android.app.Notification
import android.content.Context
import android.content.pm.PackageManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Podgląd aktywnych powiadomień dla widgetu na cover screenie. */
class NotifService : NotificationListenerService() {

    override fun onListenerConnected() {
        instance = this
        ToolkitWidget.refresh(applicationContext)
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        ToolkitWidget.refresh(applicationContext)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        ToolkitWidget.refresh(applicationContext)
    }

    companion object {
        @Volatile
        var instance: NotifService? = null

        private fun all(): List<StatusBarNotification> {
            val arr = try {
                instance?.activeNotifications
            } catch (t: Throwable) {
                null
            }
            return arr?.toList() ?: emptyList()
        }

        /** Widoczne powiadomienia wg ustawień, najnowsze pierwsze. */
        fun visible(ctx: Context): List<StatusBarNotification> {
            val blocked = Prefs.blocked(ctx)
            val ongoing = Prefs.showOngoing(ctx)
            return all().filter {
                val n = it.notification
                (ongoing || (n.flags and Notification.FLAG_ONGOING_EVENT) == 0) &&
                    (n.flags and Notification.FLAG_GROUP_SUMMARY) == 0 &&
                    it.packageName != ctx.packageName &&
                    it.packageName !in blocked
            }.sortedByDescending { it.postTime }.take(Prefs.count(ctx))
        }

        fun find(key: String?): StatusBarNotification? = all().firstOrNull { it.key == key }

        /** Akcja odpowiedzi z polem tekstowym (RemoteInput), jeśli powiadomienie ją ma. */
        fun replyAction(sbn: StatusBarNotification): Notification.Action? =
            sbn.notification.actions?.firstOrNull { a ->
                a.actionIntent != null && a.remoteInputs?.isNotEmpty() == true
            }

        fun appLabel(pm: PackageManager, pkg: String): String = try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0))).toString()
        } catch (t: Throwable) {
            pkg
        }
    }
}
