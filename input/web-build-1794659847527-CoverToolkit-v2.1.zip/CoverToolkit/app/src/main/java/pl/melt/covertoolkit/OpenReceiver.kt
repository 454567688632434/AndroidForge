package pl.melt.covertoolkit

import android.app.ActivityOptions
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast

/** Obsługa dotknięć w widgecie: otwórz / odpowiedz / zamknij. */
class OpenReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val key = intent.getStringExtra(EXTRA_KEY)
        val sbn = NotifService.find(key)
        if (sbn == null) {
            toast(context, "Powiadomienie już nie istnieje")
            ToolkitWidget.refresh(context)
            return
        }
        when (intent.action) {
            ACTION_DISMISS -> NotifService.instance?.cancelNotification(sbn.key)
            ACTION_REPLY -> reply(context, sbn)
            else -> open(context, sbn)
        }
    }

    private fun open(ctx: Context, sbn: android.service.notification.StatusBarNotification) {
        val pi = sbn.notification.contentIntent
        if (pi == null) {
            toast(ctx, "To powiadomienie nie ma akcji otwarcia")
            return
        }
        val cover = Prefs.coverDisplay(ctx)
        val ok = when (Prefs.openMode(ctx)) {
            1 -> send(ctx, pi, cover)
            2 -> send(ctx, pi, 0)
            else -> send(ctx, pi, cover) || send(ctx, pi, 0)
        }
        if (!ok) toast(ctx, "Nie udało się otworzyć")
        if (ok && Prefs.dismissAfterOpen(ctx)) NotifService.instance?.cancelNotification(sbn.key)
    }

    private fun send(ctx: Context, pi: PendingIntent, displayId: Int): Boolean = try {
        val opts = ActivityOptions.makeBasic().setLaunchDisplayId(displayId)
        if (Build.VERSION.SDK_INT >= 34) {
            opts.setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
        }
        pi.send(ctx, 0, null, null, null, null, opts.toBundle())
        true
    } catch (t: Throwable) {
        false
    }

    private fun reply(ctx: Context, sbn: android.service.notification.StatusBarNotification) {
        val text = Prefs.quickReply(ctx)
        val act = NotifService.replyAction(sbn)
        val inputs = act?.remoteInputs
        if (act == null || inputs == null || text.isBlank()) {
            toast(ctx, "Brak możliwości odpowiedzi")
            return
        }
        try {
            val results = Bundle()
            for (ri in inputs) results.putCharSequence(ri.resultKey, text)
            val fill = Intent()
            RemoteInput.addResultsToIntent(inputs, fill, results)
            act.actionIntent.send(ctx, 0, fill)
            toast(ctx, "Wysłano: $text")
        } catch (t: Throwable) {
            toast(ctx, "Odpowiedź nie wyszła: ${t.javaClass.simpleName}")
        }
    }

    private fun toast(ctx: Context, s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

    companion object {
        const val EXTRA_KEY = "key"
        const val ACTION_OPEN = "pl.melt.covertoolkit.OPEN"
        const val ACTION_REPLY = "pl.melt.covertoolkit.REPLY"
        const val ACTION_DISMISS = "pl.melt.covertoolkit.DISMISS"
    }
}
