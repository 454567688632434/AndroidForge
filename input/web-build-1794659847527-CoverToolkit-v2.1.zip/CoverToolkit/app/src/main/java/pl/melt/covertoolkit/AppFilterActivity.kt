package pl.melt.covertoolkit

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckedTextView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

/** Zaznaczone aplikacje = ich powiadomienia pokazujemy w widgecie. */
class AppFilterActivity : Activity() {

    private class Item(val pkg: String, val label: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val items = pm.queryIntentActivities(launcher, PackageManager.ResolveInfoFlags.of(0))
            .map { Item(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }

        val blocked = Prefs.blocked(this).toMutableSet()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(getColor(R.color.bg))
        root.setPadding(pad, pad, pad, 0)

        val title = TextView(this)
        title.text = "Aplikacje w widgecie"
        title.textSize = 22f
        title.setTypeface(title.typeface, Typeface.BOLD)
        title.setTextColor(getColor(R.color.text))
        root.addView(title)

        val hint = TextView(this)
        hint.text = "Zaznaczone = pokazuj ich powiadomienia. Odznacz, żeby ukryć."
        hint.textSize = 13f
        hint.setTextColor(getColor(R.color.sub))
        hint.setPadding(0, pad / 4, 0, pad / 2)
        root.addView(hint)

        val lv = ListView(this)
        lv.choiceMode = ListView.CHOICE_MODE_MULTIPLE
        lv.adapter = object : ArrayAdapter<Item>(this, android.R.layout.simple_list_item_multiple_choice, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as CheckedTextView
                v.text = getItem(position)?.label
                v.setTextColor(getColor(R.color.text))
                return v
            }
        }
        for (i in items.indices) lv.setItemChecked(i, items[i].pkg !in blocked)
        lv.setOnItemClickListener { _, _, pos, _ ->
            val pkg = items[pos].pkg
            if (lv.isItemChecked(pos)) blocked.remove(pkg) else blocked.add(pkg)
            Prefs.setBlocked(this, blocked)
            ToolkitWidget.refresh(applicationContext)
        }
        root.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }
}
