package app.coverrecents;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Insets;
import android.graphics.Outline;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Ustawienia aplikacji (ekran główny telefonu) w stylu One UI: duży nagłówek, zaokrąglone grupy
 * na tle #F6F6F6 / czerni, wiersze z podsumowaniem, niebieski akcent Samsunga.
 */
public class MainActivity extends Activity {

    private static final int BLUE = Look.ONEUI_BLUE;

    private LinearLayout content;
    private LinearLayout group;
    private TextView usageStatus;
    private TextView accessibilityStatus;
    private TextView lastSummary;
    private float density;
    private boolean dark;
    private int cardColor;
    private int textColor;
    private int subColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        density = getResources().getDisplayMetrics().density;
        dark = Look.isNight(this);
        int bg = dark ? 0xFF000000 : 0xFFF6F6F6;
        cardColor = dark ? 0xFF252525 : 0xFFFFFFFF;
        textColor = dark ? 0xFFFFFFFF : 0xFF000000;
        subColor = dark ? 0xFF9A9A9A : 0xFF767676;

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        scroll.setOnApplyWindowInsetsListener((v, insets) -> {
            Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsets.CONSUMED;
        });

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, 0, 0, dp(40));
        scroll.addView(content);
        setContentView(scroll);

        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private void updateStatus() {
        if (usageStatus != null) {
            usageStatus.setText(RecentApps.hasUsageAccess(this)
                    ? "Włączony" : "Brak - bez tego lista ostatnich jest pusta");
        }
        if (accessibilityStatus != null) {
            accessibilityStatus.setText(isAccessibilityEnabled()
                    ? "Włączona" : "Wyłączona (gest, miniatury i szkło)");
        }
    }

    private void rebuild() {
        content.removeAllViews();
        build();
        updateStatus();
    }

    // ---- zawartość ----

    private void build() {
        String style = Prefs.style(this);
        boolean glass = Prefs.STYLE_GLASS.equals(style);
        boolean preview = Prefs.STYLE_PREVIEW.equals(style);

        // Duży nagłówek jak w ustawieniach One UI.
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        head.setGravity(Gravity.BOTTOM);
        head.setPadding(dp(28), dp(48), dp(24), dp(22));
        head.addView(tv("Cover Recents", 34, textColor, false));
        TextView sub = tv("Ostatnie aplikacje na ekranie zewnętrznym Z Flip", 14, subColor, false);
        sub.setPadding(0, dp(4), 0, 0);
        head.addView(sub);
        content.addView(head, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(200)));

        newGroup("Uprawnienia");
        usageStatus = clickRow("Dostęp do użycia", v -> openUsageAccess());
        accessibilityStatus = clickRow("Usługa ułatwień dostępu",
                v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        newGroup("Sposoby otwierania");
        noteRow("1. Widżet. Dodaj widżet „Ostatnie aplikacje” na ekranie zewnętrznym (przesuń do "
                + "widżetów). Dotknięcie otwiera ostatnie aplikacje.");
        noteRow("2. Przytrzymanie paska powrotu do ekranu głównego. Zwykłe przesunięcie paska nadal "
                + "wraca do ekranu głównego. Wymaga usługi ułatwień dostępu. Jeśli przełącznik jest "
                + "wyszarzony: Ustawienia → Aplikacje → Cover Recents → ⋮ → Zezwól na ustawienia "
                + "z ograniczeniami.");
        switchRow("Gest przytrzymania paska", null, Prefs.HANDLE, false, false);
        sliderRow("Czas przytrzymania", Prefs.HOLD_MS, 500, 3000, 250, 2000, " ms");
        switchRow("Dopasuj do paska automatycznie", null, Prefs.HANDLE_AUTO, true, true);
        switchRow("Pokaż obszar gestu", "Pomaga ustawić gest", Prefs.HANDLE_VISIBLE, false, false);
        if (!Prefs.handleAutoOffset(this)) {
            sliderRow("Wysokość obszaru", Prefs.HANDLE_HEIGHT, 12, 80, 4, 28, " dp");
            sliderRow("Odstęp od dołu", Prefs.HANDLE_OFFSET, 0, 80, 4, 0, " dp");
        }

        newGroup("Motyw");
        choiceRow("Styl", Prefs.STYLE, Prefs.STYLE_ONEUI,
                new String[]{Prefs.STYLE_ONEUI, Prefs.STYLE_GLASS, Prefs.STYLE_PREVIEW},
                new String[]{"Samsung One UI", "Liquid glass", "Podgląd aplikacji"});
        choiceRow("Kolor", Prefs.THEME, Prefs.THEME_DARK,
                new String[]{Prefs.THEME_SYSTEM, Prefs.THEME_DARK, Prefs.THEME_LIGHT, Prefs.THEME_AMOLED},
                new String[]{"Automatyczny (jak system)", "Ciemny", "Jasny", "AMOLED (czerń)"});
        accentRow();

        newGroup(glass ? "Liquid glass" : preview ? "Podgląd aplikacji" : "Samsung One UI");
        sliderRow("Przyciemnienie tła", Prefs.dimKey(style), 0, 90, 5, Prefs.dimDefault(style), "%");
        if (!glass) {
            switchRow("Prawdziwe rozmycie tła",
                    "Własne rozmycie GPU na zrzucie tła, działa też przy wyłączonym rozmyciu systemu. "
                            + "Wymaga usługi ułatwień dostępu; bez niej rozmywa system.",
                    Prefs.REAL_BLUR, true, false);
        }
        sliderRow("Siła rozmycia tła", Prefs.BLUR_DP, 0, 100, 5, 50, " dp");
        if (glass) {
            sliderRow("Załamanie światła", Prefs.GLASS_REFRACT, 0, 100, 5, 60, "%");
            sliderRow("Połysk i światło krawędzi", Prefs.GLASS_SHINE, 0, 100, 5, 60, "%");
            switchRow("Rozszczepienie barw", "Delikatna dyspersja na krawędziach szkła",
                    Prefs.GLASS_DISPERSION, true, false);
            noteRow("Szkło renderuje shader na GPU. Prawdziwe załamanie tła wymaga włączonej usługi "
                    + "ułatwień dostępu (zrzut ekranu zewnętrznego). Bez niej szkło leży na tle "
                    + "rozmytym przez system.");
        } else {
            if (!preview) {
                sliderRow("Przezroczystość kart", Prefs.CARD_ALPHA, 10, 100, 5, 100, "%");
                switchRow("Matowe szkło na kartach",
                        "Karty pokazują rozmyte tło (potrzebne prawdziwe rozmycie)", Prefs.FROST, false, false);
            }
            switchRow("Obramowanie kart", null, Prefs.BORDER, false, false);
        }
        if (preview) {
            switchRow("Zapisuj miniatury aplikacji", "Zrzuty ekranu zewnętrznego, tylko lokalnie",
                    Prefs.SNAPSHOTS, true, false);
            noteRow("Miniatury powstają, gdy aplikacja jest na wierzchu ekranu zewnętrznego, oraz tuż "
                    + "przed otwarciem ostatnich gestem paska. Aplikacja bez miniatury pokazuje dużą "
                    + "ikonę. Okna chronione przed zrzutami (np. bankowość) nie mają podglądu. Po "
                    + "aktualizacji wyłącz i włącz usługę ułatwień dostępu.");
            buttonRow("Wyczyść zapisane miniatury", v -> {
                Snapshots.clearAll(this);
                Toast.makeText(this, "Miniatury usunięte", Toast.LENGTH_SHORT).show();
            });
        }

        newGroup("Zaokrąglenia");
        radiusRow();

        newGroup("Animacje");
        choiceRow("Styl animacji", Prefs.ANIM, Prefs.ANIM_ONEUI,
                new String[]{Prefs.ANIM_ONEUI, Prefs.ANIM_IOS, Prefs.ANIM_FLOW, Prefs.ANIM_NONE},
                new String[]{"One UI (krzywe sinusoidalne)", "iOS (sprężyna)",
                        "Cover Flow (obrót 3D)", "Wyłączone"});
        noteRow("Animacje to tylko transformacje GPU widocznych kart, więc nie obciążają baterii.");

        newGroup("Układ");
        boolean grid = Prefs.isGrid(this);
        choiceRow("Układ listy", Prefs.LAYOUT, Prefs.LAYOUT_CAROUSEL,
                new String[]{Prefs.LAYOUT_CAROUSEL, Prefs.LAYOUT_GRID},
                new String[]{"Karuzela (jak w Samsungu)", "Siatka"});
        if (grid) {
            sliderRow("Kolumny siatki", Prefs.COLUMNS, 2, 4, 1, 3, "");
        }
        switchRow("Nazwy aplikacji", null, Prefs.LABELS, true, false);
        switchRow("Przycisk „Zamknij wszystkie”", "Lewy dolny róg", Prefs.CLOSE_ALL, true, false);
        sliderRow("Liczba aplikacji na liście", Prefs.MAX_APPS, 4, 20, 1, 10, "");

        group = null;
        TextView open = pill("Podgląd na tym ekranie",
                v -> startActivity(new Intent(this, RecentsActivity.class)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(12), dp(24), dp(12), 0);
        content.addView(open, lp);
    }

    // ---- elementy One UI ----

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) {
            t.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        }
        return t;
    }

    private void newGroup(String header) {
        TextView h = tv(header, 14, BLUE, true);
        h.setPadding(dp(28), dp(24), dp(20), dp(8));
        content.addView(h);

        LinearLayout g = new LinearLayout(this);
        g.setOrientation(LinearLayout.VERTICAL);
        final int r = dp(26);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(cardColor);
        bg.setCornerRadius(r);
        g.setBackground(bg);
        g.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), r);
            }
        });
        g.setClipToOutline(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(12), 0, dp(12), 0);
        content.addView(g, lp);
        group = g;
    }

    private void selectable(View v) {
        TypedValue tv = new TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackground, tv, true);
        v.setBackgroundResource(tv.resourceId);
    }

    private LinearLayout rowH() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(22), dp(14), dp(22), dp(14));
        r.setMinimumHeight(dp(60));
        return r;
    }

    private LinearLayout textBlock(String title, String summary) {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        b.addView(tv(title, 16, textColor, false));
        lastSummary = null;
        if (summary != null) {
            TextView s = tv(summary, 13, subColor, false);
            s.setPadding(0, dp(2), 0, 0);
            b.addView(s);
            lastSummary = s;
        }
        return b;
    }

    private void add(View v) {
        group.addView(v, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void noteRow(String s) {
        TextView t = tv(s, 13, subColor, false);
        t.setPadding(dp(22), dp(12), dp(22), dp(12));
        t.setLineSpacing(0, 1.1f);
        add(t);
    }

    /** Wiersz otwierający ustawienia; zwraca pole podsumowania (stan). */
    private TextView clickRow(String title, View.OnClickListener l) {
        LinearLayout r = rowH();
        r.addView(textBlock(title, ""));
        TextView summary = lastSummary;
        selectable(r);
        r.setOnClickListener(l);
        add(r);
        return summary;
    }

    private void switchRow(String title, String summary, String key, boolean def, boolean rebuild) {
        LinearLayout r = rowH();
        r.addView(textBlock(title, summary), new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Switch sw = new Switch(this);
        sw.setChecked(Prefs.get(this).getBoolean(key, def));
        sw.setOnCheckedChangeListener((b, on) -> {
            Prefs.get(this).edit().putBoolean(key, on).apply();
            if (rebuild) {
                rebuild();
            }
        });
        r.addView(sw);
        selectable(r);
        r.setOnClickListener(v -> sw.toggle());
        add(r);
    }

    private void choiceRow(String title, String key, String def, String[] values, String[] names) {
        String cur = Prefs.get(this).getString(key, def);
        if (Prefs.STYLE.equals(key)) {
            cur = Prefs.style(this); // zmapowane wartości z poprzednich wersji
        }
        int idx = 0;
        for (int i = 0; i < values.length; i++) {
            if (values[i].equals(cur)) {
                idx = i;
            }
        }
        final int selected = idx;
        LinearLayout r = rowH();
        r.addView(textBlock(title, names[idx]));
        lastSummary.setTextColor(BLUE);
        selectable(r);
        r.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle(title)
                .setSingleChoiceItems(names, selected, (d, which) -> {
                    Prefs.get(this).edit().putString(key, values[which]).apply();
                    d.dismiss();
                    rebuild();
                })
                .setNegativeButton("Anuluj", null)
                .show());
        add(r);
    }

    private void sliderRow(String title, String key, int min, int max, int step, int def, String unit) {
        int current = Prefs.get(this).getInt(key, def);
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(dp(22), dp(14), dp(22), dp(8));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        TextView name = tv(title, 16, textColor, false);
        TextView value = tv(current + unit, 15, BLUE, true);
        top.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(value);
        r.addView(top);

        SeekBar bar = new SeekBar(this);
        bar.setMax((max - min) / step);
        bar.setProgress((current - min) / step);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                int v = min + progress * step;
                value.setText(v + unit);
                if (fromUser) {
                    Prefs.get(MainActivity.this).edit().putInt(key, v).apply();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        r.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        add(r);
    }

    private GradientDrawable shape(int fill, int radiusPx, int strokePx, int stroke, boolean oval) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(oval ? GradientDrawable.OVAL : GradientDrawable.RECTANGLE);
        d.setColor(fill);
        if (!oval) {
            d.setCornerRadius(radiusPx);
        }
        if (strokePx > 0) {
            d.setStroke(strokePx, stroke);
        }
        return d;
    }

    /** Akcent: neutralny, Samsung Blue i kolory obudowy Z Flip5. */
    private void accentRow() {
        String cur = Prefs.accent(this);
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(dp(14), dp(14), dp(14), dp(12));
        TextView t = tv("Kolor akcentu", 16, textColor, false);
        t.setPadding(dp(8), 0, 0, dp(10));
        r.addView(t);

        LinearLayout chips = new LinearLayout(this);
        for (int i = 0; i < Look.ACCENT_KEYS.length; i++) {
            final String key = Look.ACCENT_KEYS[i];
            boolean sel = key.equals(cur);
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);

            FrameLayout ring = new FrameLayout(this);
            ring.setBackground(shape(0, 0, sel ? dp(3) : 0, BLUE, true));
            View dot = new View(this);
            int color = Look.ACCENT_COLORS[i];
            dot.setBackground(color == 0
                    ? shape(0, 0, dp(2), subColor, true)
                    : shape(color, 0, dark ? 0 : dp(1), 0x22000000, true));
            ring.addView(dot, new FrameLayout.LayoutParams(dp(32), dp(32), Gravity.CENTER));
            cell.addView(ring, new LinearLayout.LayoutParams(dp(44), dp(44)));

            TextView n = tv(Look.ACCENT_NAMES[i], 10, subColor, false);
            n.setGravity(Gravity.CENTER);
            n.setSingleLine(true);
            n.setPadding(0, dp(4), 0, 0);
            cell.addView(n, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            cell.setOnClickListener(v -> {
                Prefs.get(this).edit().putString(Prefs.ACCENT, key).apply();
                rebuild();
            });
            chips.addView(cell, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        r.addView(chips);
        add(r);
    }

    /** Wybór zaokrągleń z podglądem kształtu karty. */
    private void radiusRow() {
        int cur = Prefs.radiusDp(this);
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(dp(14), dp(14), dp(14), dp(12));
        TextView t = tv("Zaokrąglenie kart", 16, textColor, false);
        t.setPadding(dp(8), 0, 0, dp(10));
        r.addView(t);

        LinearLayout chips = new LinearLayout(this);
        for (int i = 0; i < Look.RADII.length; i++) {
            final int dpv = Look.RADII[i];
            boolean sel = dpv == cur;
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);

            View box = new View(this);
            int fill = sel ? Look.blend(cardColor, BLUE, 0.25f) : (dark ? 0xFF3A3A3A : 0xFFE6E6E6);
            box.setBackground(shape(fill, dp(Math.min(26, Math.round(dpv * 0.6f))),
                    sel ? dp(2) : 0, BLUE, false));
            cell.addView(box, new LinearLayout.LayoutParams(dp(52), dp(60)));

            TextView n = tv(Look.RADIUS_NAMES[i], 11, sel ? BLUE : subColor, sel);
            n.setGravity(Gravity.CENTER);
            n.setSingleLine(true);
            n.setPadding(0, dp(6), 0, 0);
            cell.addView(n, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            TextView v2 = tv(dpv + " dp", 10, subColor, false);
            v2.setGravity(Gravity.CENTER);
            cell.addView(v2, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            cell.setOnClickListener(v -> {
                Prefs.get(this).edit().putInt(Prefs.RADIUS_DP, dpv).apply();
                rebuild();
            });
            chips.addView(cell, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        r.addView(chips);
        add(r);
    }

    private TextView pill(String label, View.OnClickListener l) {
        TextView b = tv(label, 15, BLUE, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(20), dp(14), dp(20), dp(14));
        b.setBackground(shape(Look.blend(cardColor, BLUE, dark ? 0.22f : 0.12f), dp(30), 0, 0, false));
        b.setOnClickListener(l);
        return b;
    }

    private void buttonRow(String label, View.OnClickListener l) {
        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(14), dp(4), dp(14), dp(14));
        box.addView(pill(label, l));
        add(box);
    }

    private int dp(int value) {
        return Math.round(value * density);
    }

    // ---- uprawnienia ----

    private void openUsageAccess() {
        try {
            startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS,
                    Uri.parse("package:" + getPackageName())));
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
        }
    }

    private boolean isAccessibilityEnabled() {
        String enabled = Settings.Secure.getString(
                getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) {
            return false;
        }
        ComponentName mine = new ComponentName(this, RecentsService.class);
        for (String entry : enabled.split(":")) {
            if (mine.equals(ComponentName.unflattenFromString(entry))) {
                return true;
            }
        }
        return false;
    }
}
