package app.coverrecents;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

/**
 * Opcjonalny uchwyt gestu: cienki, niewidoczny pasek przy dolnej krawędzi ekranu zewnętrznego.
 * Przesunięcie w górę i przytrzymanie otwiera ekran ostatnich aplikacji.
 *
 * Domyślnie wyłączony (Ustawienia -> Uchwyt gestu), bo każdy pasek przechwytuje dotyk w swoim
 * obszarze. Wymiary i położenie są konfigurowalne.
 */
public class RecentsService extends AccessibilityService {

    private static final String TAG = "CoverRecents";

    private static final int SWIPE_DISTANCE_DP = 40;
    private static final int HOLD_SLOP_DP = 12;

    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable reattach = new Runnable() {
        @Override
        public void run() {
            detachOverlay();
            attachOverlay();
        }
    };

    private final SharedPreferences.OnSharedPreferenceChangeListener prefListener =
            (prefs, key) -> {
                if (key == null) {
                    return;
                }
                switch (key) {
                    case Prefs.HANDLE:
                    case Prefs.HANDLE_VISIBLE:
                    case Prefs.HANDLE_HEIGHT:
                    case Prefs.HANDLE_OFFSET:
                        handler.removeCallbacks(reattach);
                        handler.postDelayed(reattach, 250);
                        break;
                    default:
                        break;
                }
            };

    private final DisplayManager.DisplayListener displayListener =
            new DisplayManager.DisplayListener() {
                @Override
                public void onDisplayAdded(int displayId) {
                    if (displayId == CoverLauncher.COVER_DISPLAY_ID) {
                        attachOverlay();
                    }
                }

                @Override
                public void onDisplayRemoved(int displayId) {
                    if (displayId == CoverLauncher.COVER_DISPLAY_ID) {
                        detachOverlay();
                    }
                }

                @Override
                public void onDisplayChanged(int displayId) {
                }
            };

    private WindowManager overlayWindowManager;
    private View overlay;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        getSystemService(DisplayManager.class).registerDisplayListener(displayListener, handler);
        Prefs.get(this).registerOnSharedPreferenceChangeListener(prefListener);
        attachOverlay();
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        cleanup();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        cleanup();
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Zdarzenia nie są potrzebne - usługa służy tylko do okna z gestem.
    }

    @Override
    public void onInterrupt() {
    }

    private void cleanup() {
        handler.removeCallbacksAndMessages(null);
        Prefs.get(this).unregisterOnSharedPreferenceChangeListener(prefListener);
        DisplayManager dm = getSystemService(DisplayManager.class);
        if (dm != null) {
            dm.unregisterDisplayListener(displayListener);
        }
        detachOverlay();
    }

    private void attachOverlay() {
        if (overlay != null || !Prefs.handleEnabled(this)) {
            return;
        }
        DisplayManager dm = getSystemService(DisplayManager.class);
        Display display = dm.getDisplay(CoverLauncher.COVER_DISPLAY_ID);
        if (display == null) {
            Log.w(TAG, "Brak display " + CoverLauncher.COVER_DISPLAY_ID + " - to nie jest Z Flip?");
            return;
        }
        try {
            Context ctx = createDisplayContext(display)
                    .createWindowContext(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, null);
            WindowManager wm = ctx.getSystemService(WindowManager.class);
            float density = ctx.getResources().getDisplayMetrics().density;

            View view = new View(ctx);
            if (Prefs.handleVisible(this)) {
                view.setBackgroundColor(0x40FFFFFF);
            }
            view.setOnTouchListener(new SwipeHoldListener(density));

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    Math.round(Prefs.handleHeightDp(this) * density),
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.BOTTOM;
            lp.y = Math.round(Prefs.handleOffsetDp(this) * density);

            wm.addView(view, lp);
            overlayWindowManager = wm;
            overlay = view;
            Log.i(TAG, "Uchwyt gestu dodany na display " + CoverLauncher.COVER_DISPLAY_ID);
        } catch (RuntimeException e) {
            Log.e(TAG, "Nie udało się dodać uchwytu na ekran zewnętrzny", e);
        }
    }

    private void detachOverlay() {
        if (overlay != null && overlayWindowManager != null) {
            try {
                overlayWindowManager.removeView(overlay);
            } catch (RuntimeException e) {
                Log.w(TAG, "removeView nie powiodło się", e);
            }
        }
        overlay = null;
        overlayWindowManager = null;
    }

    /** Gest: przesunięcie w górę o SWIPE_DISTANCE_DP, a potem przytrzymanie przez czas z ustawień. */
    private final class SwipeHoldListener implements View.OnTouchListener {
        private final float swipePx;
        private final float slopPx;

        private float downY;
        private float anchorX;
        private float anchorY;
        private boolean armed;
        private boolean fired;
        private View touchedView;

        private final Runnable fire = new Runnable() {
            @Override
            public void run() {
                fired = true;
                if (touchedView != null) {
                    touchedView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                }
                CoverLauncher.openRecentsOnCover(RecentsService.this);
            }
        };

        SwipeHoldListener(float density) {
            swipePx = SWIPE_DISTANCE_DP * density;
            slopPx = HOLD_SLOP_DP * density;
        }

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    handler.removeCallbacks(fire);
                    touchedView = v;
                    downY = e.getRawY();
                    armed = false;
                    fired = false;
                    return true;

                case MotionEvent.ACTION_MOVE:
                    if (fired) {
                        return true;
                    }
                    if (downY - e.getRawY() >= swipePx) {
                        if (!armed) {
                            armed = true;
                            startHold(e);
                        } else if (Math.hypot(e.getRawX() - anchorX, e.getRawY() - anchorY) > slopPx) {
                            // Palec nadal się rusza - odliczanie przytrzymania od nowa.
                            startHold(e);
                        }
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    handler.removeCallbacks(fire);
                    armed = false;
                    return true;

                default:
                    return true;
            }
        }

        private void startHold(MotionEvent e) {
            anchorX = e.getRawX();
            anchorY = e.getRawY();
            handler.removeCallbacks(fire);
            handler.postDelayed(fire, Prefs.holdMs(RecentsService.this));
        }
    }
}
