package app.coverrecents;

import android.content.Context;
import android.content.SharedPreferences;

/** Wszystkie ustawienia aplikacji w jednym miejscu. */
final class Prefs {

    static final String LAYOUT = "layout";
    static final String COLUMNS = "columns";
    static final String LABELS = "labels";
    static final String CLOSE_ALL = "close_all";
    static final String MAX_APPS = "max_apps";

    static final String HANDLE = "handle";
    static final String HANDLE_VISIBLE = "handle_visible";
    static final String HANDLE_HEIGHT = "handle_height";
    static final String HANDLE_OFFSET = "handle_offset";
    static final String HOLD_MS = "hold_ms";

    static final String LAYOUT_CAROUSEL = "carousel";
    static final String LAYOUT_GRID = "grid";

    private Prefs() {
    }

    static SharedPreferences get(Context c) {
        return c.getApplicationContext().getSharedPreferences("settings", Context.MODE_PRIVATE);
    }

    static boolean isGrid(Context c) {
        return LAYOUT_GRID.equals(get(c).getString(LAYOUT, LAYOUT_CAROUSEL));
    }

    static int columns(Context c) {
        return get(c).getInt(COLUMNS, 3);
    }

    static boolean showLabels(Context c) {
        return get(c).getBoolean(LABELS, true);
    }

    static boolean showCloseAll(Context c) {
        return get(c).getBoolean(CLOSE_ALL, true);
    }

    static int maxApps(Context c) {
        return get(c).getInt(MAX_APPS, 10);
    }

    static boolean handleEnabled(Context c) {
        return get(c).getBoolean(HANDLE, false);
    }

    static boolean handleVisible(Context c) {
        return get(c).getBoolean(HANDLE_VISIBLE, false);
    }

    static int handleHeightDp(Context c) {
        return get(c).getInt(HANDLE_HEIGHT, 28);
    }

    static int handleOffsetDp(Context c) {
        return get(c).getInt(HANDLE_OFFSET, 16);
    }

    static int holdMs(Context c) {
        return get(c).getInt(HOLD_MS, 250);
    }
}
