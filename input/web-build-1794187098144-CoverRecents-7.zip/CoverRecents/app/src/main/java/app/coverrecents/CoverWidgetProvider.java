package app.coverrecents;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;

/** Widżet ekranu zewnętrznego: jeden duży przycisk otwierający ostatnie aplikacje. */
public class CoverWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        for (int id : appWidgetIds) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_cover);
            views.setOnClickPendingIntent(R.id.widget_root, CoverLauncher.recentsPendingIntent(context));
            manager.updateAppWidget(id, views);
        }
    }
}
