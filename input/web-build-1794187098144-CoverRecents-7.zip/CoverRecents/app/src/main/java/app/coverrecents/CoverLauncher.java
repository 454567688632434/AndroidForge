package app.coverrecents;

import android.app.ActivityOptions;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/** Otwieranie ekranu ostatnich aplikacji na ekranie zewnętrznym (display 1). */
final class CoverLauncher {

    static final int COVER_DISPLAY_ID = 1;
    private static final String TAG = "CoverRecents";

    private CoverLauncher() {
    }

    private static Intent recentsIntent(Context c) {
        return new Intent(c, RecentsActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    }

    private static ActivityOptions coverOptions() {
        ActivityOptions options = ActivityOptions.makeBasic();
        options.setLaunchDisplayId(COVER_DISPLAY_ID);
        return options;
    }

    /** Start z poziomu usługi/aktywności aplikacji. Zwraca false, gdy system odmówi. */
    static boolean openRecentsOnCover(Context c) {
        try {
            c.startActivity(recentsIntent(c), coverOptions().toBundle());
            return true;
        } catch (RuntimeException e) {
            Log.w(TAG, "Nie udało się otworzyć ostatnich na display " + COVER_DISPLAY_ID, e);
            return false;
        }
    }

    /** Wersja dla widżetu: Samsung dokumentuje start aktywności na cover przez PendingIntent. */
    static PendingIntent recentsPendingIntent(Context c) {
        return PendingIntent.getActivity(
                c,
                0,
                recentsIntent(c),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE,
                coverOptions().toBundle());
    }
}
