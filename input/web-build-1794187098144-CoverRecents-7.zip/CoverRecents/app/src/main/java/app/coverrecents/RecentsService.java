package app.coverrecents;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Insets;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

/**
 * Gest przytrzymania paska: niewidoczne okno dokładnie na systemowym pasku powrotu do ekranu
 * głównego (przy dolnej krawędzi ekranu zewnętrznego). Przytrzymanie paska przez kilka sekund
 * otwiera ekran ostatnich aplikacji.
 *
 * Okno ma wysokość samego paska, więc reszta ekranu działa normalnie. Ruch palca poza małą
 * tolerancję anuluje przytrzymanie, więc zwykłe przesunięcie w górę (powrót do ekranu głównego)
 * nie uruchamia ostatnich - ten gest nadal obsługuje system.
 */
public class RecentsService extends AccessibilityService {

    private static final String TAG = "CoverRecents";

    private static final int HOLD_SLOP_DP = 10;
    private static final int MIN_BAR_HEIGHT_DP = 20;

    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable reattach = new Runnable() {
        @Override
        public void run() {
            detachOverlay();
            attachOverlay();
        }
    };

    private final SharedPreferences.OnSharedPreferenceChangeListener prefListener =
            (prefs, key) -> {
                if (key == null) {
                    return;
                }
                switch (key) {
                    case Prefs.HANDLE:
                    case Prefs.HANDLE_VISIBLE:
                    case Prefs.HANDLE_HEIGHT:
                    case Prefs.HANDLE_OFFSET:
                    case Prefs.HANDLE_AUTO:
                        handler.removeCallbacks(reattach);
                        handler.postDelayed(reattach, 250);
                        break;
                    default:
                        break;
                }
            };

    private final DisplayManager.DisplayListener displayListener =
            new DisplayManager.DisplayListener() {
                @Override
                public void onDisplayAdded(int displayId) {
                    if (displayId == CoverLauncher.COVER_DISPLAY_ID) {
                        attachOverlay();
                    }
                }

                @Override
                public void onDisplayRemoved(int displayId) {
                    if (displayId == CoverLauncher.COVER_DISPLAY_ID) {
                        detachOverlay();
                    }
                }

                @Override
                public void onDisplayChanged(int displayId) {
                }
            };

    private WindowManager overlayWindowManager;
    private View overlay;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        getSystemService(DisplayManager.class).registerDisplayListener(displayListener, handler);
        Prefs.get(this).registerOnSharedPreferenceChangeListener(prefListener);
        attachOverlay();
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        cleanup();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        cleanup();
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Zdarzenia nie są potrzebne - usługa służy tylko do okna z gestem.
    }

    @Override
    public void onInterrupt() {
    }

    private void cleanup() {
        handler.removeCallbacksAndMessages(null);
        Prefs.get(this).unregisterOnSharedPreferenceChangeListener(prefListener);
        DisplayManager dm = getSystemService(DisplayManager.class);
        if (dm != null) {
            dm.unregisterDisplayListener(displayListener);
        }
        detachOverlay();
    }

    private void attachOverlay() {
        if (overlay != null || !Prefs.handleEnabled(this)) {
            return;
        }
        DisplayManager dm = getSystemService(DisplayManager.class);
        Display display = dm.getDisplay(CoverLauncher.COVER_DISPLAY_ID);
        if (display == null) {
            Log.w(TAG, "Brak display " + CoverLauncher.COVER_DISPLAY_ID + " - to nie jest Z Flip?");
            return;
        }
        try {
            Context ctx = createDisplayContext(display)
                    .createWindowContext(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, null);
            WindowManager wm = ctx.getSystemService(WindowManager.class);
            float density = ctx.getResources().getDisplayMetrics().density;

            int heightPx;
            int offsetPx;
            if (Prefs.handleAutoOffset(this)) {
                // Dokładnie na pasku nawigacji: wysokość = wysokość paska systemowego.
                Insets nav = wm.getCurrentWindowMetrics().getWindowInsets()
                        .getInsetsIgnoringVisibility(WindowInsets.Type.navigationBars());
                heightPx = Math.max(nav.bottom, Math.round(MIN_BAR_HEIGHT_DP * density));
                offsetPx = 0;
            } else {
                heightPx = Math.round(Prefs.handleHeightDp(this) * density);
                offsetPx = Math.round(Prefs.handleOffsetDp(this) * density);
            }

            View view = new View(ctx);
            if (Prefs.handleVisible(this)) {
                view.setBackgroundColor(0x40FFFFFF);
            }
            view.setOnTouchListener(new BarHoldListener(density));

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    heightPx,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.BOTTOM;
            lp.y = offsetPx;
            // Okno liczone od fizycznej krawędzi ekranu, a nie od krawędzi paska systemowego.
            lp.setFitInsetsTypes(0);

            wm.addView(view, lp);
            overlayWindowManager = wm;
            overlay = view;
            Log.i(TAG, "Gest paska dodany na display " + CoverLauncher.COVER_DISPLAY_ID
                    + " (wysokość " + heightPx + " px, odstęp " + offsetPx + " px)");
        } catch (RuntimeException e) {
            Log.e(TAG, "Nie udało się dodać gestu na ekran zewnętrzny", e);
        }
    }

    private void detachOverlay() {
        if (overlay != null && overlayWindowManager != null) {
            try {
                overlayWindowManager.removeView(overlay);
            } catch (RuntimeException e) {
                Log.w(TAG, "removeView nie powiodło się", e);
            }
        }
        overlay = null;
        overlayWindowManager = null;
    }

    /** Długie przytrzymanie w jednym miejscu; ruch poza tolerancję anuluje. */
    private final class BarHoldListener implements View.OnTouchListener {
        private final float slopPx;

        private float downX;
        private float downY;
        private View touchedView;

        private final Runnable fire = new Runnable() {
            @Override
            public void run() {
                if (touchedView != null) {
                    touchedView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                }
                CoverLauncher.openRecentsOnCover(RecentsService.this);
            }
        };

        BarHoldListener(float density) {
            slopPx = HOLD_SLOP_DP * density;
        }

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    touchedView = v;
                    downX = e.getRawX();
                    downY = e.getRawY();
                    handler.removeCallbacks(fire);
                    handler.postDelayed(fire, Prefs.holdMs(RecentsService.this));
                    return true;

                case MotionEvent.ACTION_MOVE:
                    if (Math.hypot(e.getRawX() - downX, e.getRawY() - downY) > slopPx) {
                        // Palec się przesuwa (np. powrót do ekranu głównego) - to nie przytrzymanie.
                        handler.removeCallbacks(fire);
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    handler.removeCallbacks(fire);
                    return true;

                default:
                    return true;
            }
        }
    }
}
