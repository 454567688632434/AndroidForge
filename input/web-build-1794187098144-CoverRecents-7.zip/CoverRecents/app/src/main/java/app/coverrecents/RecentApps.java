package app.coverrecents;

import android.Manifest;
import android.app.ActivityManager;
import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Process;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Lista ostatnio używanych aplikacji.
 *
 * Zwykła aplikacja nie ma dostępu do prawdziwej listy zadań Androida, więc korzystamy z
 * UsageStatsManager (uprawnienie "Dostęp do użycia"): bierzemy zdarzenia wznowienia aktywności
 * z ostatnich dni i sortujemy po czasie. "Zamknięte" aplikacje zapamiętujemy z czasem zamknięcia -
 * wracają na listę dopiero po ponownym użyciu.
 */
final class RecentApps {

    static final class App {
        final String pkg;
        final String label;
        final Drawable icon;
        final long lastUsed;

        App(String pkg, String label, Drawable icon, long lastUsed) {
            this.pkg = pkg;
            this.label = label;
            this.icon = icon;
            this.lastUsed = lastUsed;
        }
    }

    private static final long WINDOW_MS = 3L * 24 * 60 * 60 * 1000;
    private static final String DISMISSED = "dismissed";

    private RecentApps() {
    }

    static boolean hasUsageAccess(Context c) {
        AppOpsManager ops = c.getSystemService(AppOpsManager.class);
        int mode = ops.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.getPackageName());
        if (mode == AppOpsManager.MODE_DEFAULT) {
            return c.checkCallingOrSelfPermission(Manifest.permission.PACKAGE_USAGE_STATS)
                    == PackageManager.PERMISSION_GRANTED;
        }
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    static List<App> load(Context c, int max) {
        List<App> result = new ArrayList<>();
        if (!hasUsageAccess(c)) {
            return result;
        }
        PackageManager pm = c.getPackageManager();
        SharedPreferences dismissed = c.getSharedPreferences(DISMISSED, Context.MODE_PRIVATE);
        Set<String> skip = ignoredPackages(c);

        UsageStatsManager usm = c.getSystemService(UsageStatsManager.class);
        long now = System.currentTimeMillis();
        UsageEvents events = usm.queryEvents(now - WINDOW_MS, now);

        Map<String, Long> last = new HashMap<>();
        UsageEvents.Event e = new UsageEvents.Event();
        while (events.hasNextEvent()) {
            events.getNextEvent(e);
            if (e.getEventType() != UsageEvents.Event.ACTIVITY_RESUMED) {
                continue;
            }
            String p = e.getPackageName();
            if (p == null || skip.contains(p)) {
                continue;
            }
            Long old = last.get(p);
            if (old == null || e.getTimeStamp() > old) {
                last.put(p, e.getTimeStamp());
            }
        }

        List<Map.Entry<String, Long>> sorted = new ArrayList<>(last.entrySet());
        Collections.sort(sorted, (a, b) -> Long.compare(b.getValue(), a.getValue()));

        for (Map.Entry<String, Long> entry : sorted) {
            if (result.size() >= max) {
                break;
            }
            String p = entry.getKey();
            if (entry.getValue() <= dismissed.getLong(p, 0L)) {
                continue;
            }
            if (pm.getLaunchIntentForPackage(p) == null) {
                continue;
            }
            try {
                ApplicationInfo ai = pm.getApplicationInfo(p, 0);
                result.add(new App(
                        p,
                        String.valueOf(pm.getApplicationLabel(ai)),
                        pm.getApplicationIcon(ai),
                        entry.getValue()));
            } catch (PackageManager.NameNotFoundException ignored) {
                // aplikacja odinstalowana - pomijamy
            }
        }
        return result;
    }

    /** Chowa aplikację z listy do czasu jej ponownego użycia. */
    static void dismiss(Context c, String pkg) {
        c.getSharedPreferences(DISMISSED, Context.MODE_PRIVATE)
                .edit().putLong(pkg, System.currentTimeMillis()).apply();
    }

    /** Chowa aplikację z listy i kończy jej procesy działające w tle. */
    static void close(Context c, String pkg) {
        ActivityManager am = c.getSystemService(ActivityManager.class);
        try {
            am.killBackgroundProcesses(pkg);
        } catch (RuntimeException ignored) {
            // brak uprawnienia lub proces już zakończony
        }
        dismiss(c, pkg);
    }

    private static Set<String> ignoredPackages(Context c) {
        Set<String> skip = new HashSet<>();
        skip.add(c.getPackageName());
        skip.add("android");
        skip.add("com.android.systemui");
        skip.add("com.sec.android.app.launcher");
        Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        ResolveInfo ri = c.getPackageManager().resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY);
        if (ri != null && ri.activityInfo != null) {
            skip.add(ri.activityInfo.packageName);
        }
        return skip;
    }
}
