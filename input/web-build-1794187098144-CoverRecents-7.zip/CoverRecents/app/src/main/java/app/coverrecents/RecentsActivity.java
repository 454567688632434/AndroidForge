package app.coverrecents;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * Ekran ostatnich aplikacji.
 *
 * Układ: karuzela (jak w Samsungu, przesunięcie karty w górę zamyka aplikację) albo siatka
 * (przesunięcie w bok zamyka). Przycisk X w lewym dolnym rogu zamyka wszystkie. Dotknięcie
 * tła zamyka ekran.
 *
 * Wygląd: motyw (systemowy, ciemny, biały, AMOLED) i styl (standardowy, rozmycie tła jak w
 * Samsungu, liquid glass). Rozmycie działa tylko, gdy system pozwala na rozmycie okien.
 */
public class RecentsActivity extends Activity {

    private static final String TAG = "CoverRecents";

    private static final class Palette {
        boolean dark;
        int scrim;
        int card;
        int text;
        int textDim;
        int closeBg;
        int closeIcon;
    }

    private final List<RecentApps.App> items = new ArrayList<>();

    private RecyclerView list;
    private TextView emptyView;
    private Adapter adapter;
    private Palette palette;

    private boolean grid;
    private boolean labels;
    private boolean glass;
    private boolean amoled;
    private float density;
    private int cardWidth;
    private int cardHeight;
    private int cellWidth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        density = dm.density;
        int w = dm.widthPixels;
        int h = dm.heightPixels;
        grid = Prefs.isGrid(this);
        labels = Prefs.showLabels(this);

        String theme = Prefs.theme(this);
        String style = Prefs.style(this);
        glass = Prefs.STYLE_GLASS.equals(style);
        amoled = Prefs.THEME_AMOLED.equals(theme);

        // Tło okna: kolor z przezroczystością + (opcjonalnie) rozmycie tego, co jest za oknem.
        boolean blurOn = getWindowManager().isCrossWindowBlurEnabled();
        palette = buildPalette(theme, style, blurOn);
        Window window = getWindow();
        window.setBackgroundDrawable(new ColorDrawable(palette.scrim));
        boolean wantsBlur = !Prefs.STYLE_STANDARD.equals(style);
        window.setBackgroundBlurRadius(wantsBlur && blurOn ? dp(Prefs.blurDp(this)) : 0);

        FrameLayout root = new FrameLayout(this);

        list = new RecyclerView(this);
        list.setClipToPadding(false);
        list.setOverScrollMode(View.OVER_SCROLL_NEVER);
        adapter = new Adapter();
        list.setAdapter(adapter);

        if (grid) {
            int columns = Math.max(2, Math.min(4, Prefs.columns(this)));
            int side = dp(12);
            cellWidth = (w - 2 * side) / columns;
            list.setLayoutManager(new GridLayoutManager(this, columns));
            list.setPadding(side, dp(24), side, dp(96));
        } else {
            cardWidth = Math.round(w * 0.60f);
            cardHeight = Math.round(h * 0.62f);
            int sidePad = Math.max(0, (w - cardWidth) / 2 - dp(8));
            int topPad = Math.max(dp(16), (h - cardHeight) / 2 - dp(24));
            list.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
            list.setPadding(sidePad, topPad, sidePad, 0);
            new LinearSnapHelper().attachToRecyclerView(list);
        }
        root.addView(list, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        emptyView = new TextView(this);
        emptyView.setTextColor(palette.textDim);
        emptyView.setTextSize(16);
        emptyView.setGravity(Gravity.CENTER);
        emptyView.setPadding(dp(32), 0, dp(32), 0);
        root.addView(emptyView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));

        if (Prefs.showCloseAll(this)) {
            ImageButton close = new ImageButton(this);
            close.setImageResource(R.drawable.ic_close);
            close.setColorFilter(palette.closeIcon);
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.OVAL);
            bg.setColor(palette.closeBg);
            if (glass) {
                bg.setStroke(dp(1), palette.dark ? 0x55FFFFFF : 0xCCFFFFFF);
            }
            close.setBackground(bg);
            close.setContentDescription("Zamknij wszystkie");
            close.setOnClickListener(v -> closeAll());
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    dp(56), dp(56), Gravity.BOTTOM | Gravity.START);
            lp.setMargins(dp(20), 0, 0, dp(20));
            root.addView(close, lp);
        }

        setContentView(root);

        int swipeDirs = grid
                ? (ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT)
                : ItemTouchHelper.UP;
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, swipeDirs) {
            @Override
            public boolean onMove(RecyclerView rv, RecyclerView.ViewHolder vh,
                                  RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder vh, int direction) {
                int pos = vh.getBindingAdapterPosition();
                if (pos == RecyclerView.NO_POSITION) {
                    return;
                }
                RecentApps.App app = items.remove(pos);
                adapter.notifyItemRemoved(pos);
                RecentApps.close(RecentsActivity.this, app.pkg);
                updateEmpty();
            }
        }).attachToRecyclerView(list);

        // Dotknięcie pustego tła zamyka ekran (jak w Samsungu).
        final GestureDetector tap = new GestureDetector(this,
                new GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onSingleTapUp(MotionEvent e) {
                        if (list.findChildViewUnder(e.getX(), e.getY()) == null) {
                            finish();
                        }
                        return false;
                    }
                });
        list.addOnItemTouchListener(new RecyclerView.SimpleOnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {
                tap.onTouchEvent(e);
                return false;
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        reload();
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Jak systemowe ostatnie: po wyjściu (home, wygaszenie, start aplikacji) ekran znika.
        if (!isChangingConfigurations()) {
            finish();
        }
    }

    // ---- motyw i styl ----

    private static int rgb(int color) {
        return color & 0x00FFFFFF;
    }

    private Palette buildPalette(String theme, String style, boolean blurOn) {
        boolean night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        boolean isAmoled = Prefs.THEME_AMOLED.equals(theme);

        boolean dark;
        switch (theme) {
            case Prefs.THEME_DARK:
            case Prefs.THEME_AMOLED:
                dark = true;
                break;
            case Prefs.THEME_LIGHT:
                dark = false;
                break;
            default:
                dark = night;
                break;
        }

        int scrimRgb;
        int cardRgb;
        int textRgb;
        if (isAmoled) {
            scrimRgb = 0x000000;
            cardRgb = 0x151517;
            textRgb = 0xFFFFFF;
        } else if (Prefs.THEME_SYSTEM.equals(theme)) {
            // Kolory z palety urządzenia (Material You).
            scrimRgb = rgb(getColor(dark
                    ? android.R.color.system_neutral1_900
                    : android.R.color.system_neutral1_100));
            cardRgb = rgb(getColor(dark
                    ? android.R.color.system_neutral1_800
                    : android.R.color.system_neutral1_10));
            textRgb = rgb(getColor(dark
                    ? android.R.color.system_neutral1_10
                    : android.R.color.system_neutral1_900));
        } else if (dark) {
            scrimRgb = 0x101014;
            cardRgb = 0x26262B;
            textRgb = 0xFFFFFF;
        } else {
            scrimRgb = 0xF2F2F6;
            cardRgb = 0xFFFFFF;
            textRgb = 0x111114;
        }

        int scrimA;
        int cardA;
        if (Prefs.STYLE_BLUR.equals(style)) {
            // Rozmycie tła jak w Samsungu: lekkie przyciemnienie na rozmytym tle.
            scrimA = blurOn ? (dark ? 0x80 : 0x66) : 0xD8;
            cardA = blurOn ? 0xE6 : 0xFF;
        } else if (Prefs.STYLE_GLASS.equals(style)) {
            // Liquid glass: bardzo lekki odcień, karty rysowane jako szkło.
            scrimA = blurOn ? (dark ? 0x4D : 0x40) : 0xC0;
            cardA = 0xFF;
        } else {
            scrimA = isAmoled ? 0xFF : (dark ? 0xE8 : 0xF2);
            cardA = 0xFF;
        }

        Palette p = new Palette();
        p.dark = dark;
        p.scrim = (scrimA << 24) | scrimRgb;
        p.card = (cardA << 24) | cardRgb;
        p.text = 0xFF000000 | textRgb;
        p.textDim = 0xB3000000 | textRgb;
        p.closeBg = dark ? 0x33FFFFFF : 0x22000000;
        p.closeIcon = dark ? 0xFFFFFFFF : 0xFF111114;
        return p;
    }

    /** Nowy obiekt przy każdym wywołaniu (drawable ma stan, nie współdzielimy go). */
    private GradientDrawable cardBackground() {
        GradientDrawable d;
        if (glass) {
            int hi = palette.dark ? 0x40FFFFFF : 0xB3FFFFFF;
            int lo = palette.dark ? 0x12FFFFFF : 0x66FFFFFF;
            d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{hi, lo});
            d.setCornerRadius(dp(32));
            d.setStroke(dp(1), palette.dark ? 0x55FFFFFF : 0xCCFFFFFF);
        } else {
            d = new GradientDrawable();
            d.setColor(palette.card);
            d.setCornerRadius(dp(28));
            if (amoled) {
                // Na czystej czerni karta bez ramki by się zlewała.
                d.setStroke(dp(1), 0x22FFFFFF);
            }
        }
        return d;
    }

    // ---- dane i akcje ----

    private void reload() {
        items.clear();
        items.addAll(RecentApps.load(this, Prefs.maxApps(this)));
        adapter.notifyDataSetChanged();
        updateEmpty();
    }

    private void updateEmpty() {
        boolean none = items.isEmpty();
        emptyView.setVisibility(none ? View.VISIBLE : View.GONE);
        if (none) {
            emptyView.setText(RecentApps.hasUsageAccess(this)
                    ? "Brak ostatnich aplikacji"
                    : "Przyznaj dostęp do użycia w aplikacji Cover Recents (na ekranie głównym telefonu)");
        }
    }

    private void closeAll() {
        // Zamykamy też aplikacje starsze niż te widoczne na liście.
        for (RecentApps.App app : RecentApps.load(this, Integer.MAX_VALUE)) {
            RecentApps.close(this, app.pkg);
        }
        items.clear();
        adapter.notifyDataSetChanged();
        list.animate().alpha(0f).setDuration(160).withEndAction(this::finish).start();
    }

    private void launch(RecentApps.App app) {
        Intent intent = getPackageManager().getLaunchIntentForPackage(app.pkg);
        if (intent == null) {
            Toast.makeText(this, "Nie można uruchomić: " + app.label, Toast.LENGTH_SHORT).show();
            return;
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        ActivityOptions options = ActivityOptions.makeBasic();
        Display display = getDisplay();
        if (display != null) {
            options.setLaunchDisplayId(display.getDisplayId());
        }
        try {
            startActivity(intent, options.toBundle());
        } catch (RuntimeException e) {
            Log.w(TAG, "Start z wymuszonym ekranem nie powiódł się, próbuję domyślnie", e);
            try {
                startActivity(intent);
            } catch (RuntimeException e2) {
                Log.e(TAG, "Nie udało się uruchomić " + app.pkg, e2);
                Toast.makeText(this, "Nie można uruchomić: " + app.label, Toast.LENGTH_SHORT).show();
                return;
            }
        }
        finish();
    }

    private int dp(int value) {
        return Math.round(value * density);
    }

    private static final class Holder extends RecyclerView.ViewHolder {
        final ImageView icon;
        final TextView label;

        Holder(View itemView, ImageView icon, TextView label) {
            super(itemView);
            this.icon = icon;
            this.label = label;
        }
    }

    private final class Adapter extends RecyclerView.Adapter<Holder> {

        @Override
        public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
            LinearLayout card = new LinearLayout(RecentsActivity.this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER);

            int iconSize;
            if (grid) {
                iconSize = dp(56);
                card.setPadding(dp(4), dp(10), dp(4), dp(10));
                if (glass) {
                    // W stylu szkła każda ikona leży na własnej szklanej płytce.
                    card.setBackground(cardBackground());
                    RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(
                            cellWidth - dp(8), ViewGroup.LayoutParams.WRAP_CONTENT);
                    lp.setMargins(dp(4), dp(4), dp(4), dp(4));
                    card.setLayoutParams(lp);
                } else {
                    card.setLayoutParams(new RecyclerView.LayoutParams(
                            cellWidth, ViewGroup.LayoutParams.WRAP_CONTENT));
                }
            } else {
                iconSize = dp(96);
                card.setBackground(cardBackground());
                card.setElevation(glass ? 0 : dp(6));
                RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(cardWidth, cardHeight);
                lp.setMargins(dp(8), 0, dp(8), 0);
                card.setLayoutParams(lp);
            }

            ImageView icon = new ImageView(RecentsActivity.this);
            card.addView(icon, new LinearLayout.LayoutParams(iconSize, iconSize));

            TextView label = new TextView(RecentsActivity.this);
            label.setTextColor(palette.text);
            label.setMaxLines(1);
            label.setEllipsize(TextUtils.TruncateAt.END);
            label.setGravity(Gravity.CENTER);
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, grid ? 12 : 17);
            label.setPadding(dp(8), dp(grid ? 6 : 14), dp(8), 0);
            label.setVisibility(labels ? View.VISIBLE : View.GONE);
            card.addView(label, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            return new Holder(card, icon, label);
        }

        @Override
        public void onBindViewHolder(Holder holder, int position) {
            RecentApps.App app = items.get(position);
            holder.icon.setImageDrawable(app.icon);
            holder.label.setText(app.label);
            holder.itemView.setOnClickListener(v -> {
                int p = holder.getBindingAdapterPosition();
                if (p != RecyclerView.NO_POSITION) {
                    launch(items.get(p));
                }
            });
        }

        @Override
        public int getItemCount() {
            return items.size();
        }
    }
}
