# Cover Recents

Własny ekran ostatnich aplikacji dla ekranu zewnętrznego Galaxy Z Flip 5/6/7.

## Budowa APK

GitHub: wrzuć repozytorium, uruchom workflow "Build APK" (zakładka Actions), pobierz `app-release.apk`
z artefaktów. Lub Android Studio: otwórz folder i `Build > Build APK(s)` (wariant release).

## Konfiguracja na telefonie

1. Zainstaluj APK i otwórz aplikację.
2. "Przyznaj dostęp do użycia" i włącz przełącznik dla Cover Recents.
3. Widżet: na ekranie zewnętrznym dodaj widżet "Ostatnie aplikacje" (przesuń do widżetów).
4. Gest (drugi sposób, działa obok widżetu): włącz usługę ułatwień dostępu i "Włącz gest
   przytrzymania paska" w ustawieniach aplikacji. Przytrzymaj pasek powrotu do ekranu głównego
   (domyślnie 2 s). Jeśli przełącznik usługi jest wyszarzony: Ustawienia > Aplikacje >
   Cover Recents > menu ⋮ > Zezwól na ustawienia z ograniczeniami.
5. Wygląd: motyw (systemowy, ciemny, biały, AMOLED) i styl (standardowy, rozmycie tła, liquid glass).
   "Podgląd na tym ekranie" pokazuje ekran ostatnich bez składania telefonu.

## Diagnostyka

`adb logcat -s CoverRecents` pokazuje, czy system odmówił uruchomienia na ekranie zewnętrznym
oraz jaki obszar gestu został utworzony.
