package com.melt.flipdecision.render

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin

/**
 * Moneta 3D: walec z radełkowaną krawędzią i dwiema twarzami.
 * Przód (+Z) = Orzeł, tył (-Z) = Reszka. Tył ma v = -Y, więc po obrocie o 180° wokół X
 * jest ustawiony „do góry nogami” dokładnie tak, jak trzeba.
 */
class CoinRenderer {
    private val matrix = Matrix()
    private val src = floatArrayOf(-100f, -100f, 100f, -100f, 100f, 100f, -100f, 100f)
    private val dst = FloatArray(8)
    private val path = Path()

    private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL_AND_STROKE
        strokeWidth = 1.2f
    }
    private val overlayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val emblemDark = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFF8F6A1D.toInt()
    }
    private val emblemLight = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFFFBE9B4.toInt()
    }
    private val discPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        shader = RadialGradient(
            -30f, -36f, 170f,
            intArrayOf(0xFFF8E3A6.toInt(), 0xFFDDAE47.toInt(), 0xFFB9892D.toInt()),
            floatArrayOf(0f, 0.62f, 1f),
            Shader.TileMode.CLAMP
        )
    }
    private val bigText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textSize = 124f
    }
    private val smallText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textSize = 24f
        letterSpacing = 0.3f
    }
    private val eagle: Path = buildEagle()

    fun draw(canvas: Canvas, q: Quat, cam: Camera) {
        drawEdge(canvas, q, cam)
        drawFace(canvas, q, cam, front = true)
        drawFace(canvas, q, cam, front = false)
    }

    // ---------------------------------------------------------------- krawędź

    private fun drawEdge(canvas: Canvas, q: Quat, cam: Camera) {
        for (i in 0 until SEGMENTS) {
            val a0 = TWO_PI * i / SEGMENTS
            val a1 = TWO_PI * (i + 1) / SEGMENTS
            val mid = (a0 + a1) / 2f
            val nr = q.rotate(Vec3(cos(mid), sin(mid), 0f))
            val center = q.rotate(Vec3(R * cos(mid), R * sin(mid), 0f))
            if (!cam.facing(center, nr)) continue

            val p0 = q.rotate(Vec3(R * cos(a0), R * sin(a0), H))
            val p1 = q.rotate(Vec3(R * cos(a1), R * sin(a1), H))
            val p2 = q.rotate(Vec3(R * cos(a1), R * sin(a1), -H))
            val p3 = q.rotate(Vec3(R * cos(a0), R * sin(a0), -H))
            path.reset()
            path.moveTo(cam.px(p0), cam.py(p0))
            path.lineTo(cam.px(p1), cam.py(p1))
            path.lineTo(cam.px(p2), cam.py(p2))
            path.lineTo(cam.px(p3), cam.py(p3))
            path.close()

            val diff = max(0f, nr dot Light.dir)
            // radełkowanie: co drugi ząbek minimalnie jaśniejszy
            val reeding = if (i % 2 == 0) 0.07f else -0.07f
            val bright = (AMBIENT + (1f - AMBIENT) * diff + reeding).coerceIn(0f, 1.2f)
            val spec = max(0f, nr dot Light.half).pow(8f)
            edgePaint.color = shade(200, 150, 52, bright, spec)
            canvas.drawPath(path, edgePaint)
        }
    }

    // ----------------------------------------------------------------- twarze

    private fun drawFace(canvas: Canvas, q: Quat, cam: Camera, front: Boolean) {
        val z = if (front) H else -H
        val vSign = if (front) 1f else -1f
        val nr = q.rotate(Vec3(0f, 0f, if (front) 1f else -1f))
        val center = q.rotate(Vec3(0f, 0f, z))
        if (!cam.facing(center, nr)) return

        var i = 0
        for ((a, b) in CORNERS) {
            val p = q.rotate(Vec3(R * a, R * b * vSign, z))
            dst[i++] = cam.px(p)
            dst[i++] = cam.py(p)
        }
        if (!matrix.setPolyToPoly(src, 0, dst, 0, 4)) return

        val diff = max(0f, nr dot Light.dir)
        val bright = AMBIENT + (1f - AMBIENT) * diff
        val spec = max(0f, nr dot Light.half).pow(10f)
        val shadeAlpha = ((1f - bright) * 200f).toInt().coerceIn(0, 255)
        val specAlpha = (spec * 170f).toInt().coerceIn(0, 255)

        canvas.save()
        canvas.concat(matrix)

        canvas.drawCircle(0f, 0f, 100f, discPaint)

        // obrzeże: gruby pierścień + cienka linia wewnątrz
        ringPaint.strokeWidth = 7f
        ringPaint.color = 0xFFC3952F.toInt()
        canvas.drawCircle(0f, 0f, 93f, ringPaint)
        ringPaint.strokeWidth = 1.8f
        ringPaint.color = 0xFFF3D78B.toInt()
        canvas.drawCircle(0f, 0f, 83f, ringPaint)

        if (front) drawEagle(canvas) else drawTails(canvas)

        overlayPaint.color = Color.argb(shadeAlpha, 20, 14, 4)
        canvas.drawCircle(0f, 0f, 100f, overlayPaint)
        overlayPaint.color = Color.argb(specAlpha, 255, 250, 235)
        canvas.drawCircle(0f, 0f, 100f, overlayPaint)

        canvas.restore()
    }

    private fun drawEagle(canvas: Canvas) {
        canvas.save()
        canvas.translate(0f, 6f)
        canvas.save()
        canvas.translate(-1.8f, -1.8f)
        canvas.drawPath(eagle, emblemLight)
        canvas.restore()
        canvas.drawPath(eagle, emblemDark)
        canvas.restore()
    }

    private fun drawTails(canvas: Canvas) {
        // wytłoczenie: jasna kopia przesunięta w lewo-górę, ciemna na wierzchu
        canvas.drawText("1", -1.8f, 28f - 1.8f, tint(bigText, emblemLight.color))
        canvas.drawText("1", 0f, 28f, tint(bigText, emblemDark.color))
        canvas.drawText("ZŁ", -1.4f, 64f - 1.4f, tint(smallText, emblemLight.color))
        canvas.drawText("ZŁ", 0f, 64f, tint(smallText, emblemDark.color))
    }

    private fun tint(p: Paint, color: Int): Paint {
        p.color = color
        return p
    }

    // ------------------------------------------------------------------ pomoc

    private fun shade(r: Int, g: Int, b: Int, bright: Float, spec: Float): Int {
        val sr = (r * bright + 255f * spec * 0.6f).toInt().coerceIn(0, 255)
        val sg = (g * bright + 255f * spec * 0.6f).toInt().coerceIn(0, 255)
        val sb = (b * bright + 255f * spec * 0.6f).toInt().coerceIn(0, 255)
        return Color.rgb(sr, sg, sb)
    }

    /** Geometryczny, symetryczny orzeł: korona, głowa, korpus i wachlarz piór. */
    private fun buildEagle(): Path {
        val half = Path()
        val tips = arrayOf(
            floatArrayOf(56f, -52f), floatArrayOf(68f, -24f),
            floatArrayOf(64f, 6f), floatArrayOf(50f, 34f)
        )
        for (i in tips.indices) {
            val y0 = -16f + i * 12f
            half.moveTo(12f, y0)
            half.lineTo(tips[i][0], tips[i][1])
            half.lineTo(12f, y0 + 12f)
            half.close()
        }
        // prawa połowa korpusu
        half.moveTo(0f, -22f)
        half.lineTo(12f, -15f)
        half.lineTo(15f, 6f)
        half.lineTo(10f, 30f)
        half.lineTo(0f, 52f)
        half.close()
        // prawa połowa korony
        half.moveTo(0f, -64f)
        half.lineTo(7f, -52f)
        half.lineTo(15f, -60f)
        half.lineTo(13f, -42f)
        half.lineTo(0f, -42f)
        half.close()

        val full = Path()
        full.addPath(half)
        val mirror = Matrix().apply { setScale(-1f, 1f) }
        full.addPath(half, mirror)
        full.addCircle(0f, -31f, 11f, Path.Direction.CW)
        return full
    }

    private companion object {
        const val R = 1f
        const val H = 0.085f
        const val SEGMENTS = 72
        const val AMBIENT = 0.55f

        val CORNERS = listOf(-1f to 1f, 1f to 1f, 1f to -1f, -1f to -1f)
    }
}
