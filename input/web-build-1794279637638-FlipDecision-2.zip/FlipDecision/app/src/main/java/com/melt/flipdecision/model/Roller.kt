package com.melt.flipdecision.model

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.melt.flipdecision.render.PI_F
import com.melt.flipdecision.render.Quat
import com.melt.flipdecision.render.TWO_PI
import com.melt.flipdecision.render.DiceGeometry
import com.melt.flipdecision.render.Vec3
import kotlin.random.Random

enum class Mode { COIN, DICE }

/**
 * Stan jednego rzutu (moneta albo kostka).
 *
 * Orientacja w czasie t:  spin(t) * slerp(qFrom, qTo, e(t))
 * gdzie spin to obrót o (totalAngle * (1 - e)) wokół losowej osi. totalAngle jest
 * wielokrotnością 2π, więc w t = 1 zostaje dokładnie qTo (wylosowana ściana na wierzchu),
 * a w t = 0 obiekt nie „skacze” względem poprzedniego położenia.
 */
class Roller(private val mode: Mode) {
    val progress = Animatable(1f)   // 0 = start rzutu, 1 = spoczynek
    val settle = Animatable(0f)     // mały „stuk” po wylądowaniu

    var qFrom: Quat = Quat.IDENTITY
    var qTo: Quat = Quat.IDENTITY
    var axis: Vec3 = Vec3.X
    var totalAngle: Float = 0f

    var rolling by mutableStateOf(false)
    /** Moneta: 0 = orzeł, 1 = reszka. Kostka: 1..6. null = jeszcze nie rzucano. */
    var result by mutableStateOf<Int?>(null)

    private var qRest: Quat = Quat.IDENTITY

    suspend fun roll(onLand: () -> Unit) {
        if (rolling) return
        rolling = true

        val newValue: Int
        val target: Quat
        val durationMs: Int
        if (mode == Mode.COIN) {
            newValue = Random.nextInt(2)
            target = if (newValue == 0) Quat.IDENTITY else Quat.axisAngle(Vec3.X, PI_F)
            axis = Vec3(1f, Random.nextFloat() * 0.24f - 0.12f, Random.nextFloat() * 0.2f - 0.1f).normalized()
            totalAngle = (4 + Random.nextInt(2)) * TWO_PI
            durationMs = 1750
        } else {
            newValue = Random.nextInt(1, 7)
            val align = Quat.fromTo(DiceGeometry.normalOf(newValue), Vec3.Z)
            val twist = Quat.axisAngle(Vec3.Z, (Random.nextFloat() - 0.5f) * 0.7f)
            target = twist * align
            axis = Vec3(
                sign() * (0.6f + 0.4f * Random.nextFloat()),
                sign() * (0.5f + 0.5f * Random.nextFloat()),
                sign() * (0.2f + 0.4f * Random.nextFloat())
            ).normalized()
            totalAngle = (2 + Random.nextInt(2)) * TWO_PI
            durationMs = 1600
        }

        qFrom = qRest
        qTo = target
        try {
            progress.snapTo(0f)
            progress.animateTo(1f, tween(durationMs, easing = LinearEasing))
            qRest = target
            result = newValue
        } finally {
            rolling = false
        }
        onLand()
        settle.snapTo(1f)
        settle.animateTo(0f, spring(dampingRatio = 0.35f, stiffness = 220f))
    }

    private fun sign(): Float = if (Random.nextBoolean()) 1f else -1f
}
