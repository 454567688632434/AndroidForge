package com.melt.flipdecision

import android.graphics.Color
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import com.melt.flipdecision.model.Mode
import com.melt.flipdecision.ui.FlipDecisionApp
import com.melt.flipdecision.ui.FlipDecisionTheme

class MainActivity : ComponentActivity() {
    private var shakeTick by mutableIntStateOf(0)
    private lateinit var shakeDetector: ShakeDetector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        // ekran zewnętrzny szybko gaśnie – podczas rzucania niech zostanie włączony
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        shakeDetector = ShakeDetector(this) { shakeTick++ }

        val prefs = getSharedPreferences("flip_decision", MODE_PRIVATE)
        val startMode = Mode.entries.getOrElse(prefs.getInt("mode", 0)) { Mode.COIN }

        setContent {
            FlipDecisionTheme {
                FlipDecisionApp(
                    shakeTick = shakeTick,
                    startMode = startMode,
                    onModeChange = { prefs.edit().putInt("mode", it.ordinal).apply() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        shakeDetector.start()
    }

    override fun onPause() {
        shakeDetector.stop()
        super.onPause()
    }
}
