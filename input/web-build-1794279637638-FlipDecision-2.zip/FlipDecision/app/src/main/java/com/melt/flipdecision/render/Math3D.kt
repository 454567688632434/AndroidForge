package com.melt.flipdecision.render

import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

const val TWO_PI = 6.2831855f
const val PI_F = 3.1415927f

data class Vec3(val x: Float, val y: Float, val z: Float) {
    operator fun plus(o: Vec3) = Vec3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: Vec3) = Vec3(x - o.x, y - o.y, z - o.z)
    operator fun times(s: Float) = Vec3(x * s, y * s, z * s)

    infix fun dot(o: Vec3): Float = x * o.x + y * o.y + z * o.z
    infix fun cross(o: Vec3) = Vec3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x)

    fun length(): Float = sqrt(x * x + y * y + z * z)

    fun normalized(): Vec3 {
        val l = length()
        return if (l < 1e-6f) this else Vec3(x / l, y / l, z / l)
    }

    companion object {
        val X = Vec3(1f, 0f, 0f)
        val Y = Vec3(0f, 1f, 0f)
        val Z = Vec3(0f, 0f, 1f)
    }
}

/** Kwaternion jednostkowy (w, x, y, z) – obrót bez blokady osi (gimbal lock). */
data class Quat(val w: Float, val x: Float, val y: Float, val z: Float) {

    operator fun times(o: Quat) = Quat(
        w * o.w - x * o.x - y * o.y - z * o.z,
        w * o.x + x * o.w + y * o.z - z * o.y,
        w * o.y - x * o.z + y * o.w + z * o.x,
        w * o.z + x * o.y - y * o.x + z * o.w
    )

    fun rotate(v: Vec3): Vec3 {
        val u = Vec3(x, y, z)
        val t = (u cross v) * 2f
        return v + t * w + (u cross t)
    }

    fun normalized(): Quat {
        val n = sqrt(w * w + x * x + y * y + z * z)
        return if (n < 1e-6f) IDENTITY else Quat(w / n, x / n, y / n, z / n)
    }

    companion object {
        val IDENTITY = Quat(1f, 0f, 0f, 0f)

        fun axisAngle(axis: Vec3, angle: Float): Quat {
            val a = axis.normalized()
            val s = sin(angle / 2f)
            return Quat(cos(angle / 2f), a.x * s, a.y * s, a.z * s)
        }

        /** Najkrótszy obrót przeprowadzający wektor [a] na wektor [b] (oba jednostkowe). */
        fun fromTo(a: Vec3, b: Vec3): Quat {
            val d = a dot b
            if (d > 0.99999f) return IDENTITY
            if (d < -0.99999f) {
                val helper = if (abs(a.x) < 0.9f) Vec3.X else Vec3.Y
                return axisAngle(a cross helper, PI_F)
            }
            val c = a cross b
            return Quat(1f + d, c.x, c.y, c.z).normalized()
        }

        fun slerp(a: Quat, b0: Quat, t: Float): Quat {
            var b = b0
            var d = a.w * b.w + a.x * b.x + a.y * b.y + a.z * b.z
            if (d < 0f) {
                b = Quat(-b.w, -b.x, -b.y, -b.z)
                d = -d
            }
            if (d > 0.9995f) {
                return Quat(
                    a.w + (b.w - a.w) * t,
                    a.x + (b.x - a.x) * t,
                    a.y + (b.y - a.y) * t,
                    a.z + (b.z - a.z) * t
                ).normalized()
            }
            val theta = acos(d)
            val sinTheta = sin(theta)
            val wa = sin((1f - t) * theta) / sinTheta
            val wb = sin(t * theta) / sinTheta
            return Quat(
                a.w * wa + b.w * wb,
                a.x * wa + b.x * wb,
                a.y * wa + b.y * wb,
                a.z * wa + b.z * wb
            )
        }
    }
}
