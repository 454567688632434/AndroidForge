package com.melt.flipdecision.render

/** Prosta kamera perspektywiczna: patrzy wzdłuż -Z, obiekt wokół początku układu. */
class Camera(
    val cx: Float,
    val cy: Float,
    val ppu: Float,          // piksele na jednostkę świata
    val dist: Float = 6f     // odległość kamery od środka sceny
) {
    fun px(p: Vec3): Float = cx + p.x * ppu * dist / (dist - p.z)
    fun py(p: Vec3): Float = cy - p.y * ppu * dist / (dist - p.z)

    /** Czy ściana (środek + normalna) jest zwrócona w stronę kamery. */
    fun facing(center: Vec3, normal: Vec3): Boolean =
        normal.x * (0f - center.x) + normal.y * (0f - center.y) + normal.z * (dist - center.z) > 0f
}

object Light {
    /** Światło z lewej-góry-przodu: miękkie, jak w aplikacjach One UI. */
    val dir = Vec3(-0.35f, 0.65f, 0.67f).normalized()
    val half = (dir + Vec3(0f, 0f, 1f)).normalized()
}
