package com.melt.flipdecision

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import kotlin.math.sqrt

/** Wykrywa potrząśnięcie telefonem (kilka próbek akcelerometru > progu w krótkim oknie). */
class ShakeDetector(context: Context, private val onShake: () -> Unit) : SensorEventListener {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelerometer: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private var windowStart = 0L
    private var hits = 0
    private var lastShake = 0L

    fun start() {
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        val gForce = sqrt(
            event.values[0] * event.values[0] +
                event.values[1] * event.values[1] +
                event.values[2] * event.values[2]
        ) / SensorManager.GRAVITY_EARTH
        if (gForce < THRESHOLD_G) return

        val now = SystemClock.elapsedRealtime()
        if (now - windowStart > WINDOW_MS) {
            windowStart = now
            hits = 0
        }
        hits++
        if (hits >= REQUIRED_HITS && now - lastShake > COOLDOWN_MS) {
            lastShake = now
            hits = 0
            onShake()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private companion object {
        const val THRESHOLD_G = 2.4f   // czułość: niższa wartość = łatwiej wywołać
        const val REQUIRED_HITS = 4
        const val WINDOW_MS = 600L
        const val COOLDOWN_MS = 1000L
    }
}
