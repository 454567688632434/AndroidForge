package com.melt.flipdecision.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.view.HapticFeedbackConstants
import com.melt.flipdecision.R
import com.melt.flipdecision.model.Mode
import com.melt.flipdecision.model.Roller
import com.melt.flipdecision.render.CoinRenderer
import com.melt.flipdecision.render.DiceRenderer
import com.melt.flipdecision.render.Camera
import com.melt.flipdecision.render.Quat
import com.melt.flipdecision.render.TWO_PI
import com.melt.flipdecision.render.Vec3
import kotlinx.coroutines.launch
import kotlin.math.min
import kotlin.math.sin

@Composable
fun FlipDecisionApp(shakeTick: Int, startMode: Mode, onModeChange: (Mode) -> Unit) {
    var mode by rememberSaveable { mutableStateOf(startMode) }
    val coin = remember { Roller(Mode.COIN) }
    val dice = remember { Roller(Mode.DICE) }
    val scope = rememberCoroutineScope()
    val view = LocalView.current

    fun throwIt(roller: Roller) {
        if (roller.rolling) return
        view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        scope.launch {
            roller.roll { view.performHapticFeedback(HapticFeedbackConstants.CONFIRM) }
        }
    }

    // potrząśnięcie rzuca tylko w trybie kostki
    LaunchedEffect(shakeTick) {
        if (shakeTick > 0 && mode == Mode.DICE) throwIt(dice)
    }

    val active = if (mode == Mode.COIN) coin else dice
    val hint = stringResource(if (mode == Mode.COIN) R.string.hint_coin else R.string.hint_dice)
    val shown = when {
        active.rolling -> ""
        active.result == null -> hint
        mode == Mode.COIN -> stringResource(if (active.result == 0) R.string.heads else R.string.tails)
        else -> active.result.toString()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(FlipColors.Background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 20.dp)
            .padding(bottom = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(8.dp))

        Crossfade(
            targetState = mode,
            animationSpec = tween(260),
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            label = "stage"
        ) { m ->
            val roller = if (m == Mode.COIN) coin else dice
            Stage(
                mode = m,
                roller = roller,
                onTap = { throwIt(roller) },
                modifier = Modifier.fillMaxSize()
            )
        }

        Crossfade(
            targetState = shown,
            animationSpec = tween(220),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            label = "label"
        ) { s ->
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                when {
                    s.isEmpty() -> Unit
                    s == hint -> Text(
                        text = s,
                        color = FlipColors.TextSecondary,
                        fontSize = 14.sp
                    )
                    else -> Text(
                        text = s,
                        color = FlipColors.TextPrimary,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        ModeToggle(
            mode = mode,
            onSelect = {
                if (it != mode) {
                    view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    mode = it
                    onModeChange(it)
                }
            }
        )
    }
}

// ------------------------------------------------------------------- scena 3D

private val RotationEase = CubicBezierEasing(0.25f, 0.6f, 0.2f, 1f)
private val ViewCoin = Quat.axisAngle(Vec3.X, 0.30f) * Quat.axisAngle(Vec3.Y, -0.22f)
private val ViewDice = Quat.axisAngle(Vec3.X, 0.38f) * Quat.axisAngle(Vec3.Y, -0.50f)

@Composable
private fun Stage(mode: Mode, roller: Roller, onTap: () -> Unit, modifier: Modifier) {
    val coinRenderer = remember { CoinRenderer() }
    val diceRenderer = remember { DiceRenderer() }
    val idle by rememberInfiniteTransition(label = "idle").animateFloat(
        initialValue = 0f,
        targetValue = TWO_PI,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)),
        label = "idlePhase"
    )
    val description = stringResource(if (mode == Mode.COIN) R.string.hint_coin else R.string.hint_dice)

    Canvas(
        modifier = modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
            onClickLabel = description,
            role = Role.Button,
            onClick = onTap
        )
    ) {
        val isCoin = mode == Mode.COIN
        val minDim = min(size.width, size.height)
        val ppu = if (isCoin) minDim * 0.27f else minDim * 0.20f

        val t = roller.progress.value
        val toss = 4f * t * (1f - t)
        val scale = 1f + 0.16f * toss
        val cx = size.width / 2f
        val baseY = size.height * 0.56f
        val cy = baseY - toss * ppu * 0.9f +
            roller.settle.value * ppu * 0.05f +
            sin(idle) * ppu * 0.03f

        // miękka poświata za obiektem + „światło podłogi” pod nim
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(FlipColors.Accent.copy(alpha = 0.16f), Color.Transparent),
                center = Offset(cx, baseY + ppu * 0.1f),
                radius = ppu * (2.6f - 0.5f * toss)
            ),
            radius = ppu * (2.6f - 0.5f * toss),
            center = Offset(cx, baseY + ppu * 0.1f)
        )
        val floorY = baseY + ppu * 1.35f
        val floorR = ppu * 1.3f * (1f - 0.3f * toss)
        withTransform({ scale(1f, 0.2f, pivot = Offset(cx, floorY)) }) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White.copy(alpha = 0.10f), Color.Transparent),
                    center = Offset(cx, floorY),
                    radius = floorR
                ),
                radius = floorR,
                center = Offset(cx, floorY)
            )
        }

        val e = RotationEase.transform(t)
        val spin = Quat.axisAngle(roller.axis, roller.totalAngle * (1f - e))
        val base = Quat.slerp(roller.qFrom, roller.qTo, e)
        val idleQ = Quat.axisAngle(Vec3.Y, 0.05f * sin(idle)) *
            Quat.axisAngle(Vec3.X, 0.035f * sin(idle * 0.8f + 1f))
        val q = idleQ * (if (isCoin) ViewCoin else ViewDice) * spin * base
        val cam = Camera(cx, cy, ppu * scale)

        drawIntoCanvas { c ->
            if (isCoin) coinRenderer.draw(c.nativeCanvas, q, cam)
            else diceRenderer.draw(c.nativeCanvas, q, cam)
        }
    }
}

// -------------------------------------------------------------------- przełącznik

@Composable
private fun ModeToggle(mode: Mode, onSelect: (Mode) -> Unit) {
    val items = listOf(
        Mode.COIN to stringResource(R.string.mode_coin),
        Mode.DICE to stringResource(R.string.mode_dice)
    )
    BoxWithConstraints(
        modifier = Modifier
            .widthIn(max = 320.dp)
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(FlipColors.Surface)
            .padding(4.dp)
    ) {
        val segmentWidth = maxWidth / 2
        val indicatorX by animateDpAsState(
            targetValue = segmentWidth * mode.ordinal,
            animationSpec = spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow),
            label = "indicator"
        )
        Box(
            Modifier
                .offset(x = indicatorX)
                .width(segmentWidth)
                .fillMaxHeight()
                .clip(RoundedCornerShape(22.dp))
                .background(FlipColors.Accent)
        )
        Row(Modifier.fillMaxSize()) {
            items.forEach { (m, label) ->
                val color by animateColorAsState(
                    targetValue = if (m == mode) Color.White else FlipColors.TextSecondary,
                    animationSpec = tween(200),
                    label = "segmentText"
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(22.dp))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            role = Role.Tab
                        ) { onSelect(m) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = color,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}
