package com.melt.flipdecision.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Paleta w duchu One UI (tryb ciemny, AMOLED): czerń, grafitowe powierzchnie, niebieski akcent. */
object FlipColors {
    val Background = Color(0xFF000000)
    val Surface = Color(0xFF1F1F1F)
    val Accent = Color(0xFF3E91FF)
    val TextPrimary = Color(0xFFFAFAFA)
    val TextSecondary = Color(0xFF9A9AA0)
}

@Composable
fun FlipDecisionTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = FlipColors.Accent,
            background = FlipColors.Background,
            surface = FlipColors.Surface,
            onBackground = FlipColors.TextPrimary,
            onSurface = FlipColors.TextPrimary
        ),
        content = content
    )
}
