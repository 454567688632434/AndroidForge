package com.melt.flipdecision.render

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.math.max
import kotlin.math.pow

object DiceGeometry {
    class Face(val value: Int, val n: Vec3, val u: Vec3, val v: Vec3)

    // u × v = n dla każdej ściany – dzięki temu oczka nie są odbite lustrzanie.
    // Przeciwległe ściany sumują się do 7.
    val faces = listOf(
        Face(1, Vec3(0f, 0f, 1f), Vec3(1f, 0f, 0f), Vec3(0f, 1f, 0f)),
        Face(6, Vec3(0f, 0f, -1f), Vec3(-1f, 0f, 0f), Vec3(0f, 1f, 0f)),
        Face(3, Vec3(1f, 0f, 0f), Vec3(0f, 0f, -1f), Vec3(0f, 1f, 0f)),
        Face(4, Vec3(-1f, 0f, 0f), Vec3(0f, 0f, 1f), Vec3(0f, 1f, 0f)),
        Face(2, Vec3(0f, 1f, 0f), Vec3(1f, 0f, 0f), Vec3(0f, 0f, -1f)),
        Face(5, Vec3(0f, -1f, 0f), Vec3(1f, 0f, 0f), Vec3(0f, 0f, 1f))
    )

    fun normalOf(value: Int): Vec3 = faces.first { it.value == value }.n
}

/**
 * Kostka 3D rysowana na android.graphics.Canvas.
 * Każda ściana to zaokrąglony kwadrat w lokalnych współrzędnych [-100, 100],
 * rzutowany macierzą perspektywiczną (setPolyToPoly na 4 punktach).
 */
class DiceRenderer {
    private val matrix = Matrix()
    private val src = floatArrayOf(-100f, -100f, 100f, -100f, 100f, 100f, -100f, 100f)
    private val dst = FloatArray(8)

    private val facePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val overlayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val pipPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(
            -7f, -8f, 34f,
            intArrayOf(0xFF4A4A52.toInt(), 0xFF141417.toInt()),
            null, Shader.TileMode.CLAMP
        )
    }
    private val pipAccentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(
            -8f, -9f, 40f,
            intArrayOf(0xFF7DB6FF.toInt(), 0xFF2F7CE8.toInt()),
            null, Shader.TileMode.CLAMP
        )
    }

    fun draw(canvas: Canvas, q: Quat, cam: Camera) {
        // 1) „rdzeń” – nieco mniejszy sześcian wypełnia rogi zaokrąglonych ścian
        for (f in DiceGeometry.faces) {
            val n = q.rotate(f.n)
            val c = q.rotate(f.n * CORE)
            if (cam.facing(c, n)) drawFace(canvas, q, cam, f, CORE, true)
        }
        // 2) właściwe ściany (widoczne ściany wypukłej bryły nie zasłaniają się nawzajem)
        for (f in DiceGeometry.faces) {
            val n = q.rotate(f.n)
            val c = q.rotate(f.n)
            if (cam.facing(c, n)) drawFace(canvas, q, cam, f, 1f, false)
        }
    }

    private fun drawFace(
        canvas: Canvas, q: Quat, cam: Camera,
        f: DiceGeometry.Face, s: Float, core: Boolean
    ) {
        var i = 0
        for ((a, b) in CORNERS) {
            val p = q.rotate((f.n + f.u * a + f.v * b) * s)
            dst[i++] = cam.px(p)
            dst[i++] = cam.py(p)
        }
        if (!matrix.setPolyToPoly(src, 0, dst, 0, 4)) return

        val nr = q.rotate(f.n)
        val diff = max(0f, nr dot Light.dir)
        val bright = AMBIENT + (1f - AMBIENT) * diff
        val spec = max(0f, nr dot Light.half).pow(SPEC_POWER)
        val shadeAlpha = ((1f - bright) * 235f).toInt().coerceIn(0, 255)
        val specAlpha = (spec * 150f).toInt().coerceIn(0, 255)

        canvas.save()
        canvas.concat(matrix)
        if (core) {
            facePaint.color = CORE_COLOR
            canvas.drawRect(-100f, -100f, 100f, 100f, facePaint)
            overlayPaint.color = Color.argb(shadeAlpha, 8, 12, 28)
            canvas.drawRect(-100f, -100f, 100f, 100f, overlayPaint)
        } else {
            facePaint.color = FACE_COLOR
            canvas.drawRoundRect(-100f, -100f, 100f, 100f, RADIUS, RADIUS, facePaint)
            drawPips(canvas, f.value)
            overlayPaint.color = Color.argb(shadeAlpha, 8, 12, 28)
            canvas.drawRoundRect(-100f, -100f, 100f, 100f, RADIUS, RADIUS, overlayPaint)
            overlayPaint.color = Color.argb(specAlpha, 255, 255, 255)
            canvas.drawRoundRect(-100f, -100f, 100f, 100f, RADIUS, RADIUS, overlayPaint)
            rimPaint.color = Color.argb((80 * bright).toInt().coerceIn(0, 255), 255, 255, 255)
            canvas.drawRoundRect(-98.5f, -98.5f, 98.5f, 98.5f, RADIUS, RADIUS, rimPaint)
        }
        canvas.restore()
    }

    private fun drawPips(canvas: Canvas, value: Int) {
        val pts = PIPS.getValue(value)
        val paint = if (value == 1) pipAccentPaint else pipPaint
        val r = if (value == 1) 26f else 18f
        var i = 0
        while (i < pts.size) {
            canvas.save()
            canvas.translate(pts[i], pts[i + 1])
            canvas.drawCircle(0f, 0f, r, paint)
            canvas.restore()
            i += 2
        }
    }

    private companion object {
        const val CORE = 0.955f
        const val RADIUS = 20f
        const val AMBIENT = 0.5f
        const val SPEC_POWER = 22f
        val FACE_COLOR = 0xFFF4F4F6.toInt()
        val CORE_COLOR = 0xFFD2D2D9.toInt()

        // (a, b) po kolei: lewy-górny, prawy-górny, prawy-dolny, lewy-dolny
        val CORNERS = listOf(-1f to 1f, 1f to 1f, 1f to -1f, -1f to -1f)

        val PIPS: Map<Int, FloatArray> = mapOf(
            1 to floatArrayOf(0f, 0f),
            2 to floatArrayOf(-50f, -50f, 50f, 50f),
            3 to floatArrayOf(-50f, -50f, 0f, 0f, 50f, 50f),
            4 to floatArrayOf(-50f, -50f, 50f, -50f, -50f, 50f, 50f, 50f),
            5 to floatArrayOf(-50f, -50f, 50f, -50f, 0f, 0f, -50f, 50f, 50f, 50f),
            6 to floatArrayOf(-50f, -50f, 50f, -50f, -50f, 0f, 50f, 0f, -50f, 50f, 50f, 50f)
        )
    }
}
