# Flip Decision

Minimalistyczna aplikacja na ekran zewnętrzny (cover screen) Samsunga Galaxy Z Flip 5:
moneta 3D (dotknij) albo kostka 3D (potrząśnij telefonem). Styl One UI: czarne tło AMOLED,
grafitowy przełącznik, niebieski akcent #3E91FF, zaokrąglone pigułki, miękkie animacje sprężynowe.

## Budowanie APK

1. Otwórz folder `FlipDecision` w Android Studio (Ladybug lub nowszy). Przy pierwszym otwarciu
   Studio samo pobierze Gradle i zależności (wymaga internetu).
2. `Build > Build APK(s)` (debug) albo w terminalu: `./gradlew assembleRelease`
   (jeśli nie ma wrappera: `gradle wrapper --gradle-version 8.9` albo użyj Studio).
3. APK: `app/build/outputs/apk/release/app-release.apk` (podpisany kluczem debug, gotowy do sideloadu).
4. Instalacja: `adb uninstall com.melt.flipdecision; adb install -r app-release.apk`.

## Uruchamianie na cover screenie

Aplikacja jest zwykłą aktywnością z układem płynnym (działa też na głównym ekranie).
Na zewnętrznym ekranie uruchom ją tą samą metodą, której używasz dla innych aplikacji
(np. widżet/launcher MultiStar z Good Lock albo opcja pozwalająca uruchamiać dowolne aplikacje
na ekranie zewnętrznym, zależnie od wersji One UI).

## Sterowanie

- Przełącznik u dołu: Moneta / Kostka (wybór jest zapamiętywany).
- Moneta: dotknij monety, wynik to Orzeł albo Reszka.
- Kostka: potrząśnij telefonem (dotyk też działa jako awaryjny rzut).
- Lekka wibracja przy starcie i lądowaniu.

## Dostrajanie

- Czułość potrząśnięcia: `ShakeDetector.kt` (`THRESHOLD_G`, `REQUIRED_HITS`).
- Czas i liczba obrotów: `model/Roller.kt` (`durationMs`, `totalAngle`).
- Krzywa zwalniania obrotu: `RotationEase` w `ui/FlipDecisionApp.kt`.
- Rozmiar obiektów: `ppu` w `Stage` (`0.27` moneta, `0.20` kostka).
- Kolory monety i kostki: `render/CoinRenderer.kt`, `render/DiceRenderer.kt`.
- Kąt widzenia (pochylenie kamery): `ViewCoin`, `ViewDice`.

## Jak to działa

Własny mini-silnik 3D bez bibliotek: orientacja jako kwaterniony, perspektywa kamery,
oświetlenie (ambient + diffuse + specular), a każda ściana jest rysowana w lokalnych
współrzędnych i rzutowana macierzą perspektywiczną na Canvasie. Rzut kończy się dokładnie
na wylosowanej ścianie, bez „przeskoku” na końcu animacji.
